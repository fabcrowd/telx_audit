---
format: 2
description: Automate TELx Merkl LP on Uniswap v4 Base to maximize fixed weekly reward share.
taskPrefix: TEL
---

## Tasks

### For Review
- [ ] **TEL-13** Confirm core plus anchor layout and alert channel

### In Progress
- [ ] **TEL-19** Design competitor-adaptive range width controller [Adaptive range width controller](bc-7358eb02-f99c-5a91-a357-827dbca547b8)

### Queued
- [ ] **TEL-11** Review fabcrowd TELx private repos [Report](/cursor/stores/self/docs/telx-private-repo-findings.md) [TELx private repos](bc-1b8fce17-3e2d-57d5-8bb0-4fb17fc24a4b)
- [ ] **TEL-3** Scaffold monitor and rebalance skeleton

### Done
- [x] **TEL-20** Review deployment stack and wireframe subscribe assurance [Report](/cursor/stores/self/docs/deployment-stack-and-wireframe.md)
- [x] **TEL-17** Compare live TELx pools for best reward yield [Report](/cursor/stores/self/docs/pool-selection.md)
- [x] **TEL-18** Fix block-time wording across design docs
- [x] **TEL-16** Reconcile mechanics thresholds and add low-RPC profile [Report](/cursor/stores/self/docs/measure-rebalance-mechanics.md)
- [x] **TEL-14** Analyze eUSD/TEL edge sources and recommend strategy [Report](/cursor/stores/self/docs/edge-strategy.md)
- [x] **TEL-15** Design measurement and rebalance mechanics for v4 pools [Report](/cursor/stores/self/docs/measure-rebalance-mechanics.md)
- [x] **TEL-12** Review blueprint structure and write build plan [Plan](/cursor/stores/self/docs/build-plan.md)
- [x] **TEL-2** Confirm stack, pool keys, and TELx subscribe ABI [Report](/cursor/stores/self/docs/bot-blueprint.md)
- [x] **TEL-10** Verify current TELx Merkl reward rules [Report](/cursor/stores/self/docs/telx-merkl-reward-rules.md)
- [x] **TEL-4** Analyze reference Uniswap v4 and volume repos [Report](/cursor/stores/self/docs/design-references.md)
- [x] **TEL-9** ^TEL-4 Consolidate repo briefs into design reference
- [x] **TEL-5** ^TEL-4 Volume-bot repo brief
- [x] **TEL-6** ^TEL-4 UniV4 atomic arbitrage brief
- [x] **TEL-7** ^TEL-4 Aperture v4 hooks brief
- [x] **TEL-8** ^TEL-4 JIT Uniswap v4 hook brief
- [x] **TEL-1** Draft bot structural blueprint [Report](/cursor/stores/self/docs/bot-blueprint.md)
