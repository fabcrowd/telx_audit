# eUSD/TEL (Base, Uniswap v4) — Structural edge analysis for a $2k Merkl LP

**Status:** design research only. No trading code, no secrets, no transactions.  
**Accessed / measured:** 2026-11-08, ~21:00–22:00 UTC (Base block 54,912,240 for state reads; logs 52,394,741→54,911,753 ≈ 30 days).  
**Pool:** `0x1266df87…6982` (eUSD `0x1491…2949` 6 dec = currency0, TEL v3 `0x7E13…0731` 18 dec = currency1, fee 3000, spacing 60, no hook).  
**Campaign:** Merkl opportunity `16270260351359923751`, live campaign `0x9d7de727…d1d2` (2026-11-01 → 11-30, 2,142,857 TEL ≈ **500k TEL/week ≈ $705/week** at pool price $0.00141).  
**Data & scripts:** `/cursor/stores/bc-01a1bcd2-3013-7934-9c8a-85bdaadc427d/internal/edge-data/` (see §9).  
Related: [`build-plan.md`](./build-plan.md) §1.1, [`bot-blueprint.md`](./bot-blueprint.md), [`telx-merkl-reward-rules.md`](./telx-merkl-reward-rules.md), [`measure-rebalance-mechanics.md`](./measure-rebalance-mechanics.md) (reconciled in §6).

---

## 0. TL;DR

1. **The scoring formula is confirmed empirically.** Reconstructing every position from 30 days of `ModifyLiquidity`/`Swap` logs and scoring it as `0.5·TW(L share) + 0.25·TW(eUSD share) + 0.25·TW(TEL share)` over in-range, subscribed positions reproduces the live Merkl leaderboard for all 60 rewarded tokenIds to within ±0.3 pp (sum of squared error 6e-5; L-only or value-only models are 400× worse). **The "fees" axis is time-weighted active-liquidity share, not realised swap fees.**
2. **The edge is concentration against wide passive capital.** In-range subscribed liquidity is only L ≈ 8.7e17 (≈ $29k of in-range value). $2k in a ±6% band is L ≈ 8.6e17 — i.e. **one $2k position doubles the pool's active liquidity** and takes ≈ 50% of the 50%-weighted liquidity axis before anyone reacts. Gross static upper bound: 142k TEL/week (28% share) at ±6%, 212k TEL/week (42%) at ±1.5%.
3. **The binding constraint is TEL volatility, not competitors.** Realised vol is 147% annualised (30d), 181% (last 7d); median daily range 6.9%, max 33.6%. A ±1.5% band is breached 43×/week, ±6% 5.8×/week. Replaying the last 30 days: tight layouts (including the build-plan straddle A/B/C) earn the most TEL (108–139k/week) **but lose money net of IL and re-centering costs**; ±6–12% single bands and "core + wide anchor" two-bracket layouts are the only ones with positive net P&L in every window tested.
4. **Recommended layout:** **≈ $1,000 in a ±6–8% "core" that re-centres on its own breach (≈ 1h hysteresis) + ≈ $1,000 in a ±25% "anchor" that is only re-centred when it is itself breached.** Expected ≈ **65–100k TEL/week (13–20% share, $90–140/week)** against the current competitor set, with IL + costs ≈ $75–170/week depending on regime, net ≈ +$5 to +$125/week. If the goal is strictly gross TEL regardless of IL, a single ±4–6% band earns 95–110k TEL/week.
5. **Volume spark: do not build.** The liquidity axis does not depend on swaps; a $5 self-swap changes the Merkl score by ~0 and costs ≈ (1 − our L share) × 0.3% × notional + gas, while Merkl's docs explicitly blacklist "creating tight positions and self-trading". Zero upside, non-zero tail risk.
6. **Structural trick worth copying (competitor 0xbbe5…):** pre-mint and subscribe *dust* positions in adjacent tick slots while they are in range (registry `minLiquidity = 0`, in-range is checked **only at subscribe**, subscriptions are never pruned for going out of range). Later re-centring becomes `increaseLiquidity` on an already-subscribed slot — no new NFT, no `OutOfRange` revert, and the one-sided B/C buffers from the blueprint become feasible after all. This is the same "slot model" the mechanics doc arrived at independently (D3).
7. **Reconciliation with [`measure-rebalance-mechanics.md`](./measure-rebalance-mechanics.md) §8 is in §6 below.** Headline: that doc's volatility inputs (25 swaps / 7 d, 1-h σ ≈ 20 ticks, daily range 10–160 t) are ≈ 10–30× too low versus the full log scan (805 swaps / 7 d, 1-h σ ≈ 156 t, daily ranges 440–2,900 t); its `coreHalf 180 / outerHalf 420 / maxRebalancesPerWeek 5` geometry would be breached ≈ 12×/week and spend most of a week capped-out and out of range. Decimals (eUSD 6 / TEL 18) and the swap-independent liquidity axis agree.

---

## 1. Reward model as actually applied

### 1.1 Campaign parameters (Merkl API, `/v4/campaigns?chainId=8453&campaignId=0x9d7d…`, 2026-11-08)

| Param | Value |
|---|---|
| `type` | `UNISWAP_V4_SUBSCRIPTION` (type 170) |
| `subscriptionContract` | `0xcebC0b00473Ca00e429eF431826d0A32cdc945E1` |
| `weightFees` / `weightToken0` / `weightToken1` | 5000 / 2500 / 2500 |
| `isOutOfRangeIncentivized` | `false` |
| `computeScoreParameters.computeMethod` | `genericTimeWeighted` |
| `amount`, window | 2,142,857.14 TEL, 1793491200 → 1796083140 (2,591,940 s) → **71,428.6 TEL/day, 500,000 TEL/week** |
| blacklist / whitelist / hooks | empty |

Registry on-chain reads (`eth_call` via `mainnet.base.org`, block 54,912,240): `poolAllowed = true`, `inRangeRequired = true`, **`minLiquidity[poolId] = 0`**.

### 1.2 Formula

For position *i* and campaign budget *R* over period *T*, with the eligible set *E(t)* = positions that are **subscribed in the TELx registry AND `tickLower ≤ tick(t) < tickUpper`** at time *t*:

\[
\text{share}_i=\frac{1}{T}\int_0^T\Big[\,0.50\,\frac{L_i(t)}{\sum_{j\in E(t)}L_j(t)}+0.25\,\frac{x^{\text{eUSD}}_i(t)}{\sum_{j\in E(t)}x^{\text{eUSD}}_j(t)}+0.25\,\frac{x^{\text{TEL}}_i(t)}{\sum_{j\in E(t)}x^{\text{TEL}}_j(t)}\Big]\mathbf 1_{i\in E(t)}\,dt,\qquad \text{TEL}_i = \text{share}_i\cdot R
\]

where \(x^{\text{eUSD}}_i, x^{\text{TEL}}_i\) are the token amounts implied by \(L_i\), the range and the current tick (standard v3/v4 `getAmountsForLiquidity`). Merkl's doc wording for the 50% axis is "Liquidity Contribution: time-weighted contribution of a position to the overall liquidity in the pool … what matters is sustained concentration over time, not short-term volume or swap activity" ([Merkl docs, Concentrated Liquidity Campaigns](https://docs.merkl.xyz/merkl-mechanisms/campaign-types/concentrated-liquidity-mechanisms), accessed 2026-11-08).

### 1.3 Empirical validation (campaign window 2026-11-01 00:00 UTC → 11-08 21:20 UTC, 7.89 days)

Method (`analyze.py`): rebuild every position (key = tickLower, tickUpper, salt=tokenId) from 30 days of PoolManager `ModifyLiquidity` logs plus current registry/PosM state; replay the 868 campaign-window swaps; integrate the three shares above; join to the Merkl leaderboard (`/v4/rewards?chainId=8453&campaignId=…`, 60 tokenIds, 554,041 TEL distributed so far).

| tokenId | owner | uptime | TW L share | TW eUSD share | TW TEL share | TW USD in range | predicted share | **actual share** |
|---|---|---|---|---|---|---|---|---|
| 3101576 | 0x3b0b1Ab7 | 100% | 16.8% | 34.0% | 51.1% | $10,869 | 29.67% | **29.83%** |
| 3204934 | 0xd0c50084 | 14.6% | 8.6% | 1.0% | 9.6% | $2,438 | 6.94% | **7.08%** |
| 3189442 | 0xe77D9d02 | 32.5% | 12.3% | 0.3% | 0.9% | $184 | 6.45% | **6.65%** |
| 3186105 | 0x5702a1fa | 20.8% | 6.1% | 10.2% | 0.7% | $2,066 | 5.78% | **5.91%** |
| 3186106 | 0x4041DAFA | 48.2% | 3.0% | 5.1% | 9.2% | $2,095 | 5.06% | **5.13%** |
| 3112297 | 0xa4fF2Ff7 | 100% | 1.5% | 3.1% | 4.6% | $981 | 2.68% | **2.69%** |
| 3165937 | 0xbbe582C6 | 14.6% | 0.9% | 0.01% | 0.02% | $4 | 0.45% | **0.45%** |

Fit over all 60 positions: SSE(50/25/25) = 6.1e-5; SSE(L-only) = 2.4e-2; SSE(value-only) = 2.4e-2. Full table in `internal/edge-data/analysis.json`.

### 1.4 What a position must do to earn each component

| Component | Weight | Earned by | What drives *our* share | Capital scaling |
|---|---|---|---|---|
| Liquidity ("fees") | 50% | being subscribed and in range | **our L ÷ total in-range L**, integrated over time. L per dollar scales ≈ \(1/(1-1/\sqrt{1+r})\) for a symmetric ±r band: ±1.5% → 112×, ±4% → 45×, ±6% → 32×, ±8% → 24×, ±12% → 17×, ±25% → 8× full range (measured at current tick) | **saturating**: share = L/(L+L_others) |
| eUSD holdings | 25% | same | our in-range eUSD ÷ all in-range eUSD (TW ≈ $18.4k in the campaign window) | linear in dollars held in-range |
| TEL holdings | 25% | same | our in-range TEL ÷ all in-range TEL (TW ≈ $12.3k) | linear in dollars held in-range |

### 1.5 What "edge" means under this formula

- **Edge #1 — concentration vs wide capital.** Token axes pay by dollars; the liquidity axis pays by L. Wide/passive LPs (full-range 0x3b0b…, 0x4041…, one-sided 0x5702…) hold ~$27k of the $29k in-range value but only L ≈ 5.8e17. A $2k position at ±6% carries L ≈ 8.6e17. The *marginal* L of concentrated capital is ~30× that of the incumbents, so one small LP can take ~half of the 50% axis.
- **Edge #2 — uptime.** Every second out of range earns 0 on all three axes. Breach frequency scales ≈ σ²/r²; at TEL's volatility this dominates layout choice (§3).
- **Edge #3 — token-side tilt.** $1 of in-range TEL earns 0.25/12.3k vs $1 of eUSD 0.25/18.4k → TEL-heavy in-range inventory is worth ~1.5× per dollar on the token axes *while the $16.6k all-TEL whale (3204934) is out of range*. When the whale is in range (TEL > $0.001457; 37% of the last 7 days, 56% of the last 30), the tilt flips toward eUSD.
- **Edge #4 — avoiding dilution events.** The whale alone (L 1.85e18) triples in-range L when it is active: our liquidity-axis share at ±6% falls from ≈ 50% to ≈ 24%. Nothing to do about it except size expectations (the `no_whale` column in §3 shows the upside if it leaves).
- **Edge #5 — operational: subscribe discipline and the dust-ladder trick (§6).**

---

## 2. Competitive landscape (state at block 54,912,240; tick 341,966 ⇒ 0.0014104 eUSD/TEL)

Source: registry `getSubscribed()` → `getSubscriptionsRaw(owner)` → `getPosition(tokenId)`, PosM `getPositionLiquidity`, StateView tick bitmap + `getTickLiquidity`; confirmed against DexScreener/GeckoTerminal (TVL $46.6k / $46.3k, 24h volume $3.9k).

Active liquidity `getLiquidity(poolId)` = **873,733,903,513,297,729 (8.74e17)**. Sum of subscribed in-range positions = 8.736e17 → **≈ 100% of in-range liquidity is subscribed** (the only unsubscribed in-range position is 0x12d4… with L 2.5e14, $2).

| tokenId | owner | tick range | price range (eUSD/TEL) | L (×1e15) | eUSD | TEL | USD | in range | L share |
|---|---|---|---|---|---|---|---|---|---|
| 3204934 | 0xd0c50084 (“whale”) | 336060–341640 | 0.001457–0.002546 | **1,852.9** | 0 | 11.8M | **16,559** | **no** (all TEL; re-enters at +3.3%) | 0 (212% of current if active) |
| 3101576 | 0x3b0b1Ab7 | 206700–887220 | ~0–1055 (full-range-equivalent) | 145.2 | 5,452 | 3.86M | 10,827 | yes | 16.6% |
| 3206740 | 0x5702a1fa | 341160–483540 | 0–0.001529 (one-sided, eUSD-heavy) | 257.6 | 9,668 | 0.27M | 9,984 | yes | 29.5% |
| 3206123/3207244/3205406 | 0x4041DAFA | full range ×3 | — | 78.5 | 2,950 | 2.09M | 5,861 | yes | 9.0% |
| 3208186 | 0xe77D9d02 (bot) | 341460–342480 | 0.001340–0.001484 (±5%) | 292.9 | 279 | 0.19M | **550** | yes | **33.5%** |
| 3187196 / 3166423 | 0xbbe582C6 (ladder) | 341760–342000 / 342000–342240 | 0.001406–0.001440 / 0.001372–0.001406 | 66.4 / 67.1 | 4 / 30 | 18k / 0 | 30 / 30 | yes / no | 7.6% / 0 |
| 3112297, 3110693, 3160321, 3182568 | 4 small full-range | full range | — | 22.1 | 831 | 0.59M | 1,652 | yes | 2.5% |
| 3204566 | 0x904E6d0F | 337080–344460 | 0.001099–0.002299 | 10.7 | 47 | 62k | 133 | yes | 1.2% |
| + 11 dust slots (L 2e13 each) | 0xbbe582C6 | 240-tick slots 340080…343200 | ladder | 0.2 total | — | — | <$1 | mostly no | 0 |

Totals: in-range USD ≈ **$29.0k** (Merkl shows TVL $30.0k = eligible liquidity only); all subscribed incl. whale ≈ $45.6k.

**Concentration around spot:** of 8.74e17 active L, 3.59e17 (41%) sits in tight bands (±5% bot 0xe77D… and the ±1.2% ladder slot of 0xbbe5…) backed by only ≈ $580; the remaining 59% is ≈ $28k of wide capital. Per dollar, the two tight LPs are ~25–40× more "liquidity-efficient" than the incumbents and 0xe77D… earns ≈ 15.6% of the campaign (≈ 86k TEL ≈ $122 per 7.9 days) on ≈ $550 — the existing proof that the edge is real.

**Behaviour (30-day logs):** 0xe77D9d02 minted 43 tokenIds, 0xe70E5d45 58, 0xbbe582C6 13, 0x5702a1fa 8, 0x4041DAFA ≥ 6 — i.e. 3–4 actively re-centring bots; 0xe77D… routes through the ERC-4337 EntryPoint (`0x5FF137D4…`). The whale's position was minted ~Nov 1 and earned 42% of the 1 Oct campaign under a prior tokenId.

**Reward history (Merkl leaderboards, 5 campaigns):** top position share 29.6–42% every week; 0x3b0b1Ab7 (full-range, $10.9k) has taken 21–31% every week since Oct 1 purely on the token axes.

**Volume / tick movement (PoolManager logs, 30d):** 5,168 swaps (172/day), ≈ $291k volume (eUSD leg), ≈ $845 total LP fees (≈ $200/week vs ≈ $705/week Merkl). Campaign window: 868 swaps, $44k. Price −20% over 30 days (0.00176 → 0.00141), with 0.00124–0.00166 traded on Nov 5 alone.

| Statistic (GeckoTerminal hourly closes, 30d) | Value |
|---|---|
| Hourly σ / daily σ / annualised σ | 1.57% / 7.7% / **147%** (last 7d: 181%) |
| Daily high/low range: median / p75 / max | 6.9% / 8.0% / 33.6% |
| Band breaches per week if re-centred immediately (swap tick path): ±1.5 / 2.5 / 4 / 6 / 8 / 12 / 25% | **43 / 24 / 12.6 / 5.8 / 4.0 / 1.9 / 0.23** |

**Data gaps (honest):** (a) Merkl's exact sampling cadence is not public; the event-driven time-weighting used here matches the leaderboard to ±0.3 pp but could differ during long swap-free gaps. (b) No TELx subgraph was reachable; the position history is reconstructed from logs (positions with no activity in 30 days and not currently subscribed would be missed — none affect the current set). (c) Block→timestamp uses interpolation across 50k-block samples (±2 min). (d) Leaderboard amounts lag the chain by Merkl's root cadence (~hours). (e) Gas measured from 6 recent LP txs at 0.006 gwei; not stress-tested.

---

## 3. Simulation — $2k against the current competitor set

Method (`simulate.py`): replay the actual swap tick path (and swap volumes) over three windows — **last 7d** (Nov 1–8, stress: 33% day), **prev 7d** (Oct 25–Nov 1, calm), **last 30d** — with competitors held at today's set (the OOR whale re-enters whenever tick < 341,640, exactly as on chain). Our positions re-centre when spot leaves the trigger band; on re-centre we pay gas ($0.03; measured mint ≈ 190k gas × 0.006 gwei ≈ $0.003, full 3-burn/3-mint/3-subscribe multicall ≈ $0.02–0.03) plus **0.6% on the inventory that must be swapped** to rebuild the mix (0.3% fee + ~0.3% impact; done off-pool — a $1k swap *in this pool* would move price ≈ 5–6%). "IL + cost" is end value vs HODL of the initial inventory; "fees" is 0.3% × swap volume × our L share. Weekly TEL = share × 500,000.

### 3.1 Static upper bound (price pinned at today's tick, no moves)

| Layout | L share | eUSD / TEL share | Merkl share | TEL/week | $/week |
|---|---|---|---|---|---|
| full-width | 3.0% | 5.0 / 9.1% | 5.0% | 25k | $35 |
| single ±1.5% | 77.4% | 4.3 / 10.3% | **42.4%** | **212k** | $299 |
| single ±4% | 58.0% | 5.0 / 9.1% | 32.5% | 163k | $229 |
| single ±6% | 49.7% | 5.0 / 9.1% | 28.4% | 142k | $200 |
| single ±8% | 42.7% | 5.2 / 8.8% | 24.9% | 124k | $175 |
| straddle A/B/C (build-plan) | 73.0% | 4.5 / 10.0% | 40.1% | 200k | $283 |
| nested ±1.5% + ±4% | 70.6% | 4.7 / 9.7% | 38.9% | 194k | $274 |
| $1000 ±6% core + $1000 ±25% anchor | 38.3% | 5.3 / 8.6% | 22.6% | 113k | $160 |

### 3.2 Replay results, current competitors (TEL/week · share · rebalances/week · IL+cost $/week · **net $/week** incl. fees)

| Layout | last 30d | last 7d (stress) | prev 7d (calm) |
|---|---|---|---|
| full-width | 18k · 3.7% · 0 · −0 · **+26** | 23k · 4.5% · 0 · −0 · **+35** | 21k · 4.2% · 0 · −0 · **+33** |
| single ±1.5% | 139k · 27.8% · 37 · −324 · **−19** | 172k · 34.4% · 63 · −981 · **−658** | 172k · 34.5% · 37 · −575 · **−223** |
| single ±4% | 109k · 21.8% · 12 · −234 · **−0** | 136k · 27.2% · 25 · −654 · **−402** | 132k · 26.3% · 11 · −312 · **−47** |
| single ±6% | 95k · 18.9% · 4.9 · −158 · **+41** | 121k · 24.2% · 8 · −343 · **−120** | 114k · 22.7% · 3 · −127 · **+99** |
| single ±8% | 85k · 16.9% · 2.8 · −124 · **+53** | 106k · 21.3% · 6 · −319 · **−125** | 102k · 20.4% · 1 · −66 · **+134** |
| single ±12% | 69k · 13.9% · 1.2 · −81 · **+61** | 90k · 17.9% · 3 · −251 · **−89** | 81k · 16.1% · 1 · −86 · **+70** |
| **straddle A/B/C** (±1.5 \| −4..+1.5 \| −1.5..+4; 50/25/25) | 108k · 21.6% · 12 · −263 · **−32** | 126k · 25.2% · 25 · −773 · **−532** | 138k · 27.6% · 11 · −383 · **−108** |
| nested ±1.5% + ±4% (50/50) | 110k · 22.1% · 12 · −257 · **−21** | 131k · 26.3% · 25 · −748 · **−499** | 139k · 27.8% · 11 · −367 · **−89** |
| nested ±4% + ±12% (60/40) | 65k · 13.0% · 1.2 · −105 · **+31** | 78k · 15.7% · 3 · −332 · **−186** | 64k · 12.7% · 1 · −130 · **+1** |
| $1000 ±6% core + $1000 full-range, core tracks | 65k · 13.1% · 4.9 · −81 · **+53** | 87k · 17.4% · 8 · −172 · **−14** | 80k · 16.0% · 3 · −64 · **+91** |
| **$1000 ±6% core tracks + $1000 ±25% anchor** | 71k · 14.2% · 4.9 · −93 · **+55** | 98k · 19.6% · 8 · −172 · **+5** | 90k · 17.9% · 3 · −65 · **+110** |
| same, 1h OOR hysteresis on core | 70k · 14.0% · 3.5 · −98 · **+46** | 96k · 19.2% · 5 · −164 · **+10** | 89k · 17.8% · 2 · −51 · **+123** |
| **$1000 ±8% core tracks + $1000 ±25% anchor** | 64k · 12.9% · 2.8 · −75 · **+57** | 88k · 17.5% · 6 · −160 · **−2** | 82k · 16.3% · 1 · −35 · **+123** |
| $700 ±6% core + $1300 ±25% anchor | 62k · 12.5% · 4.9 · −73 · **+55** | 89k · 17.8% · 8 · −121 · **+39** | 80k · 16.1% · 3 · −46 · **+110** |
| $1300 ±6% core + $700 ±25% anchor | 79k · 15.8% · 4.9 · −112 · **+53** | 106k · 21.2% · 8 · −224 · **−30** | 98k · 19.5% · 3 · −84 · **+108** |
| ±6% core, inventory-matched re-centre (no swap) + ±25% anchor | 71k · 14.2% · 25 · −93 · **+55** | 98k · 19.6% · 38 · −193 · **−14** | 91k · 18.1% · 13 · −48 · **+128** |

Reading: gross TEL is monotone in tightness (as the static table predicts) but IL grows faster than share once r < ~6% at this volatility, because **share saturates (L/(L+L_others)) while IL is linear in deployed dollars and ∝ 1/r²**. The build-plan straddle and nested layouts behave like a ±1.5–4% single band: top-3 in TEL, bottom-3 in net P&L. The second bracket in the recommended layout is not a "buffer that catches the price" (that is what the ±4% buffers tried to be) but a **low-IL anchor that earns the token axes and ~8× full-range L continuously**, while a smaller core carries the liquidity-axis bet.

### 3.3 Sensitivity to competitors (30d window; TEL/week · share · net $/week)

| Layout | current | whale leaves (`no_whale`) | 0xe77D re-deploys $550 at ±1.5% tracking | a copycat $2k ±4% tracking bot enters |
|---|---|---|---|---|
| single ±6% | 95k · 18.9% · +41 | 158k · 31.6% · +183 | 72k · 14.3% · −9 | 60k · 12.0% · −34 |
| straddle A/B/C | 108k · 21.6% · −32 | 162k · 32.4% · +90 | 86k · 17.1% · −80 | 73k · 14.7% · −106 |
| $1000 ±6% core + $1000 ±25% anchor | 71k · 14.2% · +55 | 131k · 26.2% · +189 | 53k · 10.5% · +14 | 44k · 8.7% · −5 |
| $1000 ±8% core + $1000 ±25% anchor | 64k · 12.9% · +57 | 122k · 24.4% · +185 | 47k · 9.5% · +20 | 39k · 7.9% · +3 |
| single ±12% | 69k · 13.9% · +61 | 127k · 25.4% · +190 | 51k · 10.2% · +22 | 42k · 8.5% · +3 |

The whale is the biggest single swing (±60–80% of our TEL). One competitor tightening costs us ~25%; a same-size copycat ~35%. Layouts with a wide anchor degrade most gracefully because the token axes are untouched by other LPs' concentration.

### 3.4 Sensitivity to price drift (same layouts, different windows)

Already embedded in §3.2: the stress week (−5.4% close-to-close but 10–33% daily ranges) vs the calm week (+1% drift, 2–8% ranges) moves the ±6% core from 3 to 8 re-centres/week and IL from −$65 to −$172. Over 30 days (−20% drift) the core-tracks layouts still net positive because the anchor rarely re-centres (0.2–0.7×/week).

### 3.5 Cost of being out of range during a move

At ±6%, 64% of excursions return inside the band within 1h and 79% within 6h (30d swap path), so a ~1h hysteresis removes ~40% of re-centres at a cost of ~1–3% uptime (§3.2 rows "1h hysteresis"). Each hour the $1k core is out of range forgoes ≈ 0.5 × 0.5 × (1/168) × 500k ≈ 0.7k TEL ≈ $1; each avoided re-centre saves ≈ $6 swap cost + ≈ 1.5% IL realisation on the core (≈ $15) + resets nothing on Merkl (time-weighting has no memory beyond the current interval). Hysteresis is therefore cheap insurance; **immediate** re-centring is only right for the anchor.

---

## 4. Fees component and the "volume spark"

**Finding.** The 50% axis is time-weighted *liquidity share*, not fee share: (i) Merkl's own documentation says so explicitly ("not short-term volume or swap activity"); (ii) the leaderboard reconstruction in §1.3 uses no swap volumes at all and matches to ±0.3 pp. Even under the alternative reading (share sampled at swap instants), the pool already prints 172 swaps/day, so one more $5 swap changes the sampling by < 0.6% of a day.

**Numbers for a $5 self-swap through our own core:** fee paid 0.3% × $5 = $0.015, of which our L share (≈ 40–50%) returns to us → net fee leakage ≈ $0.008 per spark; gas ≈ 143k–490k (observed UR/4337 swaps) × 0.006 gwei ≈ $0.002–0.007; **Merkl score delta ≈ 0**. At 8 sparks/day the yearly cost is ≈ $30 for zero reward impact.

**Risk.** Merkl's docs list exactly this pattern under "Fake volume attacks detection: Wash trading — creating tight positions and self-trading to earn rewards … Frequent rebalancing: if mistaken for wash trading, may trigger blacklisting." A blacklisting of the LP address forfeits the whole ≈ $100–150/week.

**Recommendation: do not build Phase 4; keep `NoopSpark`.** Fee income is still worth modelling for P&L (≈ $40–65/week at 30–45% L share from genuine flow, §3.2) but it comes from other people's swaps, not ours.

---

## 5. Rebalance policy

Constraint: a new position can only be subscribed while in range (`PositionRegistry._index` reverts `OutOfRange`; checked **only at subscribe**; a subscribed position that drifts out of range stays subscribed and simply earns 0 until it is back — source: Sourcify-verified `PositionRegistry.sol`, `pruneSubscription` only acts on transfer/burn or liquidity below `minLiquidity`, which is 0 here).

Widths below are given in ticks (multiples of `tickSpacing = 60`) as the mechanics doc requires (D2); tick ↑ = TEL cheaper; `1.0001^600 − 1 = 6.18%`, `^780 = 8.11%`, `^2220 = 24.9%`.

| Rule | Recommendation | Basis |
|---|---|---|
| Core width | **`coreHalf = 600` t (±6.18%)** default; `780` t (±8.11%) when 7-day realised vol > 170% annualised | §3.2: ±6–8% is the net-P&L plateau in all windows; ±4% is breached 12.6×/week |
| Core trigger | spot outside the core band for **≥ 60 min** (or ≥ 200 t ≈ 2% beyond the edge immediately) → re-centre the core only | 64% of ±6% excursions revert within 1h; immediate re-centring at ±6% costs ≈ $20–25 per event in IL + swap |
| Core re-centre shape | **inventory-matched**: choose the new ±6%-wide band offset so its token mix equals what we hold (after a drop we hold TEL → band mostly above spot); no swap. Fall back to a 50/50 band + off-pool swap only if the match would leave < 1% on the near side | §3.2 inventory-matched rows: same TEL, ≈ 0 swap cost; slightly more re-centres |
| Anchor width | **`anchorHalf = 2220` t (±24.9%)** | breached 0.23×/week over 30d; still 8× full-range L |
| Anchor trigger | spot within 300 t (≈ 3%) of an anchor edge → re-centre anchor **immediately** (so it never sits out of range, since it cannot be re-subscribed out of range) | the anchor is the uptime floor |
| Cadence / caps | expect **3–6 core re-centres/week**, 0–1 anchor; `maxRebalancesPerWeek` = 12 hard, `maxRebalancesPerDay` = 3 soft, `minTimeBetweenRebalances` = 2 h (not 3–5/week and 6 h — those would strand the core for days in a week like Nov 1–8) | §2 breach table; 0xe77D… runs 40+ re-mints/month without a blacklist |
| Staging slots (dust ladder) | when the core is minted, also mint+subscribe **dust (L = 1e13–2e13) positions for the next ±6% slot on each side if they contain spot**; later entry is `increaseLiquidity`, not mint+subscribe | enabled by `minLiquidity = 0` and subscribe-time-only range check; 0xbbe5… does this today with 13 slots |
| Don't | mint one-sided B/C buffers (unsubscribable); re-centre on every tick; swap inside this pool for inventory (≈ 5–6% impact per $1k) | §3, build-plan §1.1 |

Poll interval: a 2 s fast poll or 8–15 s both work (172 swaps/day; a 1h hysteresis makes sub-minute latency irrelevant except for the anchor's 3% margin). Note: Base block time is ≈ 0.2 s since ~2026-11-06 (2 s before), so cadences are specified in seconds, never in blocks — see `measure-rebalance-mechanics.md` D10.

---

## 6. Reconciliation with `measure-rebalance-mechanics.md` §8

Inputs received from the mechanics worker (block 54,911,993) and how this analysis answers them. Agreements first, then the one material disagreement.

**Agreed (independently verified here):** TEL v3 = 18 dec, eUSD = 6 dec, currency0 = eUSD, tick ↑ = TEL cheaper (all math in this doc uses that); the 50% axis is time-weighted active-tick liquidity share (§1.3 proves it against the leaderboard, so D4 is settled, not just documented); in-range is checked only at `handleSubscribe`, `INCREASE_LIQUIDITY` on a subscribed NFT needs no re-subscribe, `_meetsMinimum` is false at L = 0 (dust floor needed); the pool is thin (their "$100 ≈ 56 t" and this doc's "$1k ≈ 5–6%" are the same depth); the $16.6k–22.7k all-TEL wall is position 3204934 (0xd0c5…, 336060–341640, L 1.85e18) — "3.2% below spot" in tick space = TEL +3.3% in price; valued here at 11.8M TEL × $0.00141 = $16.6k (their $22.7k presumably uses a different TEL mark or amount basis; same object, same conclusion: it triples active L when TEL rallies 3.3%).

**Disagreement — volatility and swap activity are understated ≈ 10–30× in the mechanics doc, and its thresholds inherit that.**

| Quantity | mechanics doc (§0.1 / §2.3) | this doc (30-day PoolManager log scan, 5,168 swaps; GeckoTerminal/DexScreener cross-check) |
|---|---|---|
| Swaps, 7 d | 25, ≈ $2.1k | **805, ≈ $43k** (DexScreener 24h: 36 txns, $3.9k; GeckoTerminal daily volumes Nov 2–8 sum to $43k) |
| 1-h σ | 15–25 t | **≈ 156 t (1.57%)**; daily σ 7.7%; 147% annualised (181% last 7 d) |
| Daily tick range | 10–160 t | **444–2,899 t** on Nov 1–8 (Nov 5: 2,899 t = 33.6%); 30-d median 6.9% ≈ 670 t |
| Drift, 7 d | +478 t | +263 t close-to-close over the exact last 7 d (path 341,703 → 341,966); direction agrees, but drift is small versus σ√t ≈ 156·√168 ≈ 2,000 t — hitting times are vol-driven, not drift-driven |

Likely cause: a log scan limited to a sub-window (Oct 31 alone had exactly 25 swaps and a 115-t range in this data set).

| §8 item | Answer from this analysis |
|---|---|
| **R1 Thresholds** | Replace the `Geometry`/`Thresholds` defaults as follows. `coreHalf 180 → 600` t; `outerHalf 420 → 2220` t and change its role from "straddle buffer" to **anchor** (it is never emptied for a core move, only re-centred when spot is within 300 t of its own edge). Weights `0.5/0.25/0.25 → core 0.5, anchor 0.5` (two brackets, not three; the one-sided straddles B/C are dominated — §3.2 straddle row is net-negative in all three windows). `warnTicks 120 / armTicks 60` are inside one hour of noise (σ_1h ≈ 156 t) → use **`hard` only (outside the core) with `dwellHardS = 3600`**, plus an immediate path when spot is ≥ 200 t beyond the edge; drop `earlyRecenter` for the core (hitting time is vol-dominated), keep it for the anchor with the 300-t margin. `minTimeBetweenRebalancesS 21600 → 7200`; `maxRebalancesPerDay 2 → 3 (soft)`; `maxRebalancesPerWeek 5 → 12 (hard)` — at `coreHalf 180/outerHalf 420` the envelope is breached ≈ 12.6×/week, so a 5/week cap is exhausted by mid-week and the book sits out of range earning 0. `minSlotAgeS 7200` fine. `evMultiple 3` fine. `maxInPoolSwapUsd 100` fine; prefer inventory-matched re-centring (§5) so the swap path is rarely used. |
| **R2 Token denominator** | **In-range only.** The §1.3 reconstruction uses in-range denominators and matches all 60 leaderboard entries to ±0.3 pp; with whole-pool denominators (adding the whale's 11.8M TEL) the full-range position 3101576's TEL share would fall from 51% to ≈ 24% and its predicted share from 29.7% to ≈ 23% vs an actual 29.8%. `tok0ShareLB/tok1ShareLB` can be dropped. |
| **R3 Spark** | Do not build; keep `NoopSpark` permanently (§4). The axis does not depend on swaps and Merkl names self-trading as a blacklist trigger. |
| **R4 Parked dust slots** | Evidence that Merkl pays them: 0xbbe582C6 runs 13 dust/ladder slots (L 2e13) and its refilled slots (3165937, 3187072, 3163255) appear on the live leaderboard with actual = predicted share. No sign of penalty after ≥ 30 days. Keep `dustL ≥ 1e13`, `maxParkedSlots 3` is conservative; 5–7 is fine given no per-owner cap in the registry. Canary still confirms. |
| **R5 PosM/UR pinning** | Out of scope here; nothing in this analysis depends on opcode layout. |
| **R6 Reserve** | **No idle reserve (reserveTargetUsd → 0).** Every idle dollar costs linearly on the 25/25 axes with nothing in return (§3.2 "idle reserve" rows: $1k idle costs ≈ 6 pp of share ≈ 30k TEL/week vs the same dollars in a ±25% anchor). The ±25% anchor *is* the inventory buffer: it holds both tokens at all times and a `DECREASE` on it funds a core refill without an external swap; inventory-matched core re-centring (§5) removes most swap needs anyway. Keep `swapToleranceUsd 150`. |
| **R7 UR address** | Not needed if the spark is dropped and ratio swaps go through the anchor; verify only if the external-swap fallback is kept. |

---

## 7. Ranked structural sources of edge

| # | Source | Expected impact (vs a $2k full-range LP earning ≈ 18–25k TEL/week) | How to capture |
|---|---|---|---|
| 1 | **Concentration against wide passive capital** on the 50% liquidity axis | +45k to +90k TEL/week (full-range 3.7% → 13–19% share) | ±6–8% core, §5 |
| 2 | **Uptime and IL discipline** (right width + hysteresis + anchor) | the difference between −$30…−$660/week and +$5…+$125/week net at the *same* gross TEL | core + ±25% anchor, 1h hysteresis, caps |
| 3 | **Pre-subscribed dust ladder** (subscribe-time-only range check, `minLiquidity = 0`) | removes the `OutOfRange` blocker from build-plan §1.1; cuts re-centre to one `increaseLiquidity`/`decreaseLiquidity` pair; keeps long-lived tokenIds (lower Merkl "frequent rebalancing" profile) | mint dust slots when they contain spot; top up later |
| 4 | **Token-side tilt** toward the scarcer in-range token (TEL while the whale is OOR, eUSD when it is in) | ≈ +1–2 pp share (≈ 5–10k TEL/week) from the 25/25 axes at no extra IL | choose asymmetric offset at each core re-centre (coincides with inventory matching after a drop) |
| 5 | **Fee income from genuine flow** (not Merkl) | ≈ $40–65/week at 30–45% L share | by-product of #1; do not spark |

Anti-edges to avoid: tight single bands / the build-plan straddle at this volatility (gross-optimal, net-negative); volume spark (zero effect, blacklist tail); re-centring inside the pool (5–6% impact).

**What to do first**

1. Freeze the layout decision in `build-plan.md` §1.1 as: *core ±6% ($1k, inventory-matched re-centre, 1h hysteresis) + anchor ±25% ($1k, immediate re-centre at 3% margin) + dust staging slots*. Drop one-sided B/C.
2. Phase 1 planner: implement `planCore(tick, inventory)` (offset search so token mix ≈ inventory), `planAnchor(tick)`, dust-slot planner; property-test that every minted range contains spot.
3. Phase 2 fork tests: add "increaseLiquidity on an out-of-range but subscribed dust position, then move price into it → `isInRange` true, no re-subscribe needed", and "subscribe dust slot while in range, L = 2e13".
4. Phase 5 canary ($100): confirm (a) Merkl pays a topped-up ladder slot on re-entry (0xbbe5…'s leaderboard entries say yes), (b) no blacklist after a week of 3–6 re-centres.
5. Re-run `simulate.py` weekly with the fresh competitor set; if the whale leaves, widen expectations; if a second tight bot appears, consider ±8%.

**Remaining unknowns**

- Merkl's exact sampling cadence and whether very long swap-free gaps are handled identically (fit is ±0.3 pp; not a proof).
- Merkl "frequent rebalancing" heuristic thresholds — 0xe77D… survives 40+ re-mints/month today, but the rule is undocumented.
- Whether TELx will raise `minLiquidity` above 0 (would break the dust ladder; `belowSubscriptionThreshold` would then let anyone prune the slots).
- The whale's intentions (its $16.6k of TEL at 0.001457–0.002546 is the main dilution risk) and whether 0x3b0b… ($10.9k full range) ever concentrates.
- TEL volatility regime: all net-P&L numbers assume 147–181% annualised vol; at 80% vol a ±4% core would become optimal.

---

## 8. Sources

| Item | How obtained | Accessed |
|---|---|---|
| Campaign params, opportunity TVL/APR | `https://api.merkl.xyz/v4/opportunities/16270260351359923751?campaigns=true`, `/v4/campaigns?chainId=8453&campaignId=0x9d7d…` | 2026-11-08 |
| Leaderboards (5 campaigns) | `https://api.merkl.xyz/v4/rewards?chainId=8453&campaignId=<id>&items=200` | 2026-11-08 |
| Merkl scoring semantics, wash-trading / rebalancing blacklist | https://docs.merkl.xyz/merkl-mechanisms/campaign-types/concentrated-liquidity-mechanisms | 2026-11-08 |
| Pool state, tick bitmap, tick liquidity | StateView `0xa3c0…a71` `getSlot0/getLiquidity/getTickBitmap/getTickLiquidity` via `https://mainnet.base.org`, block 54,912,240 | 2026-11-08 |
| Subscriptions, ranges, eligibility, `minLiquidity`, `inRangeRequired` | PositionRegistry `0xcebC…45E1` (`getSubscribed`, `getSubscriptionsRaw`, `getPosition`, `isInRange`, …), PosM `0x7C5f…9bDc` (`getPositionLiquidity`, `ownerOf`, `subscriber`) | 2026-11-08 |
| Registry source (`_index`, `pruneSubscription`, `_isInRange`) | Sourcify `/server/v2/contract/8453/0xcebC…?fields=sources` | 2026-11-08 |
| Swap / ModifyLiquidity history (30d) | PoolManager `0x4985…2b2b` logs, topics `Swap`/`ModifyLiquidity` + poolId, via `https://base-rpc.publicnode.com` (50k-block chunks; ≈ 2.8 h per chunk at 0.2 s/block, ≈ 28 h at the earlier 2 s — `block-timestamps.json` carries real per-chunk timestamps, see `measure-rebalance-mechanics.md` D10) | 2026-11-08 |
| OHLCV, volume, TVL cross-check | GeckoTerminal `/api/v2/networks/base/pools/<poolId>` (+`/ohlcv/hour`, `/ohlcv/day`), DexScreener `/latest/dex/pairs/base/<poolId>` | 2026-11-08 |
| Gas | receipts of 6 recent PosM/UR txs (`gasUsed` 121k–434k, 0.006 gwei; L1 fee ≈ 1e-9 ETH), ETH ≈ $2,227 (GeckoTerminal native price) | 2026-11-08 |

## 9. Data and scripts (`/cursor/stores/bc-01a1bcd2-3013-7934-9c8a-85bdaadc427d/internal/edge-data/`)

| File | Content |
|---|---|
| `scan_logs.py` → `logs-30d.jsonl` | 5,646 decoded Swap/ModifyLiquidity logs, 30 days |
| `read_state.py` → `state.json` | slot0, active L, 29 initialised ticks, 12 eligible subscribed positions, registry params |
| `analyze.py` → `analysis.json`, `block-timestamps.json` | position reconstruction, leaderboard validation, tick path with volumes, TW in-range totals |
| `simulate.py` → `sim-results.json`, `sim-output.txt` | 34 layouts × 3 windows × 4 competitor scenarios + static bound |
| `tick_stats.py` → `tick-stats.json` | vol, daily ranges, breach rates, excursion return times, whale in-range fraction |
| `merkl-*.json`, `gecko-*.json`, `dexscreener-*.json`, `registry-*.json`, `PositionRegistryImpl.sol`, `merkl-doc-*.txt` | raw API / source snapshots |
