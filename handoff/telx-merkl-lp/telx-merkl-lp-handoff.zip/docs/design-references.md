# TELx Merkl LP Bot — Design References

**Audience:** future developers of the staggered-bracket Uniswap v4 LP bot on Base.  
**Status:** consolidated from four internal research briefs. No new deep research.  
**Related:** [`project-context.md`](./project-context.md), [`bot-blueprint.md`](./bot-blueprint.md).

> **Merkl / TELx rules status (verified 2026-11-08):** Live Merkl Base campaigns do **not** use the Essential Guide’s Passive/Active/JIT period classifier. That classifier still exists on the **legacy** registry; Merkl’s `subscriptionContract` is a newer registry without those levers. See [`telx-merkl-reward-rules.md`](./telx-merkl-reward-rules.md). Keep Merkl platform anti-gaming blacklist risk in mind for aggressive same-block churn; treat atomic vs staged rebalance as configurable ops policy.

---

## 1. Purpose and how to use this doc

This handbook digests four external repos into borrow / avoid guidance for our bot:

| Goal of our bot | What these repos are for |
|-----------------|--------------------------|
| PosM NFT brackets + TELx `subscribe` | Atomicity / unlock literacy, not product forks |
| Rare volume-spark keep-alive | Swap encoding ideas only — not wash loops |
| Off-chain plan → on-chain execute | Control-plane pattern (Automan lineage) |
| Avoid Merkl-hostile churn | JIT hook as a **negative** catalog |

**How to use**

1. Skim §2–§4 before designing modules.
2. Open a §5 one-pager only when implementing that surface (discovery, unlock, spark, hooks).
3. Follow the linked internal brief for file-level depth; reimplement ideas clean-room — do not vendor unclear licenses.
4. Re-check §6 and live TELx campaign docs before locking rebalance policy (atomic vs staged).

**Out of scope here:** production ABIs, live addresses beyond blueprint placeholders, MEV/arb implementation, wash-trading runbooks.

---

## 2. Repo scorecard

| Repo | URL | Maturity | License | Relevance |
|------|-----|----------|---------|-----------|
| joymadhu49/volume-bot | https://github.com/joymadhu49/volume-bot | Early personal prototype; ~14 commits; idle since 2026-03 | **None** (treat as all-rights-reserved) | **Med** — Base v4 UR + PoolKey discovery / spark encoding ideas |
| pixelis0x/UniV4-AtomicArbitrage | https://github.com/pixelis0x/UniV4-AtomicArbitrage | 2024 research demo; Goerli / stale v4 pins; not production | MIT root; `AtomicArbRouter.sol` header **UNLICENSED** (inconsistent) | **High** — unlock + flash-accounting atomic multi-ops mental model |
| Aperture-Finance/uniswap-v4-hooks | https://github.com/Aperture-Finance/uniswap-v4-hooks | README-only 2023 brainstorm; no Solidity | **None** | **Low** (target repo) — **High** for adjacent Automan / Lens *patterns* only |
| LamsyA/JIT-UNISWAP-V4-HOOK | https://github.com/LamsyA/JIT-UNISWAP-V4-HOOK | Hackathon/prototype; dormant since 2024-09 | README MIT; no `LICENSE` file | **Med** — **negative** reference for same-tx add/remove; light PoolManager literacy |

**Adjacent (not scored as primary inputs, cited in Aperture brief):**

| Repo | Why mentioned |
|------|----------------|
| [uniswap-v3-automan](https://github.com/Aperture-Finance/uniswap-v3-automan) | Real off-chain + periphery LP automation (v3/SlipStream, Base params) |
| [Aperture-Lens](https://github.com/Aperture-Finance/Aperture-Lens) | Ephemeral V4 position/tick reads (Apache-2.0) |

---

## 3. Cross-cutting patterns to borrow

### PosM / unlock / atomic inventory

- Uniswap v4 atomicity = **one `PoolManager.unlock` session** with flash accounting (EIP-1153): multiple ops, net deltas, then `settle` / `take`.
- Prefer **PositionManager** `modifyLiquidities` / packed `Actions` (BURN/DECREASE → MINT/INCREASE → SETTLE/TAKE/SWEEP) over a custom unlock router. Custom router only if PosM + TELx `subscribe` cannot be composed.
- Encode planned burns/mints in one intent struct; assert **delta invariants** before unlock completes (no unexpected leftover currency).
- TELx `subscribe` lives **outside** PoolManager — wrap PosM + IncentiveController in the same user tx (outer multicall / executor) when policy allows. Mint alone does not earn; new `tokenId`s need subscribe in the same operational window.
- Keep NFT **owner stable** (approvals/permits, not transfers — transfer unsubscribes per blueprint).

### Volume-spark restraint

- Physical primitive from volume-bot: tiny Universal Router (or SwapRouter) exact-in through **in-range core** ticks.
- Policy inversion: gate on idle (`no_volume_duration > 3h`), negligible size, non-zero `amountOutMinimum`, gas cap, simulate-before-send — **not** continuous 10–60s wash.
- Sparks are swaps, not liquidity mods — still verify against live Merkl attribution rules before assuming they are cooldown-safe.
- Never couple spark and rebalance into one aggressive same-block add/remove bundle.

### Off-chain automation vs hooks

- Aperture’s shipped model wins for TELx: **decide off-chain → act via periphery**. Automan-style `_rebalance`: remove → optional ratio swap → mint **new** NFT → preserve owner.
- Do **not** put rebalance / compound in `afterSwap` hooks on TELx pools (taxes swappers, couples strategy to every trade, cannot own TELx subscribe cleanly).
- Consume official TELx `PoolKey.hooks`; do not deploy automation or JIT hooks onto those pools.
- Bot owns breach detection, cooldown clocks, capital splits, simulation, and verification; chain path is “execute planned bundle.”

### Config / discovery

- Persist full **PoolKey** (`currency0/1`, `fee`, `tickSpacing`, `hooks`) per pool; support **manual override**.
- Discovery order: StateView `slot0` probe grid over known fee/spacing (+ known TELx hooks) → optional chunked `Initialize` log scan → write `pools.base.yaml`. Prefer StateView over calling `getSlot0` on PoolManager (volume-bot cautionary tale).
- Single module owns Base addresses + ABIs; schema-validate config (zod/TOML).
- Serialize all wallet sends through one **nonce/mutex** queue (monitor + spark + rebalance race).
- Soft kill switch (env/file) checked every loop; structured logs with Basescan links.
- Inventory reads: StateView + optional ephemeral lens-style batch readers (Aperture-Lens pattern).

---

## 4. Patterns to avoid

| Pattern | Source | Why |
|---------|--------|-----|
| Continuous wash-trading buy/sell loops | volume-bot | Gas burn, wash optics; opposite of rare keep-alive |
| `amountOutMinimum = 0`, no simulate | volume-bot | Production capital defect |
| Plaintext / default-passphrase key custody, open Telegram control | volume-bot | Wrong ops model for a single-ops vault |
| Cross-pool arb, initiator bounty, `donate` profit, fee-override hooks | AtomicArbitrage | Wrong product; not Merkl LP |
| Subclassing `PoolTestBase` / Goerli / stale 2024 submodule pins for prod | AtomicArbitrage | Use audited Base periphery |
| Assuming unlock alone = burn+mint+subscribe | AtomicArbitrage | Subscribe is a separate contract |
| In-hook / `afterSwap` rebalance or limit orders | Aperture v4-hooks README | Trader-gas tax; fights cooldown-friendly design |
| JIT fee-redistribution / MasterChef-in-hook | Aperture README | Orthogonal to Merkl TIR; not TELx’s mechanism |
| Hook-owned liquidity (HOL) as LP custody | Aperture README | Subscribe/ownership complexity; unnecessary at ~$2k scale |
| **Same-tx / same-block liquidity add then remove** (beforeSwap add → afterSwap remove) | JIT hook | Textbook JIT shape — **if Merkl still zero-weights this class, it destroys reward share** |
| Hook-owned ephemeral PM positions (`salt: 0`) instead of PosM NFTs | JIT hook | Not TELx-subscribable |
| Rebalance on “large swap” detection / every tick | JIT hook | Thrash; opposite of outer-buffer + cooldown gating |
| Vendor unclear-license source verbatim | volume-bot, Aperture hooks, JIT packaging gaps | Clean-room ideas; license review before copy (esp. Automan BUSL) |

**Conditional (Merkl platform anti-gaming — still relevant):**

- Live TELx Merkl campaigns do not apply the old Passive/JIT period weights; residual risk is Merkl’s platform JIT/wash blacklist and TIR reset on new NFTs.
- Prefer genuine outer-buffer re-centering over swap-sandwich liquidity; keep `rebalanceMode` configurable.
- Fee claims: reconfirm whether they count as liquidity mods — keep claim path separate unless verified safe to bundle.

---

## 5. Per-repo one-pagers

### 5.1 joymadhu49/volume-bot

**What it is:** Node/ethers “auto volume” bot for Base Uniswap v4 (Clanker/WETH-centric): randomized buy/sell via Universal Router. No LP, PosM, or Merkl.

**Steal (ideas):** PoolKey persistence + manual override; combinatorial probe then log-scan discovery; UR wrap/swap/unwrap for sparks; Permit2 allowance check; nonce queue; chain adapter vs orchestrator split.

**Reject:** Continuous wash loop; zero slippage; WETH-only assumptions; Telegram multi-user key store; Clanker-first discovery as TELx source of truth.

**Depth:** [`internal/ref-volume-bot.md`](../internal/ref-volume-bot.md)

---

### 5.2 pixelis0x/UniV4-AtomicArbitrage

**What it is:** Foundry “TheEqualizer” demo — atomic cross-pool swaps inside one `unlock`, optional discounted-fee hook, profit `donate`. Teaching sample for flash accounting, not an LP rebalancer.

**Steal:** `unlock` → callback → N PoolManager ops → settle/take; flash netting so burn credits fund mint debits; post-op delta asserts; Cancun/Foundry test posture; PoolKey discipline.

**Reject:** Arb sizing, donate, privileged fee hooks, `PoolTestBase` production use, treating the repo as a Merkl/subscribe reference.

**Depth:** [`internal/ref-univ4-atomic-arbitrage.md`](../internal/ref-univ4-atomic-arbitrage.md)

---

### 5.3 Aperture-Finance/uniswap-v4-hooks (+ Automan / Lens)

**What it is:** Target repo = 2023 README of three hook *ideas* (JIT fee equity, in-hook automation, HOL permissions) — **no code**. Useful lineage is **uniswap-v3-automan** (off-chain + periphery rebalance) and **Aperture-Lens** (V4 read helpers).

**Steal:** Off-chain condition engine + allowlisted executor; rebalance = remove → ratio swap → mint new NFT, preserve owner; position lineage `oldTokenId → newTokenIds[]`; ephemeral V4 inventory reads; OptimalSwap *idea* only (license review before Solidity copy).

**Reject:** Implementing the README hooks; `afterSwap` automation; HOL for this bot; assuming a Base v4 Automan exists (it does not publicly).

**Depth:** [`internal/ref-aperture-v4-hooks.md`](../internal/ref-aperture-v4-hooks.md)

---

### 5.4 LamsyA/JIT-UNISWAP-V4-HOOK

**What it is:** Educational JIT hook — vault inventory, `beforeSwap` add narrow band, `afterSwap` remove. Hook-owned PM liquidity; no PosM/Merkl.

**Steal (generic only):** Slot0/liquidity reads; tick-spacing snap (rewrite + test); LiquidityAmounts sizing; settle/take literacy; Foundry Deployers multi-range fixtures for **durable** A/B/C brackets in tests.

**Reject / defensive:** Any beforeSwap-add / afterSwap-remove machine; ephemeral hook positions; large-swap-triggered rebalance. **If Merkl still penalizes same-block add/remove, treat this repo’s lifecycle as a hard anti-pattern for rewarded LP.**

**Depth:** [`internal/ref-jit-uniswap-v4-hook.md`](../internal/ref-jit-uniswap-v4-hook.md)

---

## 6. Open questions / contested assumptions

| Topic | Status | Implication |
|-------|--------|-------------|
| TELx still Passive-only (≤1 modify / ~24h, Base 43_200 blocks)? | **Stale for live Merkl path** (verified 2026-11-08) | Optional soft cooldown only; see [`telx-merkl-reward-rules.md`](./telx-merkl-reward-rules.md) |
| Same-block burn+mint still JIT-zeroed by TELx weights? | **No on live Merkl path**; Merkl platform blacklist still possible | Atomic PosM + subscribe OK as default capital-safe mode; keep staged mode |
| Active (second modify inside window) still zeros remainder of period? | **No on live Merkl path** (legacy registry only) | No hard Passive clock required for Merkl scoring |
| Min size 1 bp of pool liquidity / auto-unsubscribe | Blueprint claim — reconfirm live | Post-tx verify sizes before assuming subscribed |
| Fee claims count as liquidity modifications? | Blueprint FAQ note (2025-11-28) — reconfirm | Prefer separate claim path |
| Volume-spark swaps affect Passive clocks / attribution? | Unverified in briefs | Gate + size sparks; do not assume “swaps are free” vs Merkl |
| TELx IncentiveController ABI: `subscribe(tokenIds)` multicall-friendly? | Placeholder | Confirm caller auth + same-tx composition with PosM |
| Official TELx pool keys / hooks / IncentiveController on Base | Placeholders in blueprint | Pull from TELx docs + Basescan at implement time |
| Custom unlock router vs PosM-only | Open engineering choice | Prefer PosM; custom only if subscribe composition fails |
| OptimalSwap / Automan code reuse | License (BUSL) | Ideas OK; legal review before vendoring Solidity |
| volume-bot / JIT / Aperture-hooks code reuse | No or incomplete LICENSE | Clean-room only |

---

## Appendix — alignment with bot goals

| Blueprint theme | Digest stance |
|-----------------|---------------|
| Staggered A/B/C brackets, breach-only rebalance | Reinforced; ignore micro-tick and large-swap triggers from JIT/volume repos |
| Atomic burn → mint → subscribe | Borrow unlock/PosM atomicity; **subscribe outside PM**; atomic default OK under live Merkl; keep staged mode for ops risk |
| Volume-spark keep-alive | Borrow UR spark mechanics; reject wash cadence |
| TS + viem + StateView + PosM | Compatible with all four briefs’ “use official periphery” advice |
| No custom pool hooks | Explicit across Aperture + JIT avoid lists |
