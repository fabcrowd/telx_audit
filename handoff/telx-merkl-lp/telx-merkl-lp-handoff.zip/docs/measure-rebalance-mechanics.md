# TELx Merkl LP Bot — Measurement & Rebalance Mechanics (eUSD/TEL, Uniswap v4, Base)

**Status:** design only — interfaces + pseudo-code, no runnable bot, no keys, no live transactions.  
**Date:** 2026-11-08 (on-chain snapshot at Base block 54,911,993).  
**Scope:** how the bot *measures* the eUSD/TEL v4 pool and *rebalances* ~$2k across multiple subscribed brackets to maximise its share of the fixed weekly Merkl TEL budget (subscribed + in-range liquidity; 50% liquidity-contribution / 25% token0 / 25% token1; time-weighted).  
**Related:** [`bot-blueprint.md`](./bot-blueprint.md) (addresses, PoolKey, subscribe pattern) · [`build-plan.md`](./build-plan.md) (module layout, phases, §1.1 straddle proposal) · [`telx-merkl-reward-rules.md`](./telx-merkl-reward-rules.md) · [`design-references.md`](./design-references.md) · [`edge-strategy.md`](./edge-strategy.md) (**layout, thresholds and volatility inputs adopted from its §5–§6 on 2026-11-08** — see D10–D15 and §8).

---

## 0. Deltas vs blueprint / build plan

This document does **not** edit the blueprint. Where it supersedes it:

| # | Blueprint / build-plan statement | This doc | Why |
|---|------------------------------------|----------|-----|
| D1 | Task brief said "TEL 2 decimals, eUSD 18" | **TEL v3 = 18 dec, eUSD = 6 dec** (verified `decimals()` on-chain, this pass). Blueprint §1 was already right. `currency0 = eUSD`, `currency1 = TEL`; `price = token1/token0 = TEL per eUSD`, tick **up** = TEL **cheaper**. | 2-dec TEL is the legacy Ethereum/Polygon token, not Base TEL v3. |
| D2 | Widths in percent (±1.5% / ±4%) | Widths in **ticks, multiples of 60**: **core ±600 (±6.18%)**, **anchor ±2220 (±24.9%)** (per `edge-strategy.md` §5; 1.5% is not representable anyway — 120 t = 1.21%, 180 t = 1.82%). | tickSpacing 60; realised vol (D10) |
| D3 | Rebalance = BURN all + MINT all + subscribe all, every time (§5) | **Slot model:** brackets are persistent subscribed NFTs; move liquidity with `DECREASE_LIQUIDITY` / `INCREASE_LIQUIDITY` whenever the target range already has a subscribed slot; `BURN`/`MINT`+`subscribe` only for ranges with no slot. | Verified: registry `notifyModifyLiquidity` is a no-op, in-range is checked **only at `handleSubscribe`**, so an existing subscribed slot can be refilled when it is in range without re-subscribing; also removes the `nextTokenId` race for refills. Two live competitors already operate this way (see §1.7). |
| D4 | "Zero volume hurts fee-weighted Merkl scores"; volume spark justified by fee axis | Merkl docs (fetched 2026-11-08): the 50% axis is **time-weighted share of liquidity at the active tick** ("sustained concentration over time, not short-term volume or swap activity"). Our share accrues with **zero swaps**. **Volume spark: not built — `NoopSpark` is permanent**, not a default (edge-strategy §4 reproduces the Merkl leaderboard to ±0.3 pp with no swap data; a $5 self-swap changes the score by ≈ 0 and Merkl names self-trading as a blacklist trigger). | Merkl "Concentrated Liquidity Campaigns" page; edge-strategy §1.3/§4 |
| D5 | `minLiquidity[poolId]` unknown | **`minLiquidity[eUSD/TEL] = 0`**, `poolAllowed = true`, `inRangeRequired = true` (read 2026-11-08). But `_meetsMinimum` returns **false for L = 0** → an emptied slot is prunable by anyone. Keep a dust floor `L ≥ dustL` in parked slots. | registry source (Sourcify) |
| D6 | `breachMarginTicks: 10` single trigger | **Core:** hard trigger (spot outside the core band) held for **60 min**, or immediately when ≥ 200 t beyond the edge; **anchor:** re-centre immediately when spot is within 300 t of an anchor edge. Cooldown 2 h, caps 3/day soft, 12/week hard, EV gate (§3). The earlier warn/arm/velocity bands were inside one hour of noise (1-h σ ≈ 156 t) and are dropped. | edge-strategy §3.5/§5: 64% of ±6% excursions return within 1 h; Merkl "frequent rebalancing" note |
| D7 | Ratio swap "through Universal Router in the same bundle" left open | Not possible atomically with burn+subscribe: UR `V4_POSITION_MANAGER_CALL` rejects `DECREASE`/`BURN`/`INCREASE` (`OnlyMintAllowed`) and cannot call `subscribe`. §4.4: **inventory-matched core re-centring (no swap) is the default**; anchor `DECREASE` funds any residual; external swap only as a rare fallback. Pool is so thin that a **$100 swap moves spot ~56 ticks (0.56%)**; never swap for inventory inside this pool. | UR source `V3ToV4Migrator._checkV4PositionManagerCall`; on-chain L; edge-strategy §5 |
| D8 | Poll 5–15 s; single RPC | **Low-RPC profile is the default** (§1.2): slot0+liquidity every 12 s via one `multicall3` call, our positions/registry every 60 s or on a `Swap` log, competitor map every 12 min, `Swap` logs by `eth_getLogs` polling — ≈ **500 requests/h**, fits every free tier with ≥ 60% headroom. A 2 s fast-poll profile exists as **opt-in**. Free-tier providers + public-endpoint rotation with per-endpoint rate limiting and health scoring (§1.9); **no paid RPC**. | user constraint; sampling latency is irrelevant to a 60-min dwell |
| D9 | — | Pool has **protocol fee on**: `protocolFee = 2048500` = 500 pips (0.05%) both directions, taken before the 0.3% LP fee. Fee-APR maths must use `lpFee` on post-protocol-fee input. | slot0 read |
| D10 | Blueprint, build-plan, edge-strategy and the first draft of this doc all assumed **Base block time = 2 s** | **Base block time is 0.2 s** since ≈ 2026-11-06 (measured: last 1M blocks 0.200 s/block; last 2.5M blocks average 1.02 s; 2.0 s before late October). Consequences: (a) **every "N blocks" parameter is now expressed in seconds** (confirmations, RBF, dwell, gap limits, log chunking); (b) a 7-day log backfill is ≈ 3.0M blocks, not 302k; (c) this doc's first-draft swap/volatility statistics ("25 swaps / 7 d, 1-h σ 15–25 t, daily range 10–160 t") were computed over 302,400 blocks ≈ **17 hours**, not 7 days, and are withdrawn — edge-strategy's figures (805 swaps last 7 d, ≈ 172/day over 30 d, 36 in the last 24 h = GeckoTerminal's count, 1-h σ ≈ 1.57% ≈ 156 t, daily range median 6.9% ≈ 670 t, 147% annualised / 181% last 7 d) used real block timestamps and are adopted. | `eth_getBlockByNumber` timestamps at head −1k/−100k/−1M/−2M/−2.5M (2026-11-08 21:48 UTC); GeckoTerminal trades cross-check |
| D11 | Build-plan §1.1 option A: **asymmetric straddles A/B/C** (±1.5% core, [−4%, +1.5%], [−1.5%, +4%]; 50/25/25) — the layout this doc's first draft designed around | **Rejected.** At 147–181% annualised vol the ±1.5% core is breached ≈ 43×/week and the ±4% envelope ≈ 12.6×/week; the 30-day replay (edge-strategy §3.2) ranks the straddle top-3 in gross TEL (108–138k/week) but **net-negative in every window** (−$32 … −$532/week after IL and re-centring). Liquidity-axis share saturates as L/(L+L_others) while IL grows ∝ 1/r². Replaced by **two brackets: core $1k at ±600 t (inventory-matched re-centre, 60-min hysteresis) + anchor $1k at ±2220 t (re-centred within 300 t of its edge)**, expected 65–100k TEL/week (13–20% share), net +$5 … +$125/week. | edge-strategy §3.1–3.3 |
| D12 | — | **Pre-subscribed dust staging slots** (core band shifted ±300 t, minted with `dustL` while they contain spot) make the next core re-centre an `INCREASE_LIQUIDITY` on an already-subscribed NFT — removes the `OutOfRange` blocker from build-plan §1.1 and keeps long-lived tokenIds. Competitor `0xbbe5…` runs 13 such slots and is paid on the live leaderboard. | edge-strategy §0 item 6, §6 R4 |
| D13 | Blueprint `maxRebalancesPerWeek: 3`, this doc's first draft 5/week, 6 h cooldown, 20-min arm dwell, 10% idle reserve | `maxRebalancesPerDay 3` (soft), `maxRebalancesPerWeek 12` (hard), `minTimeBetweenRebalances 2 h`, core dwell 60 min, **reserve 0** (every idle dollar costs linearly on the 25/25 axes; the anchor is the inventory buffer). | edge-strategy §5, §6 R1/R6 |

Everything else in the blueprint (addresses, PoolKey `fee 3000 / tickSpacing 60 / hooks 0`, PosM `multicall([modifyLiquidities, subscribe×n])`, custody, kill switch) stands.

### 0.1 Verified on-chain snapshot (Base, block 54,911,993, 2026-11-08 ~21:20 UTC)

| Item | Value |
|------|-------|
| `keccak256(abi.encode(PoolKey))` | `0x1266df87…6982` — matches configured poolId |
| `PositionManager.poolKeys(bytes25)` | eUSD `0x1491…2949`, TEL `0x7E13…0731`, 3000, 60, hooks 0 |
| `StateView.getSlot0` | `sqrtPriceX96 = 2109671869084477070878252953148658604`, `tick = 341966`, `protocolFee = 2048500`, `lpFee = 3000` |
| Spot | 709.04 TEL / eUSD → 0.001410 eUSD / TEL (Merkl API marks TEL $0.001535: pool ≈ 9% stale vs market — ghost pool) |
| `StateView.getLiquidity` | `873,733,903,513,297,729` (8.74e17) |
| `PositionManager.nextTokenId` | 3,208,271 |
| `PositionManager.unsubscribeGasLimit` | 300,000 |
| Registry `0xcebC…45E1` | `inRangeRequired = true`, `minLiquidity[pool] = 0`, `poolAllowed = true`, `positionManager/stateView/poolManager` match blueprint, `hasRole(SUBSCRIBER_ROLE, 0x19ED…8c86) = true` |
| Subscribed owners / positions in this pool | 23 owners, 118 tokenIds; **subscribed in-range L = 99.97% of pool active L** (everyone in range is subscribed) |
| Block time | **0.200 s/block** (head 54,920,737 at 21:48:43 UTC; 1M blocks back = 2026-11-06 14:15 UTC). 2.5M blocks ≈ 29.4 days (mixed 2 s → 0.2 s regime). |
| Swaps, last ≈ 17 h (302,400 blocks) | 25 swaps, ≈ $2.1k eUSD side; tick path 341,561 → 342,039 (+478 t ≈ TEL −4.7% **in 17 h**); last swap block 54,896,604 (20:28 UTC). Blocks 54,523,000 → head: **36 swaps, identical to GeckoTerminal's 36 trades / 24 h ($3.9k)** — log scan and indexer agree. *(First draft mislabelled this window "7 days" — see D10.)* |
| Swaps / volatility, 30 d (from `edge-strategy.md` §2, same PoolManager logs over 2.5M blocks) | 5,168 swaps (≈ 172/day), ≈ $291k volume; 1-h σ 1.57% ≈ 156 t; daily range median 6.9% (≈ 670 t), p75 8.0%, max 33.6% (Nov 5); 147% annualised (181% last 7 d); breaches/week if re-centred immediately: ±1.5% 43, ±4% 12.6, ±6% 5.8, ±8% 4.0, ±12% 1.9, ±25% 0.23; 64% of ±6% excursions return within 1 h |
| `ModifyLiquidity`, 30 d | 478 events, all via PosM; 3–4 actively re-centring bots (`0xe77D…` 43 mints, `0xe70E…` 58, `0xbbe5…` 13, `0x5702…` 8) |

Sources: own `eth_call`/`eth_getLogs` against `https://mainnet.base.org` and `https://base-rpc.publicnode.com`; v4-core `bea7f6d` and v4-periphery `c6e4754` (main, 2026-10); registry source from Sourcify. Function signatures quoted below are copied from those sources; **re-pin to the deployed Base PosM/UR version at build time** (main has grown opcodes `0x15–0x19` and a `minHopPriceX36` field in `ExactInputSingleParams` that the Jan-2025 Base deployment does not have — opcodes `0x00–0x14` are unchanged).

---

## 1. Measurement layer

### 1.1 What to read (verified signatures)

```solidity
// v4-periphery/src/interfaces/IStateView.sol  (StateView 0xa3c0c9b65bad0b08107aa264b0f3db444b867a71)
function getSlot0(PoolId poolId) external view returns (uint160 sqrtPriceX96, int24 tick, uint24 protocolFee, uint24 lpFee);
function getLiquidity(PoolId poolId) external view returns (uint128 liquidity);
function getTickBitmap(PoolId poolId, int16 word) external view returns (uint256 tickBitmap);
function getTickInfo(PoolId poolId, int24 tick) external view returns (uint128 liquidityGross, int128 liquidityNet, uint256 feeGrowthOutside0X128, uint256 feeGrowthOutside1X128);
function getTickLiquidity(PoolId poolId, int24 tick) external view returns (uint128 liquidityGross, int128 liquidityNet);
function getFeeGrowthGlobals(PoolId poolId) external view returns (uint256 feeGrowthGlobal0, uint256 feeGrowthGlobal1);
function getFeeGrowthInside(PoolId poolId, int24 tickLower, int24 tickUpper) external view returns (uint256 feeGrowthInside0X128, uint256 feeGrowthInside1X128);
function getPositionInfo(PoolId poolId, address owner, int24 tickLower, int24 tickUpper, bytes32 salt) external view returns (uint128 liquidity, uint256 feeGrowthInside0LastX128, uint256 feeGrowthInside1LastX128);
function getPositionLiquidity(PoolId poolId, bytes32 positionId) external view returns (uint128 liquidity);

// v4-periphery/src/interfaces/IPositionManager.sol + INotifier.sol  (PosM 0x7C5f5A4bBd8fD63184577525326123B519429bDc)
function nextTokenId() external view returns (uint256);
function getPositionLiquidity(uint256 tokenId) external view returns (uint128 liquidity);
function getPoolAndPositionInfo(uint256 tokenId) external view returns (PoolKey memory, PositionInfo);
function positionInfo(uint256 tokenId) external view returns (PositionInfo);   // uint256: 200b poolId(bytes25) | 24b tickUpper | 24b tickLower | 8b hasSubscriber
function subscriber(uint256 tokenId) external view returns (ISubscriber);
function ownerOf(uint256 tokenId) external view returns (address);              // ERC721

// v4-core/src/interfaces/IPoolManager.sol  (PoolManager 0x498581fF718922c3f8e6A244956aF099B2652b2b)
event Swap(PoolId indexed id, address indexed sender, int128 amount0, int128 amount1, uint160 sqrtPriceX96, uint128 liquidity, int24 tick, uint24 fee);
event ModifyLiquidity(PoolId indexed id, address indexed sender, int24 tickLower, int24 tickUpper, int256 liquidityDelta, bytes32 salt);

// TELx PositionRegistry 0xcebC0b00473Ca00e429eF431826d0A32cdc945E1 (Sourcify-verified ABI)
function inRangeRequired() view returns (bool);
function minLiquidity(bytes32 poolId) view returns (uint128);
function poolAllowed(bytes32 poolId) view returns (bool);
function isTokenSubscribed(uint256 tokenId) view returns (bool);
function isInRange(uint256 tokenId) view returns (bool);
function subscriptionEligible(uint256 tokenId) view returns (bool);
function belowSubscriptionThreshold(uint256 tokenId) view returns (bool);
function getSubscribed(uint256 offset, uint256 limit) view returns (address[] page, uint256 total);
function getSubscriptionsRaw(address owner) view returns (uint256[]);
function getPosition(uint256 tokenId) view returns (address owner, bytes32 poolId, int24 tickLower, int24 tickUpper);
function getAmountsForLiquidity(bytes32 poolId, uint128 liquidity, int24 tickLower, int24 tickUpper) view returns (uint256 amount0, uint256 amount1, uint160 sqrtPriceX96);
event Subscribed(uint256 tokenId, address owner);  event Unsubscribed(uint256 tokenId, address owner);
```

`PositionInfo` decode (from `PositionInfoLibrary.sol`): `hasSubscriber = info & 0xff`, `tickLower = signextend24(info >> 8)`, `tickUpper = signextend24(info >> 32)`, `poolId25 = info & MASK_UPPER_200_BITS`. The core `positionId` for our NFT is `keccak256(abi.encodePacked(address(PosM), tickLower, tickUpper, bytes32(tokenId)))` (salt = tokenId; `Position.calculatePositionKey`).

### 1.2 Cadence tiers and profiles

Two cadence profiles share the same tiers; **`low-rpc` is the default**, `fast-poll` (2 s; formerly "block-driven" — with 0.2 s blocks a per-block loop would be 18,000 req/h and is pointless) is opt-in (`execution.cadenceProfile`). Every tier is one `multicall3.aggregate3` call (`0xcA11bde05977b3631167028862bE2a173976CA11`) = **one** JSON-RPC request regardless of sub-call count; `getBlockNumber()`/`getCurrentBlockTimestamp()` ride in the same aggregate, so no separate `eth_blockNumber`. Never use JSON-RPC batch arrays (dRPC free caps them at 3; some public nodes reject them).

| Tier | Reads (one `multicall3` request) | Purpose | **`low-rpc` (default)** | `fast-poll` (opt-in) |
|------|----------------------------------|---------|--------------------------|-------------------------|
| **T0 hot** | `getSlot0`, `getLiquidity`, `getBlockNumber` | tick, spot, active L → breach engine | HTTP poll **every 12 s** (jittered 10–15 s) → 300 req/h | HTTP poll every 2 s (≈ 10 blocks) → 1,800 req/h |
| **T1 warm** | per-slot `getPositionLiquidity`, `positionInfo`, `subscriber`; registry `isTokenSubscribed`, `belowSubscriptionThreshold`; `getFeeGrowthInside(lo,hi)`; `getFeeGrowthGlobals`; `minLiquidity` | our state, fee accrual, prune risk | **every 60 s** or immediately after a `Swap`/`ModifyLiquidity` log for our poolId → ≈ 60–70 req/h (1 request; 2 if > 8 slots) | every 30 s → 120 req/h |
| **T2 cold** | bitmap words ±3 → `getTickLiquidity` per initialised tick; registry `getSubscribed` → `getSubscriptionsRaw` → `getPosition` + PosM `getPositionLiquidity` for all subscribed ids in the pool | competitor profile, subscribed in-range L, token0/1 held in range | **every 12 min** (10–15) or after `ModifyLiquidity`/`Subscribed`/`Unsubscribed` log → 5 runs × ~6 requests = ≈ 30 req/h | every 5 min → ≈ 72 req/h |
| **T3 logs** | `eth_getLogs(address: PoolManager, topics: [[Swap, ModifyLiquidity], poolId], from: lastSeen+1, to: latest)` — one request covers both events | swap stream → volume, `lastSwapAt`, tick path; invalidates T1/T2 | **`eth_getLogs` poll every 60 s** (≈ 300 blocks per call at 0.2 s/block) → 60 req/h; WS `eth_subscribe('logs')` only if the chosen provider offers free WS | WS `eth_subscribe('logs')` + `eth_getLogs` reconcile every 60 s |
| **T4 startup / hourly** | Merkl API (not RPC); `eth_getLogs` 7-day backfill = ≈ 3.0M blocks at 0.2 s/block → 300 requests in 10k-block chunks (keyed lane only, once; Alchemy/Infura accept 10k ranges) | invariants, cold start | hourly | hourly |
| **EXECUTING burst** | `nextTokenId` + `simulateContract` + `estimateGas` + `eth_gasPrice`/`eth_maxPriorityFeePerGas` + send + receipt polls every 4 s for ≤ 20 s, then RBF | rebalance path only | ≤ 15 requests per rebalance, ≤ 12/week | same |

**Requests per hour, steady state:** `low-rpc` ≈ 300 + 65 + 30 + 60 ≈ **455 req/h ≈ 11k/day ≈ 330k/month** (97% `eth_call`, 3% `eth_getLogs`); `fast-poll` ≈ **2,050 req/h ≈ 1.5M/month**. In provider units (§1.9): `low-rpc` ≈ 10.5M Alchemy CU/month (35% of free), ≈ 1.1M Infura credits/day (37% of free), ≈ 7M dRPC CU/month (3% of free), ≈ 66M Ankr credits/month (33% of free at ≈ 200 credits/request). Peak rate is the T2 burst of ~6 sequential requests; a 2 req/s token bucket per endpoint keeps every provider under its per-second cap.

**Yield trade-off of the slower cadence: none measurable.** The decision engine never acts on a single sample — the core trigger needs **60 min** of continuous out-of-band samples (300 samples at 12 s vs 1,800 at 2 s); the only immediate paths (core ≥ 200 t beyond edge, anchor within 300 t of edge) are confirmed by a second sample ≤ 15 s later. Detection latency rises from ≤ 2 s to ≤ 15 s per event, i.e. ≤ 15 s of extra out-of-range time per rebalance — at 20% share of a ≈ $750/week budget that is < $0.01. The hysteresis reset ("any sample back inside the band resets the timer") becomes slightly *less* sensitive to sub-12-s wicks, which marginally favours re-centring on real trends. With ≈ 172 swaps/day (one per ≈ 8 min on average) a 12 s sampler still sees essentially every tick move; Merkl's time-weighting is hourly-scale, so neither profile changes realised share. `fast-poll` is only worth opting into for fork soak tests.

### 1.3 Interfaces

```ts
import type { Address, Hex, PublicClient } from 'viem';

export type PoolId = Hex;            // bytes32
export type Tick = number;           // int24
export type Q96 = bigint;            // uint160 sqrtPriceX96
export type X128 = bigint;           // uint256 fee growth

export interface PoolKey { currency0: Address; currency1: Address; fee: number; tickSpacing: number; hooks: Address }

export interface Slot0Sample { block: bigint; ts: number; sqrtPriceX96: Q96; tick: Tick; protocolFee: number; lpFee: number; liquidity: bigint }

export interface TickLiquidity { tick: Tick; liquidityGross: bigint; liquidityNet: bigint }

export interface SlotState {            // one of our bracket NFTs
  tokenId: bigint; role: 'core' | 'anchor' | 'staging';            // staging = dust slot (§3.1); 'lower'/'upper' straddles removed (D11)
  tickLower: Tick; tickUpper: Tick; liquidity: bigint;
  hasSubscriber: boolean; subscriberAddr: Address; registrySubscribed: boolean; prunable: boolean;
  feeGrowthInside0X128: X128; feeGrowthInside1X128: X128;      // current (StateView.getFeeGrowthInside)
  feeGrowthInside0LastX128: X128; feeGrowthInside1LastX128: X128; // position checkpoint
}

export interface CompetitorPosition { tokenId: bigint; owner: Address; tickLower: Tick; tickUpper: Tick; liquidity: bigint; inRange: boolean }

export interface SwapObs { block: bigint; ts: number; amount0: bigint; amount1: bigint; sqrtPriceX96: Q96; tick: Tick; liquidity: bigint; sender: Address; logIndex: number; blockHash: Hex }

export interface PoolSnapshot {
  slot0: Slot0Sample;
  ticks: TickLiquidity[];               // initialised ticks within ±N words of spot
  competitors: CompetitorPosition[];    // all subscribed positions in this pool
  ours: SlotState[];
  feeGrowthGlobal0X128: X128; feeGrowthGlobal1X128: X128;
  swaps: SwapObs[];                     // rolling window (7 d)
}

export interface Measurement {
  readSlot0(client: PublicClient, poolId: PoolId): Promise<Slot0Sample>;                           // T0
  readOurSlots(client: PublicClient, tokenIds: bigint[]): Promise<SlotState[]>;                    // T1
  readTickProfile(client: PublicClient, poolId: PoolId, centerTick: Tick, words: number): Promise<TickLiquidity[]>; // T2
  readCompetitors(client: PublicClient, poolId: PoolId): Promise<CompetitorPosition[]>;            // T2
  subscribeSwaps(client: PublicClient, poolId: PoolId, onSwap: (s: SwapObs) => void): () => void;  // T3
}
```

### 1.4 Pseudo-code: T0 / T1 batches

```ts
async function readSlot0(client, poolId): Promise<Slot0Sample> {
  const [s0, liq] = await client.multicall({ allowFailure: false, contracts: [
    { address: STATE_VIEW, abi: stateViewAbi, functionName: 'getSlot0', args: [poolId] },
    { address: STATE_VIEW, abi: stateViewAbi, functionName: 'getLiquidity', args: [poolId] },
  ]});
  const block = await client.getBlock({ blockTag: 'latest' });   // or carry from newHeads
  return { block: block.number, ts: Number(block.timestamp), sqrtPriceX96: s0[0], tick: s0[1], protocolFee: s0[2], lpFee: s0[3], liquidity: liq };
}

async function readOurSlots(client, tokenIds): Promise<SlotState[]> {
  const calls = tokenIds.flatMap(id => [
    { address: POSM, abi: posmAbi, functionName: 'positionInfo', args: [id] },
    { address: POSM, abi: posmAbi, functionName: 'getPositionLiquidity', args: [id] },
    { address: POSM, abi: posmAbi, functionName: 'subscriber', args: [id] },
    { address: REGISTRY, abi: registryAbi, functionName: 'isTokenSubscribed', args: [id] },
    { address: REGISTRY, abi: registryAbi, functionName: 'belowSubscriptionThreshold', args: [id] },
  ]);
  const r = await client.multicall({ allowFailure: false, contracts: calls });
  // second batch: fee growth inside for each (lo,hi) decoded from positionInfo + position checkpoint
  ...
  return tokenIds.map((id, i) => {
    const info = r[5*i] as bigint;
    const tickLower = signExtend24(Number((info >> 8n) & 0xffffffn));
    const tickUpper = signExtend24(Number((info >> 32n) & 0xffffffn));
    return { tokenId: id, tickLower, tickUpper, liquidity: r[5*i+1], hasSubscriber: (info & 0xffn) !== 0n,
             subscriberAddr: r[5*i+2], registrySubscribed: r[5*i+3], prunable: r[5*i+4], ... };
  });
}
```

### 1.5 Pseudo-code: tick profile (competitor in-range liquidity by tick)

```ts
// Reconstruct L(t) for any tick t from net liquidity: L(t) = L_active + Σ_{spot<τ≤t} net(τ)  (t > spot)
//                                                            L_active − Σ_{t<τ≤spot} net(τ)  (t < spot)
async function readTickProfile(client, poolId, centerTick, words = 3): Promise<TickLiquidity[]> {
  const spacing = 60;
  const compressed = Math.floor(centerTick / spacing);
  const word0 = compressed >> 8;                               // int16 word index
  const bitmaps = await client.multicall({ allowFailure: false, contracts:
    range(word0 - words, word0 + words).map(w => ({ address: STATE_VIEW, abi: stateViewAbi, functionName: 'getTickBitmap', args: [poolId, w] })) });
  const initialised: Tick[] = [];
  bitmaps.forEach((bm, i) => { for (let b = 0; b < 256; b++) if ((bm >> BigInt(b)) & 1n) initialised.push((((word0 - words + i) << 8) + b) * spacing); });
  const infos = await client.multicall({ allowFailure: false, contracts:
    initialised.map(t => ({ address: STATE_VIEW, abi: stateViewAbi, functionName: 'getTickLiquidity', args: [poolId, t] })) });
  return initialised.map((t, i) => ({ tick: t, liquidityGross: infos[i][0], liquidityNet: infos[i][1] }));
}

export function liquidityAt(target: Tick, spot: Tick, activeL: bigint, ticks: TickLiquidity[]): bigint {
  let L = activeL;
  if (target > spot) for (const t of ticks) { if (t.tick > spot && t.tick <= target) L += t.liquidityNet; }
  else               for (const t of ticks) { if (t.tick > target && t.tick <= spot) L -= t.liquidityNet; }
  return L;                                           // total pool liquidity if spot were at `target`
}
// competitorLiquidityAt(target) = liquidityAt(target) − ourLiquidityAt(target)
```

±3 words × 256 bits × 60 ticks = ±46,080 ticks (≈ ±99%) around spot — more than enough; 25 initialised ticks today.

### 1.6 Pseudo-code: subscribed competitor set (Merkl-eligible denominator)

```ts
async function readCompetitors(client, poolId): Promise<CompetitorPosition[]> {
  const [owners] = await client.readContract({ address: REGISTRY, abi: registryAbi, functionName: 'getSubscribed', args: [0n, 1000n] });
  const idLists = await client.multicall({ allowFailure: false, contracts: owners.map(o => ({ address: REGISTRY, abi: registryAbi, functionName: 'getSubscriptionsRaw', args: [o] })) });
  const ids = idLists.flat();
  const pos = await client.multicall({ allowFailure: false, contracts: ids.map(id => ({ address: REGISTRY, abi: registryAbi, functionName: 'getPosition', args: [id] })) });
  const inPool = ids.filter((_, i) => pos[i][1].toLowerCase() === poolId.toLowerCase());
  const liqs = await client.multicall({ allowFailure: false, contracts: inPool.map(id => ({ address: POSM, abi: posmAbi, functionName: 'getPositionLiquidity', args: [id] })) });
  return inPool.map((id, i) => ({ tokenId: id, owner: pos[i][0], tickLower: pos[i][2], tickUpper: pos[i][3], liquidity: liqs[i], inRange: pos[i][2] <= spot && spot < pos[i][3] }));
}
```

Cache for `coldEveryS` (12 min); invalidate on `Subscribed`/`Unsubscribed`/`ModifyLiquidity` logs. Today: 23 owners / 118 ids / ~300 sub-calls → 3 multicall batches.

### 1.7 What the snapshot tells us (design-relevant)

- **Subscribed in-range L ≈ pool active L (99.97%)** → Merkl's active-tick denominator ≈ `getLiquidity()`; the tick profile is the right tool to predict it at other ticks.
- **Liquidity wall just below spot:** one position (`0xd0c5…`) holds **L = 1.85e18 in [336060, 341640]** (−44.6% … −3.2% in TEL-per-eUSD terms, i.e. it activates if **TEL rallies ≥ 3.2%**), ≈ $22.7k of the $30k TVL. If spot enters it, active L jumps 8.7e17 → 2.7e18 and our active-tick share falls ~2.3×. The decision engine must know `liquidityAt(t)` is **not** flat.
- **Active competitors:** `0xe70E…` (≈20 NFTs, 240-tick bands, most now L = 0, zombie-subscribed), `0xbbe5…` (240-tick ladder; parks dust L = 2e13 in off-spot slots and refills the on-spot slot — exactly the slot model of D3), `0x5702…`/`0x327d…` (wide upward ranges, re-minted ~weekly). Over 30 days `0xe70E…` re-minted 58× and `0xe77D…` 43× (edge-strategy §2.4) — i.e. the active bots re-centre 1–2× per day, which is the frequency our caps (3/day soft) must tolerate without being out-competed.
- **Price impact:** at L = 8.7e17, a swap of $5 / $50 / $100 / $500 of TEL moves spot ≈ 3 / 28 / 56 / 278 ticks. Our own $1k core at ±600 t is **L ≈ 0.45e18 ≈ 52% of today's active book** (a $1k ±180 t core would be 1.5e18, but is breached ≈ 43×/week — D11).
- **Volatility (edge-strategy §2):** 1-h σ ≈ 156 t, daily range median ≈ 670 t, 7-day realised 181% annualised; the +478 t move in the last 17 h is an ordinary day. A ±600 t core is breached ≈ 5.8×/week if re-centred at once; with the 60-min hysteresis 64% of those excursions resolve on their own, so expected re-centres ≈ 2/week, well inside the 12/week cap.

### 1.8 Polling vs subscription, block time, reorgs

- **`low-rpc` (default):** pure HTTP polling through the rotating `RpcPool` (§1.9); no WS dependency. T0 timer 12 s ± 2.5 s jitter (so several bots on the same public endpoint do not synchronise); each tick carries the block number from the aggregate, and a sample whose block number did not advance is discarded (stale node behind a load balancer).
- **`fast-poll` (opt-in):** HTTP T0 every 2 s; optional WS `eth_subscribe('logs')` for T3 with HTTP reconcile every 60 s; on WS silence > 10 s fall back to polling and attempt WS reconnect with backoff (1 → 30 s). `newHeads` is **not** used — at 0.2 s/block it is 18k events/h for no decision value. Never two WS streams feeding the same state concurrently (dedupe by block hash). Free WS exists on publicnode (`wss://base-rpc.publicnode.com`), Alchemy, Infura (credits per event), dRPC paid only, Ankr Premium only.
- **Logs:** default `eth_getLogs({address: PoolManager, topics: [[Swap.topic, ModifyLiquidity.topic], poolId], fromBlock: lastSeen + 1, toBlock: 'latest'})` every 60 s; on a gap > 10k blocks (restart; 10k blocks ≈ 33 min) chunk ≤ 10k blocks (publicnode/dRPC limits observed) through the keyed lane. WS `eth_subscribe('logs')` only in `fast-poll`. Dedupe on `(blockHash, logIndex)`. **Cross-check the swap stream** once an hour against GeckoTerminal `/trades` (free, no key) and alert on > 20% disagreement in the 24-h count — cheap insurance against a load-balanced public node silently serving a lagging replica (verified 2026-11-08: publicnode returned exactly the 36 swaps Gecko lists for the last 24 h, so today the two agree).
- **Reorgs:** Base is a single-sequencer OP-stack chain; L2 reorgs are rare but `latest` is "unsafe". Rules: (i) `removed: true` logs are dropped and rolling stats rebuilt from the retained window; (ii) tx receipts count as confirmed after **≥ 3 blocks and ≥ 2 s** (0.2 s blocks — use time, not height) and state is **re-read** (T1) before the bot commits `BotState`; (iii) any T0 sample whose `block.parentHash` ≠ previous hash triggers a T1 re-read; (iv) nothing is ever decided from a single sample — all triggers go through dwell timers or a confirming second sample (§3).

### 1.9 RPC provider plan (no paid RPC)

**Design:** one `RpcPool` with two lanes. *Lane A — keyed free tiers* (1–3 accounts; stable quotas, used for 100% of steady-state traffic and for every send/simulate). *Lane B — public endpoints* (no key; used only when lane A is exhausted/unhealthy, and for the one-off 7-day log backfill). All traffic is `multicall3`-aggregated, so provider quotas are consumed per request, not per sub-call.

**Free tiers with Base access — limits as published on 2026-11-08** (re-check quarterly; all changed in 2026):

| Provider | Free quota | Rate cap | Base cost model | Our `low-rpc` use (≈ 330k req/mo) | WS | Notes |
|----------|-----------|----------|-----------------|-----------------------------------|----|-------|
| **Alchemy** (Free) | 30M CU / month | 300 CU/s ≈ 15 req/s, 10-s rolling bucket | `eth_call` 26 CU, `eth_getLogs` 75 CU (avg 27) | ≈ 10.5M CU ≈ **35%** | yes | 5 apps; 429 on throughput, retry safe. Best primary. |
| **Infura** (Core/free) | 3M credits / **day** (reset 00:00 UTC) | 500 credits/s ≈ 6 `eth_call`/s | `eth_call` 80, `eth_getLogs` 255 credits | ≈ 1.1M/day ≈ **37%** | yes (credits per event) | Cut from 6M/2k to 3M/500 on 2026-01-07; **402** when daily quota is gone (hard stop until midnight) — keep as secondary, not primary. |
| **dRPC** (Free) | 210M CU / 30 d | 120k CU/min/IP ≈ 100 `eth_call`/s (may drop to 40/s under load) | ~20 CU/request | ≈ 7M CU ≈ **3%** | no (paid) | Public nodes only; batch ≤ 3; `eth_getLogs` ≤ 10k logs; filters disabled. Excellent secondary. |
| **Ankr** (Freemium, keyed) | 200M API credits / month | ≈ 30 req/s (1,800/min guaranteed) | ≈ 200 credits/request ($10 ≈ 500k req on PAYG) | ≈ 66M ≈ **33%** | no (Premium) | Unkeyed `rpc.ankr.com/base` now returns `Unauthorized` — must sign up for the key. |
| **QuickNode** | 10M credits, **30-day trial only** | 15 req/s | 20 credits / EVM call | would be 6.6M in the month | yes | Not a permanent free plan — account is disabled after 30 days. **Exclude** from the rotation. |

Two keyed accounts (Alchemy primary + dRPC or Infura secondary) give > 5× headroom for `low-rpc`; even `fast-poll` (1.5M req/mo ≈ 40M Alchemy CU) needs two providers split 50/50 to stay free.

**Public endpoints (lane B), probed 2026-11-08 from this VM:**

| Endpoint | Probe | Observed limits / caveats |
|----------|-------|---------------------------|
| `https://mainnet.base.org` | 70 ms, OK | Coinbase-run; **429 "request limit reached" at ≈ 100 requests in a few seconds** (hit during §1.6 enumeration); fine at ≤ 1 req/s. No WS (405). |
| `https://base-rpc.publicnode.com` (alias `base.publicnode.com` → 301) | 75 ms, OK | Allnodes; `eth_getLogs` ≤ 10k-block range; free `wss://base-rpc.publicnode.com`. Most generous public node. |
| `https://base.llamarpc.com` | **Cloudflare challenge page** from a datacenter IP | May work from residential IPs; treat as lowest priority and auto-disable on non-JSON responses. |
| `https://1rpc.io/base` | 78 ms, OK | Automata; privacy relay, per-IP daily cap undocumented (historically ~10k req/day); fine for lane B. |
| `https://base.drpc.org` | 72 ms, OK | dRPC public (same infra as the keyed free tier, per-IP limits above). |

**Per-endpoint rate limiting, backoff, health scoring:**

```ts
export interface RpcEndpoint {
  id: string; url: string; lane: 'keyed' | 'public'; ws?: string;
  maxRps: number;                   // token bucket refill; defaults: alchemy 10, infura 4, drpc 20, ankr 15, mainnet.base.org 1, publicnode 4, 1rpc 2, llamarpc 1
  burst: number;                    // bucket size (≈ 2 × maxRps)
  dailyBudget?: number;             // requests/day we allow ourselves on this endpoint (e.g. infura 25_000 ≈ 2M credits); soft stop at 90 %
  supports: { getLogs: boolean; maxLogRange: number; ws: boolean };
}

export interface EndpointHealth { score: number /* 0..1 */; consecutiveFailures: number; cooldownUntil: number; p50Ms: number; lastBlock: bigint; usedToday: number }

export class RpcPool {
  // viem transport: fallback([...endpoints.map(e => http(e.url, { batch: false, retryCount: 0, timeout: 8_000 }))], { rank: false })
  // — but routing is ours, not viem's: we pick the endpoint, viem only encodes/decodes.
  pick(kind: 'read' | 'logs' | 'send'): RpcEndpoint {
    const now = Date.now();
    const live = this.endpoints.filter(e => this.health(e).cooldownUntil <= now && this.bucket(e).tokens >= 1 && (kind !== 'logs' || e.supports.getLogs) && (kind !== 'send' || e.lane === 'keyed') && this.health(e).usedToday < 0.9 * (e.dailyBudget ?? Infinity));
    const laneA = live.filter(e => e.lane === 'keyed');
    const pool = laneA.length ? laneA : live;                                 // public lane only when every keyed endpoint is out
    if (!pool.length) throw new NoHealthyRpc();                              // caller: skip this tick, alert if > 2 min
    return maxBy(pool, e => this.health(e).score - this.health(e).p50Ms / 10_000);   // best health, tie-break latency; lag-behind-head nodes score 0 (see below)
  }
  async request<T>(kind, fn: (ep: RpcEndpoint) => Promise<T>): Promise<T> {
    for (let attempt = 0; attempt < 4; attempt++) {
      const ep = this.pick(kind); this.bucket(ep).take(); const t0 = Date.now();
      try { const r = await fn(ep); this.onSuccess(ep, Date.now() - t0, r); return r; }
      catch (e) { this.onFailure(ep, e); if (!isRetryable(e)) throw e; await sleep(250 * 2 ** attempt + jitter()); }
    }
    throw new RpcExhausted();
  }
  onSuccess(ep, ms, r) { const h = this.health(ep); h.consecutiveFailures = 0; h.p50Ms = ewma(h.p50Ms, ms, 0.2); h.score = min(1, h.score + 0.05); h.usedToday++;
    if (r?.blockNumber !== undefined) { h.lastBlock = r.blockNumber; if (this.headBlock - r.blockNumber > cfg.rpc.health.lagDemoteBlocks /* 25 ≈ 5 s */) h.score *= 0.5; else this.headBlock = max(this.headBlock, r.blockNumber); } }  // stale node → demote
  onFailure(ep, e) { const h = this.health(ep); h.consecutiveFailures++; h.usedToday++;
    if (is429(e))            { h.cooldownUntil = Date.now() + min(60_000, 2_000 * 2 ** h.consecutiveFailures); h.score *= 0.7; }         // 2 s → 4 → 8 … 60 s, honour Retry-After if present
    else if (is402(e))       { h.cooldownUntil = nextUtcMidnight(); h.score = 0; alert('warn', 'rpcDailyQuota', ep.id); }                 // Infura daily quota
    else if (isTimeout(e) || isNetwork(e)) { h.cooldownUntil = Date.now() + min(30_000, 1_000 * 2 ** h.consecutiveFailures); h.score *= 0.8; }
    else if (isNonJson(e))   { h.cooldownUntil = Date.now() + 10 * 60_000; h.score *= 0.3; }                                             // Cloudflare challenge (llamarpc), HTML error pages
    if (h.consecutiveFailures >= 5) { h.cooldownUntil = Date.now() + 5 * 60_000; alert('warn', 'rpcEndpointDown', ep.id); }
    this.health(ep).score = max(0.05, h.score); }                                                                                          // never pin to 0: probe again after cooldown
}
```

Rules: (i) every tick picks the endpoint fresh — no sticky primary; (ii) 429s cost the endpoint a cooldown and 30% of score but no request is lost (retried elsewhere within the same tick); (iii) **sends and simulations use keyed endpoints only** (public relays may serve stale state or drop txs), and `simulate → send` must hit the **same** endpoint; (iv) per-endpoint `usedToday` persists to state so a restart does not reset Infura's daily budget tracking; (v) a background `healthProbe` every 5 min sends `eth_blockNumber` to endpoints in cooldown-expired/low-score state (≈ 12 req/h extra, included in the 455 req/h figure's rounding); (vi) metrics (§6.4) add `rpc{id, usedToday, score, p50Ms, cooldownUntil, lagBlocks}` per endpoint. Configuration lives in `BotConfig.rpc` (§7).

---

## 2. Derived metrics

### 2.1 Price and tick conversions (decimals 6 / 18)

```ts
const Q96 = 2n ** 96n;
export function priceToken1PerToken0Raw(sqrtPriceX96: Q96): number { const s = Number(sqrtPriceX96) / 2 ** 96; return s * s; }
/** TEL per eUSD (human units). currency0 = eUSD (6), currency1 = TEL (18). */
export function telPerEusd(sqrtPriceX96: Q96): number { return priceToken1PerToken0Raw(sqrtPriceX96) * 10 ** (6 - 18); }
export function eusdPerTel(sqrtPriceX96: Q96): number { return 1 / telPerEusd(sqrtPriceX96); }
export function tickToPct(dTick: number): number { return (1.0001 ** dTick - 1) * 100; }   // 60 t = 0.602 %, 180 t = 1.816 %, 420 t = 4.289 %
export function pctToTicks(pct: number): number { return Math.log(1 + pct / 100) / Math.log(1.0001); }
export function snapDown(t: Tick, s = 60): Tick { return Math.floor(t / s) * s; }
export function snapUp(t: Tick, s = 60): Tick { return Math.ceil(t / s) * s; }
```

Golden values (block 54,911,993): `sqrtPriceX96 = 2109671869084477070878252953148658604` → tick 341966 → **709.04 TEL/eUSD = 0.001410 eUSD/TEL**. Check: `1.0001^341966 × 1e-12 = 709.01`. Orientation rule: **tick ↑ ⇒ TEL cheaper**; when spot exits a bracket **upward** the bracket holds **100% TEL** (token1); exiting **downward** leaves **100% eUSD** (token0).

### 2.2 Per-bracket in-range share and Merkl share estimate

Merkl (docs, 2026-11-08): budget split **50% "liquidity contribution" = time-weighted share of liquidity at the active tick**, **25% share of token0 held by in-range positions**, **25% share of token1 held by in-range positions**. Out-of-range positions earn 0 (`isOutOfRangeIncentivized: false`). **Denominators are in-range only** — edge-strategy §4 reproduces the live leaderboard to ±0.3 pp with in-range token0/token1 denominators, so the all-pool lower-bound variant of the first draft is dropped (R2).

```ts
export interface ShareEstimate {
  activeL: bigint; ourActiveL: bigint; liqShare: number;            // fee/liquidity axis (concentration pays)
  tok0Share: number; tok1Share: number;                               // in-range token holdings (concentration does not pay; uptime does)
  merklShare: number;                                                 // 0.5*liq + 0.25*t0 + 0.25*t1 (validated ±0.3 pp vs leaderboard)
  rewardPerHourTel: number;                                           // merklShare × weeklyBudgetTel / 168
}

export function estimateShare(snap: PoolSnapshot, weeklyBudgetTel: number): ShareEstimate {
  const spot = snap.slot0.tick, sP = snap.slot0.sqrtPriceX96;
  const inRange = (p: {tickLower: Tick; tickUpper: Tick}) => p.tickLower <= spot && spot < p.tickUpper;
  const ourActiveL = sum(snap.ours.filter(inRange).map(s => s.liquidity));
  const activeL = snap.slot0.liquidity;                              // ≈ subscribed in-range L (99.97 % today)
  const amounts = (p) => amountsForLiquidity(sP, p.tickLower, p.tickUpper, p.liquidity);   // §4.3 math
  const ourAmt = sumAmounts(snap.ours.filter(inRange).map(amounts));
  const compInRange = sumAmounts(snap.competitors.filter(inRange).map(amounts));
  const liqShare = Number(ourActiveL) / Number(activeL);              // ourActiveL already included in activeL once minted
  const tok0Share = ourAmt.a0 / (ourAmt.a0 + compInRange.a0), tok1Share = ourAmt.a1 / (ourAmt.a1 + compInRange.a1);
  const merklShare = 0.5 * liqShare + 0.25 * tok0Share + 0.25 * tok1Share;
  return { activeL, ourActiveL, liqShare, tok0Share, tok1Share, merklShare, rewardPerHourTel: merklShare * weeklyBudgetTel / 168 };
}
```

Worked snapshot (adopted layout: $1,000 core ±600 t + $1,000 anchor ±2220 t at tick 341966): core L ≈ 0.45e18, anchor L ≈ 0.13e18 → our active L ≈ **0.58e18 → liqShare ≈ 40%** of post-mint active L (1.45e18); in-range token0 (eUSD) competitors ≈ $12.9k vs ours ≈ $1.0k → **tok0 ≈ 7%**; in-range token1 (TEL) competitors ≈ $3.9k vs ours ≈ $1.0k → **tok1 ≈ 20%**; blended **≈ 27%** at this instant. Time-weighted over a week it is lower — the core is out of range part of the time and competitors re-centre — which is why edge-strategy's replay lands at **13–20% (65–100k TEL/week)**. If TEL rallies 3.2% into the 1.85e18 wall and we stay in range: liqShare → ~18%, blended → ~16%. The rejected straddle (D11) would show **≈ 72% liqShare / 43% blended at the instant of minting** and then lose it ≈ 43×/week to IL and re-centring — the instant share is the wrong objective; the **time-weighted** share is.

### 2.3 Fees earned, fee APR, time-in-range, edge distance, drift, volatility

```ts
export function feesOwed(s: SlotState): { fee0: bigint; fee1: bigint } {
  const d0 = (s.feeGrowthInside0X128 - s.feeGrowthInside0LastX128) & ((1n << 256n) - 1n);  // wraps like Solidity
  const d1 = (s.feeGrowthInside1X128 - s.feeGrowthInside1LastX128) & ((1n << 256n) - 1n);
  return { fee0: (d0 * s.liquidity) >> 128n, fee1: (d1 * s.liquidity) >> 128n };
}
// Realised fee APR over window W (hours): feesUsd(W) / positionUsd × 8760 / W. Expect small in this pool: ≈ $291k / 30 d × 0.3% ≈ $29/day pool-wide LP fees ≈ 3–4% APR on $30k TVL — the Merkl budget (500k TEL ≈ $750/week) is ≈ 3.7× the fee income.

export interface EdgeDistance { role: string; toLowerTicks: number; toUpperTicks: number; toLowerPct: number; toUpperPct: number; inRange: boolean }
export const edgeDistance = (spot: Tick, s: SlotState): EdgeDistance => ({
  role: s.role, toLowerTicks: spot - s.tickLower, toUpperTicks: s.tickUpper - 1 - spot,      // in-range iff lower ≤ spot < upper
  toLowerPct: tickToPct(spot - s.tickLower), toUpperPct: tickToPct(s.tickUpper - 1 - spot), inRange: s.tickLower <= spot && spot < s.tickUpper });

// Time-in-range: integrate over T0 samples (12 s default). tir[role] += inRange ? dt : 0 ; report rolling 24 h and since-mint.

// Drift velocity (ticks/hour): robust slope of tick vs time over window W, using swap-event ticks + T0 samples.
export function driftTicksPerHour(samples: {ts: number; tick: Tick}[], windowH: number): number {
  const w = samples.filter(x => x.ts >= now() - windowH * 3600);
  if (w.length < 3) return 0;
  return theilSenSlope(w.map(x => [x.ts / 3600, x.tick]));          // median of pairwise slopes; wick-robust
}
// Realised volatility: σ_ticks(W) = stdev of per-hour tick changes (resampled to 1 h bars, last-value fill since swaps are sparse).
// Expected excursion over horizon H: E|Δtick| ≈ σ_h √H ; use σ from 24 h and 7 d windows, take the max.
```

Reference values (edge-strategy §2, 30-day PoolManager logs, cross-checked against GeckoTerminal): **1-h σ ≈ 156 t (1.57%)**, daily range median ≈ 670 t, p75 ≈ 780 t, max ≈ 2,900 t (Nov 5), annualised 147% (181% last 7 d). Drift is not a usable signal at this σ (the first draft's +2.9 t/h was 17 h of data). The bot recomputes σ over rolling 24 h / 7 d windows from its own T3 stream; if the 7-d annualised figure exceeds **170%** the core widens to ±780 t (edge-strategy §5).

---

## 3. Rebalance decision engine

### 3.1 Vocabulary (layout adopted from `edge-strategy.md` §5)

- **Core:** `[c − coreHalf, c + coreHalf]`, `coreHalf = 600` t (±6.18%), **$1,000**; `c` is the centre, chosen by the inventory-matched planner (§5.2), not necessarily `spot`. Widens to `780` t when 7-d realised vol > 170% annualised.
- **Anchor:** `[a − anchorHalf, a + anchorHalf]`, `anchorHalf = 2220` t (±24.9%), **$1,000**, centred on spot at mint. Always-in-range insurance and the **inventory buffer** (reserve = 0).
- **Staging slots:** dust-liquidity (`dustL` ≈ 1e13) positions at the core band shifted by `±stagingOffset = 300` t (i.e. `[c − 300, c + 900]` and `[c − 900, c + 300]`), minted **only when they contain spot** and subscribed in the same multicall. When the core later re-centres into one of them, the move is `DECREASE(core) → INCREASE(staging)` on an already-subscribed NFT, so `OutOfRange` cannot bite and the tokenId history stays long-lived. At most `maxParkedSlots = 6` dust slots are kept; the farthest are burned when a new one is needed.
- **Rejected:** build-plan §1.1 straddles A/B/C and this doc's first-draft `warn`/`arm`/`early` bands — see D11; all of them acted inside one hour of ordinary noise (1-h σ ≈ 156 t).
- **Triggers (per bracket, evaluated on every T0 sample):**
  - **Core hard:** `spot < core.lower || spot ≥ core.upper`, held continuously for **`dwellHardS = 3600`** (60 min; any sample back inside the band resets the timer). 64% of ±6% excursions return within the hour, so most never fire.
  - **Core immediate:** `spot` ≥ `immediateBeyondTicks = 200` t beyond a core edge (≈ 8% from centre) on **two consecutive samples** (≤ 15 s apart) → skip the dwell.
  - **Anchor:** `spot` within `anchorMarginTicks = 300` t of either anchor edge on two consecutive samples → re-centre the anchor immediately (it is the fallback; it must never go out of range).
  - **Sweep (not a rebalance):** every `coldEveryS`, if the anchor is in range and the core is not, and no trigger is pending, nothing happens — the anchor earns. There is no "degraded → act" path; only the triggers above move capital.
- **Cooldown and caps:** `minTimeBetweenRebalancesS = 7200` (2 h, per bracket **and** global); **`maxRebalancesPerDay = 3` (soft — an `immediate` or `anchor` trigger may exceed it once, alerting), `maxRebalancesPerWeek = 12` (hard — nothing exceeds it; alert and stay in the anchor).** Merkl: "frequent rebalancing, if mistaken for wash trading, may trigger blacklisting"; the active competitors do 1–2/day and are paid.
- **Minimum slot age:** `minSlotAgeS = 3600` before a slot that was just filled may be emptied again (reads as non-JIT; the dwell already guarantees this for core).
- **Expected frequency:** ±600 t breaches ≈ 5.8/week at zero hysteresis → ≈ 2/week after the 60-min dwell; anchor ≈ 0.23/week. Budget use ≈ 20% of the weekly cap.

### 3.2 Realised-volatility inputs (velocity/early-recentre logic removed)

```
σ_h       = stdev of 1-h tick changes over the last 7 d (fallback 24 h; floor 60 t, cap 600 t)     // ≈ 156 t today
volAnn    = σ_h × √8760 / 10000  (as a fraction)                                                 // ≈ 1.47–1.81 today
coreHalf  = volAnn > 1.70 ? 780 : 600                                                             // hysteresis: switch back below 1.50
expectedHoldH(half) = 168 / breachesPerWeek(half)                                                 // breaches/week table from §0.1 (5.8 @ 600 t, 4.0 @ 780 t, 0.23 @ 2220 t)
```

Drift (Theil–Sen slope) is still computed for the dashboard but is **not** a trigger input: at σ_h ≈ 156 t a 24-h slope has no predictive value for a ±600 t band.

### 3.3 Expected-value test (gate for every `hard` trigger; `immediate` and `anchor` bypass it but log it)

```
Gain_TEL  = (share_after − share_now) × budgetTelPerHour × H_eff
H_eff     = min(expectedHoldH(coreHalf), 72 h)                                 // ≈ 29 h @ 600 t at today's vol
share_now = estimateShare(current slots at spot)                              // core out of range ⇒ only the anchor's L counts
share_after = estimateShare(planned slots)                                    // uses liquidityAt(t) so the 1.85e18 wall is priced in
Cost_TEL  = gasUsd/telUsd + swapCostUsd/telUsd + ilUsd/telUsd + rebalanceBudgetPenalty
swapCostUsd = 0 in the default inventory-matched re-centre (§4.4 mode S0); fallback S1 = notional × fee + impact
ilUsd     = value lost by realising the current token mix at the new centre vs holding  — ≈ 0 for an inventory-matched move (nothing is sold), > 0 only in S1/S2
rebalanceBudgetPenalty = λ × (rebalancesThisWeek / maxRebalancesPerWeek) × Gain_TEL      // λ = 0.5
Pass iff Gain_TEL ≥ evMultiple × Cost_TEL, evMultiple = 3
```

Reference magnitudes: campaign budget 500k TEL/week (≈ $705–770 at $0.00141–0.00153) → 20% share ≈ **$0.9/h**; a 1.5M-gas bundle on Base costs **$0.02–0.40**; a $250 in-pool ratio swap would cost ≈ $0.9 fee + ≈ $1.8 impact (never done by default). With S0 the test is almost always passed when the core has been out for an hour; its real job is to block re-centres while the anchor alone already captures most of the available share (e.g. when the 1.85e18 wall is active and a re-centred core would add < 3 pp).

### 3.4 OutOfRange-at-subscribe constraint, handled structurally

Every slot that is **newly minted** in a bundle must satisfy `tickLower ≤ tick_post ≤ tickUpper − 1` where `tick_post` is the tick **after** the bundle's own liquidity changes (liquidity changes don't move tick; a swap in the same tx would — never put a swap between mint and subscribe, see §4.4). The planner asserts it and requires **`spot` ≥ `mintSafetyTicks = 60` from every new edge** so a short move before inclusion cannot flip `handleSubscribe` into `OutOfRange(tokenId)` (whole multicall reverts — no capital moves, but the attempt is wasted). Two structural helpers make this a non-issue in steady state: (i) **staging slots** mean a core re-centre is normally an `INCREASE_LIQUIDITY` on a subscribed NFT, which has **no** in-range requirement; (ii) the **anchor** is 2,220 t wide, so its re-mint is trivially in range. New mints with `subscribe` happen only at bootstrap, when staging has no slot for the chosen centre, or when the anchor moves.

### 3.5 State machine

```
            ┌────────────┐  kill/alert   ┌─────────┐
            │  HALTED    │◄──────────────┤  ANY    │
            └─────┬──────┘               └─────────┘
      switch off  │ reconcile ok
                  ▼
   ┌─────────────────────────┐  core out of range (anchor in)          ┌──────────────┐
   │ IN_RANGE_HEALTHY        ├─────────────────────────────────────────►│ CORE_OUT     │
   │ core+anchor in range,   │◄─────────────────────────────────────────┤ anchor earns;│
   │ subscribed, staging ok  │  spot back inside core (timer reset)     │ dwell timer  │
   └─────────────┬───────────┘                                          └──────┬───────┘
                 │ anchor edge within 300 t (×2 samples)                       │ held 60 min  OR
                 │                                                             │ ≥ 200 t beyond edge (×2 samples)
                 ▼                                                             ▼
   ┌─────────────────────────┐                                       ┌──────────────┐  guards fail  ┌──────────┐
   │ ANCHOR_TRIGGER          ├──────────────────────────────────────►│ ARMED        ├──────────────►│ DEFERRED │
   │ immediate, EV logged    │                                       │ guards (+EV  │               │ retry on │
   └─────────────────────────┘                                       │ for 'hard')  │               │ next T0  │
                                                                     └──────┬───────┘               └──────────┘
                                                                            │ pass
                                                                            ▼
   ┌──────────────┐  revert/timeout ×N ┌──────────────┐  simulate ok  ┌──────────────┐
   │ FAILED       │◄───────────────────┤ EXECUTING    │◄──────────────┤ PLANNED      │
   │ alert, re-   │                    │ txQueue      │               │ plan+simulate│
   │ reconcile    │                    └──────┬───────┘               └──────────────┘
   └──────────────┘                           │ receipt ≥ 3 blocks & ≥ 2 s
                                              ▼
                                      ┌──────────────┐  all invariants ok
                                      │ VERIFYING    ├────────────► IN_RANGE_HEALTHY (cooldown timer started)
                                      └──────┬───────┘
                                             │ unsubscribed / OOR / prunable slot found
                                             ▼
                                      ┌──────────────┐
                                      │ REPAIR       │ subscribe(id) / resubscribe(id) / top-up dust; max 3 attempts → HALTED
                                      └──────────────┘
```

`CORE_OUT` is a normal, expected state (≈ 5.8 entries/week, most shorter than an hour); it only becomes a page if the **anchor** is also out of range (zero in-range liquidity — should be impossible outside a > 25% gap move). Transitions are evaluated once per T0 sample; timers are persisted so a restart does not reset dwell.

```ts
export type EngineState = 'HALTED' | 'IN_RANGE_HEALTHY' | 'CORE_OUT' | 'ANCHOR_TRIGGER' | 'ARMED' | 'DEFERRED' | 'PLANNED' | 'EXECUTING' | 'VERIFYING' | 'REPAIR' | 'FAILED';

export interface Trigger { kind: 'none' | 'hard' | 'immediate' | 'anchor'; bracket: 'core' | 'anchor'; edge: 'lower' | 'upper'; heldSinceTs: number; consecutive: number }

export type Range = { lower: Tick; upper: Tick };
export function detectTrigger(spot: Tick, core: Range, anchor: Range, cfg: Thresholds, prev: Trigger, now: number): Trigger {
  const aLower = spot - anchor.lower, aUpper = (anchor.upper - 1) - spot;                 // ticks inside the anchor
  if (Math.min(aLower, aUpper) <= cfg.anchorMarginTicks)
    return next('anchor', 'anchor', aLower <= aUpper ? 'lower' : 'upper');
  const cLower = spot - core.lower, cUpper = (core.upper - 1) - spot;                     // negative ⇒ outside the core
  const d = Math.min(cLower, cUpper), edge = cLower <= cUpper ? 'lower' : 'upper';
  if (d < -cfg.immediateBeyondTicks) return next('immediate', 'core', edge);
  if (d < 0)                         return next('hard', 'core', edge);
  return { kind: 'none', bracket: 'core', edge, heldSinceTs: now, consecutive: 0 };     // any in-band sample resets the dwell
  function next(kind: Trigger['kind'], bracket: Trigger['bracket'], e: Trigger['edge']): Trigger {
    const cont = prev.bracket === bracket && prev.kind !== 'none' && prev.edge === e;   // 'hard' → 'immediate' keeps the timer
    return { kind, bracket, edge: e, heldSinceTs: cont ? prev.heldSinceTs : now, consecutive: cont ? prev.consecutive + 1 : 1 };
  }
}

export function shouldArm(t: Trigger, cfg: Thresholds, now: number): boolean {
  if (t.kind === 'hard')      return now - t.heldSinceTs >= cfg.dwellHardS;          // 60 min continuous
  if (t.kind === 'immediate') return t.consecutive >= 2;                              // two samples ≤ 15 s apart
  if (t.kind === 'anchor')    return t.consecutive >= 2;
  return false;
}

export function guards(state: BotState, cfg: Thresholds, now: number, ev: EvResult, trig: Trigger): { ok: boolean; reasons: string[] } {
  const r: string[] = [];
  const urgent = trig.kind === 'immediate' || trig.kind === 'anchor';
  if (state.killSwitch) r.push('kill');
  if (now - state.lastRebalanceTs[trig.bracket] < cfg.minTimeBetweenRebalancesS && !urgent) r.push('cooldown');
  if (state.rebalancesToday >= cfg.maxRebalancesPerDay && !urgent) r.push('dayCap');            // soft: urgent may exceed once, alerts
  if (state.rebalancesThisWeek >= cfg.maxRebalancesPerWeek) r.push('weekCap');                   // hard cap, even for urgent → alert, anchor carries
  if (state.ours.some(s => s.liquidity > 0n && !s.registrySubscribed)) r.push('unsubscribedSlot');
  if (!ev.pass && trig.kind === 'hard') r.push('ev');
  if (state.gasSpentTodayEth > cfg.dailyGasBudgetEth) r.push('gasBudget');
  if (now - state.lastFilledTs[trig.bracket] < cfg.minSlotAgeS && !urgent) r.push('slotAge');
  return { ok: r.length === 0, reasons: r };
}
```

---

## 4. Rebalance execution

### 4.1 Action opcodes and param encodings (v4-periphery `Actions.sol`, `PositionManager._handleAction`)

| Action | Opcode | `abi.encode(...)` params (from `_handleAction` decoders) |
|--------|--------|------------------------------------------------------------|
| `INCREASE_LIQUIDITY` | `0x00` | `(uint256 tokenId, uint256 liquidity, uint128 amount0Max, uint128 amount1Max, bytes hookData)` |
| `DECREASE_LIQUIDITY` | `0x01` | `(uint256 tokenId, uint256 liquidity, uint128 amount0Min, uint128 amount1Min, bytes hookData)` — `liquidity = 0` ⇒ collect fees only |
| `MINT_POSITION` | `0x02` | `(PoolKey poolKey, int24 tickLower, int24 tickUpper, uint256 liquidity, uint128 amount0Max, uint128 amount1Max, address owner, bytes hookData)` |
| `BURN_POSITION` | `0x03` | `(uint256 tokenId, uint128 amount0Min, uint128 amount1Min, bytes hookData)` — "will automatically decrease liquidity to 0"; fees are returned with principal; slippage is checked on `liquidityDelta − feesAccrued`; `notifyBurn` → registry `handleBurn` → unsubscribed |
| `SETTLE_PAIR` | `0x0d` | `(Currency currency0, Currency currency1)` — payer = `msgSender()` via Permit2 |
| `TAKE_PAIR` | `0x11` | `(Currency currency0, Currency currency1, address recipient)` — `recipient = 0x…01` (`ActionConstants.MSG_SENDER`) |
| `CLOSE_CURRENCY` | `0x12` | `(Currency currency)` — settles **or** takes whatever the net delta is; safe because slippage was enforced per action |
| `SWEEP` | `0x14` | `(Currency currency, address to)` — returns excess **native** ETH; not needed for eUSD/TEL (both ERC-20) |

Swap opcodes `0x06–0x09` **revert `UnsupportedAction`** in PositionManager — swaps live in V4Router/Universal Router only. `modifyLiquidities(bytes unlockData, uint256 deadline)` with `unlockData = abi.encode(bytes actions, bytes[] params)`; `multicall(bytes[] data)` (delegatecall-to-self, `msg.sender` preserved, so `subscribe`'s `onlyIfApproved(msg.sender, tokenId)` passes for the EOA). `subscribe(uint256 tokenId, address newSubscriber, bytes data)` is `onlyIfPoolManagerLocked` — it **must** be a sibling call after `modifyLiquidities`, never an action.

### 4.2 Bundle shapes

**Shape R (core re-centre into a staging slot — the default case):**

```
multicall([
  modifyLiquidities(encode(
    [DECREASE_LIQUIDITY(core, L_core − dustL, min0, min1, 0x),     // old core becomes a dust staging slot (stays subscribed, not prunable)
     DECREASE_LIQUIDITY(anchor, ΔL_anchor, min0, min1, 0x),       // optional: only if inventory matching needs the other token (§4.4)
     INCREASE_LIQUIDITY(staging_k, L_new − dustL, max0, max1, 0x), // the pre-subscribed slot that contains spot — no subscribe, no OutOfRange risk
     CLOSE_CURRENCY(eUSD), CLOSE_CURRENCY(TEL)]), deadline)
])
```

**Shape M (new ranges — bootstrap, anchor move, or no staging slot for the chosen centre):**

```
multicall([
  modifyLiquidities(encode(
    [DECREASE_LIQUIDITY(oldCore, L − dustL, …) | BURN_POSITION(oldAnchor, min0, min1, 0x) | BURN_POSITION(farthestStaging, …),
     MINT_POSITION(key, core.lo, core.hi, L_core, max0, max1, OWNER, 0x),
     MINT_POSITION(key, anchor.lo, anchor.hi, L_anchor, max0, max1, OWNER, 0x),
     MINT_POSITION(key, stagingLo.lo, stagingLo.hi, dustL, max0, max1, OWNER, 0x),   // only if it contains spot (§3.4)
     MINT_POSITION(key, stagingHi.lo, stagingHi.hi, dustL, max0, max1, OWNER, 0x),
     CLOSE_CURRENCY(eUSD), CLOSE_CURRENCY(TEL)]), deadline),
  subscribe(nextId,   SUBSCRIBER, 0x),
  subscribe(nextId+1, SUBSCRIBER, 0x),
  subscribe(nextId+2, SUBSCRIBER, 0x),
  subscribe(nextId+3, SUBSCRIBER, 0x),
])
```

`nextId = PositionManager.nextTokenId()` read in the **same** `eth_call` batch as the simulation; if a third party mints between simulation and inclusion, `subscribe(nextId)` hits a token we don't own → `onlyIfApproved` revert → whole multicall reverts → re-plan (no capital moved). PosM mints chain-wide on Base are a few per minute, inclusion latency is ≈ 1–3 s at 0.2 s blocks — a rare retry, not a design problem, and Shape R avoids it entirely. Burn/decrease credits net against mint/increase debits inside the unlock (flash accounting), so **no token transfer is needed for the part of the inventory that is re-used**; `CLOSE_CURRENCY` settles the residual debit from the wallet (Permit2) or pays the residual credit back to the wallet.

### 4.3 Liquidity from freed balances (LiquidityAmounts / SqrtPriceMath, v4-periphery `libraries/LiquidityAmounts.sol`)

```ts
// sqrt prices as Q96 bigints; use @uniswap/v4-sdk TickMath.getSqrtRatioAtTick for exactness (never Math.pow in production).
export function amountsForLiquidity(sP: Q96, lo: Tick, hi: Tick, L: bigint): { a0: bigint; a1: bigint } {
  const sA = sqrtAtTick(lo), sB = sqrtAtTick(hi);
  if (sP <= sA) return { a0: amount0Delta(sA, sB, L), a1: 0n };
  if (sP >= sB) return { a0: 0n, a1: amount1Delta(sA, sB, L) };
  return { a0: amount0Delta(sP, sB, L), a1: amount1Delta(sA, sP, L) };
}
const amount0Delta = (sA: Q96, sB: Q96, L: bigint) => (L << 96n) * (sB - sA) / sB / sA;    // L·(1/√a − 1/√b), rounded down
const amount1Delta = (sA: Q96, sB: Q96, L: bigint) => L * (sB - sA) >> 96n;               // L·(√b − √a)
export function liquidityForAmounts(sP: Q96, lo: Tick, hi: Tick, a0: bigint, a1: bigint): bigint {  // = LiquidityAmounts.getLiquidityForAmounts
  const sA = sqrtAtTick(lo), sB = sqrtAtTick(hi);
  if (sP <= sA) return a0 * sA / (1n << 96n) * sB / (sB - sA);
  if (sP >= sB) return (a1 << 96n) / (sB - sA);
  return min(a0 * sP / (1n << 96n) * sB / (sB - sP), (a1 << 96n) / (sP - sA));
}

/** Plan mints from the inventory the decreases/burns will free (predicted at current tick) plus any wallet dust (reserve target is 0, R6). */
export function planMints(sP: Q96, brackets: Bracket[], freed: {a0: bigint; a1: bigint}, wallet: {a0: bigint; a1: bigint}, cfg: Thresholds) {
  const avail = { a0: freed.a0 + wallet.a0, a1: freed.a1 + wallet.a1 };
  // capital weights w_i (core 0.5 / anchor 0.5) → per-bracket budget in each token; the bracket's own geometry fixes its a0:a1 ratio at sP.
  // Solve the single scalar k such that Σ_i amounts(L_i = k·w_i·L̂_i) ≤ avail in BOTH tokens, where L̂_i = liquidityForAmounts(sP, lo_i, hi_i, 1 unit USD split by the bracket's natural ratio).
  const UNIT = 10n ** 18n;
  const perUnit = brackets.map(b => amountsForLiquidity(sP, b.lo, b.hi, UNIT));                       // a0, a1 needed per 1e18 L
  // weights are USD weights; convert to L-weights so each bracket gets w_i of the USD, not w_i of the L
  const usdPerUnit = perUnit.map(u => usd(u));
  const lw = brackets.map((b, i) => b.weight / usdPerUnit[i]);                                        // L per USD-weight
  const need0 = Σ_i lw[i] · perUnit[i].a0,  need1 = Σ_i lw[i] · perUnit[i].a1;                        // token needs for k = 1
  const k = Math.min(Number(avail.a0) / need0, Number(avail.a1) / need1);                              // binding token
  const L = brackets.map((_, i) => BigInt(Math.floor(k * lw[i] * 1e9)) * UNIT / 10n ** 9n);           // L_i = k·lw_i UNITs, as bigint
  const used = sumAmounts(brackets.map((b, i) => amountsForLiquidity(sP, b.lo, b.hi, L[i])));
  const leftover = { a0: avail.a0 - used.a0, a1: avail.a1 - used.a1 };                                 // the non-binding token's excess
  return { L, used, leftover, imbalanceUsd: usd(leftover) };
}
```

Then: `amount0Max/amount1Max = used × (1 + slippageBps/1e4)` per mint; `amount0Min/amount1Min = predicted × (1 − slippageBps/1e4)` per burn/decrease. Because the pool is thin and spot can move 10–60 ticks between simulation and inclusion when a swap lands (1-h σ ≈ 156 t), use **`slippageBps = 100`** on liquidity legs (cost is just a revert) and re-plan on revert.

### 4.4 Inventory-matched re-centring first; ratio swaps only as fallback

The core re-centre is **inventory-matched by default** (edge-strategy §5): after the core exits on, say, the upper side (TEL fell), the old core holds ≈ 100% TEL. Instead of swapping half to eUSD, the planner (§5.2) searches core centres `c ∈ [spot − 300, spot + 300]` (step 60) for the one whose natural a0:a1 ratio at `spot` best matches what the decrease frees, with the anchor supplying the deficit token via a bounded `DECREASE_LIQUIDITY` (anchor holds both tokens at all times — it *is* the reserve). `imbalanceUsd` from `planMints` is whatever is still left idle. Decision:

| Case | Condition | Mode | Txs |
|------|-----------|------|-----|
| **S0 inventory-matched (default)** | offset search finds `c` with `imbalanceUsd ≤ swapToleranceUsd (= $150)` **and** ≥ 1% of core value on the near side; anchor `DECREASE` ≤ `anchorDrawMaxFraction = 0.25` of anchor L | Shape R/M only; leftover stays in wallet and is swept into the anchor at the next anchor move | 1 |
| **S1 off-pool swap** | no matching `c` (e.g. gap move > 600 t leaves 100% one token and the anchor cannot cover) | tx1: UR swap on a **deeper venue** (never this pool) **before** the bundle, so post-swap tick is known; tx2: PosM bundle at 50/50 | 2 |
| **S2 three-step** | S1 but the inventory is locked in slots that must be emptied first (anchor move + core move at once) | tx1: PosM `[DECREASE/BURN×n, TAKE_PAIR]` → tx2: UR swap → tx3: PosM `[MINT×n, CLOSE×2] + subscribe×n` | 3 (≈ 1–2 min incl. confirmations; the anchor stays in place if at all possible so in-range liquidity never reaches 0) |

Rules: (i) **never** place a swap between a mint and its `subscribe` — the post-swap tick is what `handleSubscribe` checks; (ii) **never** swap for inventory through *this* pool (`maxInPoolSwapUsd = 0`; a $100 swap is ≈ 56 ticks of impact and the counterparty is partly ourselves); route `TEL → ETH (v4 ETH/TEL, $68k TVL) → eUSD` or any deeper TEL venue, chosen by **quote** (`V4Quoter.quoteExactInputSingle` / `quoteExactInput` from v4-periphery `lens/V4Quoter.sol`, `eth_call` only); (iii) `amountOutMinimum = quote × (1 − swapSlippageBps/1e4)`, `swapSlippageBps = 50`; (iv) UR calldata: `execute(bytes commands, bytes[] inputs, uint256 deadline)` with command `V4_SWAP = 0x10` and actions `[SWAP_EXACT_IN_SINGLE 0x06, SETTLE_ALL 0x0c, TAKE_ALL 0x0f]`; `ExactInputSingleParams{poolKey, zeroForOne, amountIn, amountOutMinimum, hookData}` on the Jan-2025 deployment (**confirm against deployed UR ABI** — current main adds `minHopPriceX36`); UR `0x6fF5693b99212Da76ad316178A184AB56D299b43` has code on Base (19.5 kB) — confirm it is the v2 router with `V4_SWAP` before wiring; (v) `V4_POSITION_MANAGER_CALL (0x14)` cannot carry our bundle (`OnlyMintAllowed` rejects `DECREASE`/`BURN`/`INCREASE`; no `subscribe`), so **UR+PosM single-tx is off the table without a custom executor** (out of scope). The UR address is needed only for S1/S2 (R7): with `NoopSpark` and S0 as default it can stay unconfigured in phase 1 and S1/S2 simply `DEFER` with an alert.

**Permit2 (one-time, per token):** `IERC20.approve(PERMIT2, MaxUint256)` then `IAllowanceTransfer.approve(token, PosM, uint160 amount, uint48 expiration)` for eUSD and TEL → PosM; for the UR swap path also `approve(token, UR, …)`. `SETTLE_PAIR`/`CLOSE_CURRENCY` pull via `permit2.transferFrom(payer, PosM, amount, token)`. Expiration ≤ 30 d; the T4 job re-checks `allowance(owner, token, spender)` and alerts 3 d before expiry. Alternatively sign a `PermitBatch` and prepend `PositionManager.permitBatch(owner, permitBatch, sig)` as the first multicall element (`Permit2Forwarder`) — avoids standing allowances but adds a signature per bundle.

### 4.5 Deadline, gas, simulation, nonce, revert, verification

```ts
export interface RebalancePlan {
  shape: 'R' | 'M' | 'S1' | 'S2'; mode: 'S0' | 'S1' | 'S2'; spotTick: Tick; sqrtPriceX96: Q96; block: bigint;
  burns: bigint[]; decreases: {tokenId: bigint; liquidity: bigint; min0: bigint; min1: bigint}[];
  increases: {tokenId: bigint; liquidity: bigint; max0: bigint; max1: bigint}[];
  mints: {lo: Tick; hi: Tick; liquidity: bigint; max0: bigint; max1: bigint; role: SlotState['role']}[];
  predictedTokenIds: bigint[]; swap?: {route: 'inPool' | 'viaEth' | 'external'; zeroForOne: boolean; amountIn: bigint; amountOutMin: bigint};
  expected: { walletDelta0: bigint; walletDelta1: bigint; ourActiveLAfter: bigint; shareAfter: ShareEstimate };
  planHash: Hex;                      // keccak of the above → idempotency key in txQueue
}

async function simulateAndSend(plan: RebalancePlan, deps) {
  const deadline = BigInt(nowSec() + cfg.deadlineS);                                 // 120 s: long enough for RBF, short enough that a stale plan dies
  const calls = encodeMulticall(plan);
  // 1. simulate on the live node, at 'latest', from the EOA — catches OutOfRange, MaximumAmountExceeded, MinimumAmountInsufficient, stale nextTokenId, DeadlinePassed
  const sim = await client.simulateContract({ address: POSM, abi: posmAbi, functionName: 'multicall', args: [calls], account: signer.address });
  // 2. optional second opinion on an anvil fork pinned to the same block (CI/soak; also measures gas for maxTxCostEth)
  // 3. gas: estimateGas × 1.25; maxFeePerGas = baseFee×2 + tip; refuse if gas×maxFee > maxTxCostEth
  const gas = (await client.estimateGas({ ...sim.request })) * 125n / 100n;
  if (gas * maxFeePerGas > cfg.maxTxCostWei) return defer('gasCap');
  // 4. txQueue: single mutex; nonce = getTransactionCount('pending') cached + local increment; idempotency by planHash (never resend a plan that already has a known hash in flight)
  const hash = await txQueue.send({ planHash: plan.planHash, request: { ...sim.request, gas, maxFeePerGas, maxPriorityFeePerGas } });
  // 5. wait: receipt; if not mined in 20 s (≈ 100 blocks at 0.2 s) → RBF same nonce +12.5 % fees (max 3 bumps) ; if dropped → re-plan from scratch (tick may have moved)
  const receipt = await txQueue.waitWithRbf(hash, { afterS: 20, bumps: 3 });
  if (receipt.status === 'reverted') { state.failures++; return reconcileAndReplan(); }  // decode revert: OutOfRange→wait for dwell; MaximumAmountExceeded→widen slippage once; stale id→reread nextTokenId
  await client.waitForBlocks(3, { minMs: 2000 });                                      // reorg guard: ≥ 3 blocks and ≥ 2 s
  return verify(plan, receipt);
}

async function verify(plan, receipt): Promise<'ok' | 'repair' | 'fail'> {
  const ids = decodeTransferLogs(receipt, POSM, signer.address).map(l => l.tokenId);   // real minted ids (ERC721 Transfer from 0x0)
  assert(equalSets(ids, plan.predictedTokenIds));
  const slots = await readOurSlots(client, [...ids, ...plan.increases.map(i => i.tokenId)]);
  const s0 = await readSlot0(client, poolId);
  for (const s of slots) {
    if (s.liquidity < plan.liquidityFor(s.tokenId) * 99n / 100n) return 'fail';
    if (s.subscriberAddr.toLowerCase() !== SUBSCRIBER.toLowerCase() || !s.registrySubscribed) return 'repair';   // subscribe(id) if in range; else wait
    if (s.prunable) return 'repair';                                                                               // top-up above dustL
  }
  const inRange = slots.filter(s => s.tickLower <= s0.tick && s0.tick < s.tickUpper).length;
  if (inRange === 0) return 'repair';
  const bal = await readWalletBalances(); assertWithin(bal − before, plan.expected.walletDelta, tolerance = slippage);
  persist({ slots, lastRebalanceTs: now(), rebalancesToday++, rebalancesThisWeek++, gasSpentTodayEth += receipt.gasUsed × receipt.effectiveGasPrice });
  return 'ok';
}
```

---

## 5. Bracket geometry

### 5.1 Alignment

All edges are multiples of `tickSpacing = 60`; usable range `[-887220, 887220]`. `center = snapDown(spot)` (so `center ≤ spot < center + 60`). Default widths in ticks (not percent) — see D2.

### 5.2 Core (inventory-matched offset) + anchor — straddles A/B/C rejected (D11)

```ts
export interface Bracket { role: 'core' | 'anchor' | 'staging'; lo: Tick; hi: Tick; weight: number }

/** Anchor: symmetric around spot, re-centred only when spot is within anchorMarginTicks of an edge. */
export function planAnchor(spot: Tick, g: Geometry): Bracket {
  const c = snapDown(spot, 60);
  return { role: 'anchor', lo: c - g.anchorHalf, hi: c + 60 + g.anchorHalf, weight: g.wAnchor };      // [−2220, +2280) around c
}

/**
 * Core: width 2·coreHalf, centre offset so that the token ratio the new range needs at `spot`
 * matches the inventory the old core frees (plus a bounded anchor draw) — no swap (S0, §4.4).
 * TEL-heavy inventory (TEL fell, spot moved up) ⇒ a range mostly ABOVE spot holds mostly token1 ⇒ shift centre up.
 */
export function planCore(spot: Tick, sP: Q96, inv: {a0: bigint; a1: bigint}, anchorAvail: {a0: bigint; a1: bigint}, g: Geometry): { core: Bracket; anchorDraw: {a0: bigint; a1: bigint}; imbalanceUsd: number } | null {
  const half = g.coreHalf;                                                                          // 600, or 780 when 7-d vol > 170 %
  let best = null;
  for (let off = -g.maxCoreOffsetTicks; off <= g.maxCoreOffsetTicks; off += 60) {                  // ±300 t search
    const c = snapDown(spot, 60) + off;
    const core = { role: 'core', lo: c - half, hi: c + 60 + half, weight: g.wCore };
    if (!(core.lo + g.mintSafetyTicks <= spot && spot < core.hi - g.mintSafetyTicks)) continue;    // must contain spot with margin (§3.4)
    const need = amountsForLiquidity(sP, core.lo, core.hi, UNIT);                                   // natural a0:a1 at spot for this geometry
    const nearSideUsd = Math.min(usd({a0: need.a0, a1: 0n}), usd({a0: 0n, a1: need.a1})) / usd(need);
    if (nearSideUsd < 0.01) continue;                                                               // never a one-sided core (edge-strategy §5)
    const draw = deficitCoveredByAnchor(inv, need, anchorAvail, g.anchorDrawMaxFraction);           // bounded DECREASE on anchor
    const { imbalanceUsd } = planMints(sP, [core], { a0: inv.a0 + draw.a0, a1: inv.a1 + draw.a1 }, ZERO, cfg);
    if (!best || imbalanceUsd < best.imbalanceUsd) best = { core, anchorDraw: draw, imbalanceUsd };
  }
  return best;                                                                                      // caller: if best.imbalanceUsd > swapToleranceUsd → S1/S2 (§4.4)
}

/** Staging: dust copies of the core band shifted ±stagingOffset, minted only while they contain spot. */
export function planStaging(spot: Tick, core: Bracket, g: Geometry): Bracket[] {
  return [-g.stagingOffsetTicks, g.stagingOffsetTicks]
    .map(o => ({ role: 'staging', lo: core.lo + o, hi: core.hi + o, weight: 0 }))
    .filter(b => b.lo + g.mintSafetyTicks <= spot && spot < b.hi - g.mintSafetyTicks);
}
```

Coverage after mint: core `[c − 600, c + 660)` (±6.2%), anchor `[c − 2220, c + 2280)` (±25%). When spot leaves the core, the anchor (L ≈ 0.13e18 ≈ 22% of our book) keeps earning on all three axes until the core is re-centred — the state the 60-min dwell in §3 is tuned to. The anchor is breached ≈ 0.23×/week; a core exit never leaves us with zero in-range liquidity.

**Why not the straddles:** A/B/C ([−1.8%, +1.8%] core plus two 4.3% wings, 50/25/25) ranks **top-3 in gross TEL** in every replay window (108–138k TEL/week) but is **net-negative in every window** (−$32 to −$532/week after IL and re-centring costs; edge-strategy §3.2). The ±1.5–1.8% core is breached ≈ 43×/week at 150–180% annualised vol; the liquidity-axis gain saturates as `L/(L + L_others)` while IL grows ∝ 1/r², so narrowing past ≈ ±6% buys share that is more than paid back in IL. The two-bracket layout gives up ≈ 30% of the gross TEL for a positive net.

### 5.3 Token-side tilt (free with inventory matching)

The offset search in `planCore` already tilts the core toward the token the inventory holds. Edge-strategy §7 item 4 notes a second, free effect: the 25/25 axes pay for the **scarcer in-range token**, so when the 1.85e18 wall (`0xd0c5…`, mostly eUSD, active only when TEL rallies ≥ 3.2%) is out of range, TEL is scarce in range and a TEL-tilted core gains ≈ 1–2 pp of share at no extra IL. Implement as a tie-break in `planCore`: among candidates within `imbalanceUsd ≤ swapToleranceUsd`, prefer the one whose `(a0, a1)` raises `0.25·tok0Share + 0.25·tok1Share` most (§2.2). Bounded by `maxCoreOffsetTicks = 300`.

### 5.4 Recomputing after a move; slot reuse; continuity

- **Core re-centre:** `planCore` picks `c`. If a staging slot has **identical** `(lo, hi)` → Shape R (`DECREASE` old core to `dustL`, `INCREASE` staging); else Shape M (`MINT` + `subscribe`, only if spot is ≥ `mintSafetyTicks` inside). The old core becomes a staging slot (dust). Then `planStaging` mints any missing dust slot that contains spot. Staging slots that no longer contain spot are kept (they may again); if the count exceeds `maxParkedSlots (= 6)`, **BURN** the farthest first (never one that contains spot).
- **Anchor move:** always Shape M (`BURN` old anchor → `MINT` new → `subscribe`), 2,220 t wide so in-range at mint is trivial; done in the same multicall as a core move when both trigger.
- **Dust floor:** `dustL = max(minLiquidity[pool] × minLiquidityHeadroom, 1e13)` — `1e13` L ≈ $0.01 here; `_meetsMinimum` is false at `L = 0`, so a staging slot must never be fully emptied unless burned. Re-read `minLiquidity` every T1; if the admin raises it above a staging slot's L, top-up or burn before anyone can `pruneSubscription`.
- **Continuity invariant:** at every sample ≥ 1 slot with `L ≥ activeL × minActiveShareFloor (= 5%)` is in range — normally the anchor; except during an in-flight S2 sequence (bounded by `maxGapS = 600`, alert beyond).
- **Capital split** `0.50 / 0.50` of the mint-time USD value (core / anchor). Inside `±coreHalf` the density is `L_core + L_anchor`, outside it `L_anchor` only.

---

## 6. Safety and observability

### 6.1 Invariants checked every loop (T1 cadence)

| Invariant | Read | On violation |
|-----------|------|--------------|
| every slot with `L > dustL`: `PositionManager.subscriber(id) == 0x19ED…` **and** registry `isTokenSubscribed(id)` | PosM + registry | `REPAIR`: `subscribe(id, SUBSCRIBER, 0x)` if in range (one tx); `resubscribe(id)` if PosM says subscribed but registry does not; page if 3 attempts fail |
| no slot `belowSubscriptionThreshold(id)` | registry | top-up to `dustL × 2` (INCREASE) or burn |
| in-range slot count ≥ 1 and `ourActiveL / activeL ≥ minActiveShareFloor` | slot0 + slots | state → `CORE_OUT`/`ARMED` per §3; page if 0 in range (anchor out) for > `maxGapS` |
| `nextTokenId` monotonic; all our `tokenIds` owned by signer (`ownerOf`) | PosM | HALT (ownership drift = key or approval compromise) |
| wallet balances within `balanceDriftUsd (= $50)` of `expected` (positions' amounts + wallet leftover + fees owed − gas) | ERC20 + §4.3 | alert; HALT if > 5% of capital |
| `poolKeys(bytes25(poolId))` and `keccak256(PoolKey)` unchanged; registry `poolAllowed`, `inRangeRequired`; Merkl campaign params (`type`, `subscriptionContract`, weights, `isOutOfRangeIncentivized`) unchanged | PosM/registry/Merkl API (hourly) | HALT new rebalances; alert (campaign drift means the strategy may be wrong) |
| `block.timestamp − lastSlot0.ts < 45 s` (data freshness, 12 s poll + 2 retries), ≥ 1 keyed endpoint healthy | `RpcPool` | rotate; HALT sends if every endpoint is in cooldown |
| rebalance counters ≤ caps; gas spent today ≤ budget | state | DEFER |

### 6.2 Kill switches

`state/KILL` file **or** `KILL_SWITCH=1` env **or** an on-chain sentinel (any ERC-20 `balanceOf(sentinelAddr) > 0`, lets ops stop the bot from a phone wallet) → `HALTED`: reads continue, **no sends**, heartbeat keeps publishing. Auto-halts: 3 consecutive reverts; verification `fail`; ownership drift; balance drift > 5%; Merkl params drift; `maxRebalancesPerWeek` reached by an `immediate`/`anchor` trigger (needs a human to raise the cap or widen geometry).

### 6.3 Alerting hooks

`Alerter.notify(level, code, ctx)` → webhook (Slack/Telegram, `RECONCILE` channel with build-plan Q11). **Page:** unsubscribed live slot, 0 in range > `maxGapS`, HALT, all RPC endpoints down, ownership drift. **Warn (data):** swap-log count disagreeing > 20% with the cross-check source (§1.8). **Warn:** DEFERRED > 1 h, EV fail on `hard`, day-cap exceeded by an urgent trigger, RBF bump, RPC failover, staging slot prunable. **Info:** state transitions, each rebalance with plan hash + Basescan link. Deadman: heartbeat every loop to a dead-man's-switch endpoint; silence > 10 min pages.

### 6.4 Metrics to log (JSONL, every T0 sample compressed to 1/min unless state ≠ healthy)

`ts, block, tick, sqrtPriceX96, activeL, ourActiveL, liqShare, tok0Share, tok1Share, merklShareEst, perSlot{tokenId, role, lo, hi, L, inRange, feesOwed0, feesOwed1}, edgeDistances, driftTph24h, sigmaH24h, sigmaH7d, volAnn7d, coreHalfActive, dwellHeldS, engineState, trigger, evGain, evCost, guardsReasons, lastSwapAgeS, swaps24h, swaps24hCrossCheck, volume24hUsd, rebalancesToday, rebalancesThisWeek, gasSpentTodayEth, rpc{endpoint, score, usedToday, cooldowns}`. Plus one row per Merkl API poll of our address's claimed/pending TEL (for realised-share tuning: `realisedShare = ourRewards / dailyBudget`, compared with `merklShareEst` integrated over the same day — the primary tuning signal for the share model in §2.2).

### 6.5 Dry-run mode

`mode: 'dry-run'` runs the full loop including plan, encode, `simulateContract` and gas estimate, writes the would-be bundle (`calls[]`, decoded) to the log, and increments shadow counters; `txQueue.send` is a no-op that returns a fake hash. A second flag `mode: 'fork'` points the wallet at an `anvil --fork-url` node and really sends there (Phase 2/3 of the build plan).

---

## 7. Configuration surface

```ts
export interface BotConfig {
  chain: { id: 8453; multicall3: Address; blockTimeS: 0.2 /* measured 2026-11-08; informational — all timing config is in seconds */ };
  rpc: RpcConfig;
  contracts: { poolManager: Address; positionManager: Address; stateView: Address; permit2: Address; universalRouter?: Address /* only for S1/S2; R7 */; v4Quoter?: Address;
               registry: Address; subscriber: Address; merklDistributor: Address };
  pool: { poolId: PoolId; key: PoolKey; token0: { symbol: 'eUSD'; decimals: 6 }; token1: { symbol: 'TEL'; decimals: 18 }; merklOpportunityId: string;
          expectedWeights: { fees: 5000; token0: 2500; token1: 2500 }; weeklyBudgetTel: number /* read from Merkl API; fallback 500_000 */ };
  geometry: Geometry; thresholds: Thresholds; execution: Execution; safety: Safety; spark: { kind: 'noop' } /* NoopSpark — not built (D4) */;
  mode: 'dry-run' | 'fork' | 'live';
}

export interface RpcConfig {                       // §1.9 — no paid RPC
  keyed: RpcEndpoint[];                            // ≥ 2 of: Alchemy (30M CU/mo, 300 CU/s), Infura (3M credits/day), dRPC (210M CU/30d), Ankr (200M credits/mo, 30 rps); URLs from env
  public: RpcEndpoint[];                           // mainnet.base.org (maxRps 1), base-rpc.publicnode.com (maxRps 2, WS); llamarpc/1rpc disabled by default (see §1.9 table)
  perEndpoint: { maxRps: number /* 2 */; burst: number /* 5 */; requestTimeoutMs: 8_000; maxAttempts: 4; backoffBaseMs: 250 };
  health: { ewmaAlpha: 0.2; lagDemoteBlocks: 25 /* 5 s at 0.2 s/block */; cooldown429MaxS: 60; cooldownTimeoutMaxS: 30; cooldownNonJsonS: 600; cooldown402: 'utc-midnight'; failuresToAlert: 5; scoreFloor: 0.05 };
  budgets: { alchemyCuPerMonth: 30_000_000; infuraCreditsPerDay: 3_000_000; drpcCuPer30d: 210_000_000; ankrCreditsPerMonth: 200_000_000; reserveFraction: 0.25 /* stop using a keyed endpoint at 75 % of its quota */ };
  logsLane: 'keyed';                               // eth_getLogs only through keyed endpoints (public ones truncate or cap ranges); maxLogRange 10_000
  sendLane: 'keyed';                               // eth_sendRawTransaction / receipts only through keyed endpoints
  crossCheck: { geckoTradesUrl: string; everyS: 3600; maxDisagreementPct: 20 };   // §1.8 swap-log reliability check
}

export interface Geometry {                        // adopted from edge-strategy.md §5
  tickSpacing: 60;
  coreHalf: number;          // 600  → ±6.18 %. Breached ≈ 5.8×/week at zero hysteresis, ≈ 2×/week after the 60-min dwell; the replay's best net $/week among 1.5–12 %.
  coreHalfHighVol: number;   // 780  → ±8.1 %, used while volAnn7d > 1.70 (switch back below 1.50).
  anchorHalf: number;        // 2220 → ±24.9 %. Breached ≈ 0.23×/week; always-in-range insurance and the inventory buffer (reserve = 0).
  wCore: 0.5; wAnchor: 0.5;  // USD split at mint ($1,000 / $1,000)
  mintSafetyTicks: number;   // 60   → one spacing: a short move before inclusion still cannot make handleSubscribe revert OutOfRange.
  maxCoreOffsetTicks: number;// 300  → inventory-matching search range for the core centre (§5.2); also the token-side tilt bound (§5.3)
  minNearSideFraction: number;// 0.01 → never mint a one-sided core (edge-strategy §5: "don't mint one-sided B/C")
  anchorDrawMaxFraction: number; // 0.25 → at most a quarter of the anchor's L may be DECREASEd to fund a core refill in one move
  staging: { offsetTicks: 300; dustL: bigint /* 1e13 */; maxParkedSlots: 6 };   // pre-subscribed dust slots at core ± 300 t; R4: 5–7 is fine
}

export interface Thresholds {                      // adopted from edge-strategy.md §5–§6 (R1)
  dwellHardS: number;               // 3600 (60 min): core outside its band continuously. 64 % of ±6 % excursions return within 1 h — most never fire.
  immediateBeyondTicks: number;     // 200  : spot ≥ 200 t beyond a core edge (≈ 8 % from centre) on 2 consecutive samples → skip the dwell.
  anchorMarginTicks: number;        // 300  : spot within 300 t of an anchor edge on 2 consecutive samples → re-centre anchor immediately.
  confirmSamples: number;           // 2    : consecutive T0 samples (≤ 15 s apart) for the immediate/anchor paths.
  sigmaWindowsH: [24, 168];         // σ_h from 7 d, fallback 24 h; floor 60 t, cap 600 t
  volHighEnter: number;             // 1.70 : annualised 7-d vol above which coreHalf → coreHalfHighVol
  volHighExit: number;              // 1.50 : and below which it returns to coreHalf
  minTimeBetweenRebalancesS: number;// 7200 (2 h) per bracket and global; immediate/anchor triggers bypass it (alert).
  minSlotAgeS: number;              // 3600 (1 h): never empty a slot younger than 1 h (JIT optics); the dwell already guarantees this for core.
  maxRebalancesPerDay: number;      // 3 (soft; immediate/anchor may exceed once → warn)   — Merkl "frequent rebalancing may be blacklisted"; competitors do 1–2/day
  maxRebalancesPerWeek: number;     // 12 (hard; nothing exceeds it → anchor carries, page)
  evMultiple: number;               // 3 : gain must be ≥ 3× cost (gates 'hard' only).
  evBudgetLambda: number;           // 0.5
  evMaxHoldH: number;               // 72 : cap on H_eff
  swapToleranceUsd: number;         // 150 : idle inventory accepted rather than swapped (R6: keep 150)
  maxInPoolSwapUsd: number;         // 0   : never swap for inventory through this pool (56-t impact per $100)
  reserveTargetUsd: number;         // 0   : fully deployed (R6); the anchor is the inventory buffer
  minActiveShareFloor: number;      // 0.05 : below this our in-range L is noise → treat as 0-in-range.
  maxGapS: number;                  // 600 (10 min): longest tolerated zero-in-range stretch (S2 only).
}

export interface Execution {
  deadlineS: 120; liquiditySlippageBps: 100; swapSlippageBps: 50; gasMultiplier: 1.25; rbf: { afterS: 20; bumpPct: 12.5; maxBumps: 3 };
  confirmations: { blocks: 3; minS: 2 }; maxTxCostEth: 0.002 /* ≈ $6; a 1.5M-gas bundle is $0.02–0.4 */; dailyGasBudgetEth: 0.01;
  permit2: { expirationDays: 30; renewBeforeDays: 3 }; swapRoute: 'viaEth' | 'external' | 'off' /* 'inPool' removed */; swapMode: 'S0-only' | 'S0+S1' | 'S0+S1+S2' /* default 'S0-only' until R7 verified */;
  cadenceProfile: 'low-rpc' | 'fast-poll';         // default 'low-rpc'
  lowRpc:   { slot0PollS: 12; jitterS: 2.5; warmEveryS: 60; coldEveryS: 720; logsPollS: 60; receiptPollS: 4 };       // ≈ 455 req/h
  fastPoll: { slot0PollS: 2;  jitterS: 0;   warmEveryS: 30; coldEveryS: 300; logsPollS: 60; receiptPollS: 1; wsLogs: boolean }; // ≈ 2,050 req/h, opt-in
  logsBackfillS: 604_800; logsChunk: 10_000;      // 7 d ≈ 3.0M blocks → ≈ 300 chunked requests at startup, keyed lane
}

export interface Safety {
  killFile: string; killEnv: string; killSentinel?: { token: Address; holder: Address };
  balanceDriftUsd: 50; balanceDriftHaltPct: 5; maxConsecutiveReverts: 3; maxRepairAttempts: 3;
  staleDataS: 45; deadmanS: 600; alertWebhook: string /* env */;
  merklAssert: { everyS: 3600; failClosed: true };
}
```

**Zod rules:** every `Address` non-zero and checksummed; `coreHalf < coreHalfHighVol < anchorHalf`, all `% 60 === 0`, `mintSafetyTicks ≥ 60`; `immediateBeyondTicks ≥ 60`; `anchorMarginTicks ≥ maxCoreOffsetTicks` (an anchor move must not be triggered by a core offset alone); `staging.offsetTicks % 60 === 0 && staging.offsetTicks ≤ coreHalf`; `wCore + wAnchor === 1`; `dwellHardS ≥ 3 × lowRpc.slot0PollS × confirmSamples`; `maxRebalancesPerDay × 7 ≥ maxRebalancesPerWeek` or warn; `rpc.keyed.length ≥ 2`; `lowRpc.slot0PollS ∈ [10, 15]`; `expectedWeights` must equal the Merkl API or the process refuses to start; `spark.kind === 'noop'` (any other value fails validation — the spark is not built).

---

## 8. Open items — status after `edge-strategy.md` (2026-11-08)

| # | Item | Resolution |
|---|------|------------|
| R1 | `Thresholds` defaults | **Resolved** — adopted edge-strategy §5/§6: core ±600 t, 60-min dwell, 200-t immediate, anchor ±2220 t re-centred within 300 t, cooldown 2 h, caps 3/day soft, 12/week hard (§3.1, §7). |
| R2 | Merkl token0/token1 denominator | **Resolved** — in-range denominators reproduce the leaderboard to ±0.3 pp (edge-strategy §4); `tok0ShareLB/tok1ShareLB` removed (§2.2). Canary still logs `realisedShare` vs estimate (§6.4). |
| R3 | Volume spark | **Resolved — not built.** `NoopSpark` is permanent; config rejects any other value (§7). |
| R4 | Dust staging slots vs Merkl gaming heuristics | **Accepted** — competitor `0xbbe5…` runs 13 and is paid; `maxParkedSlots = 6`. Keep watching the leaderboard for our address during canary. |
| R5 | Deployed Base PosM / UR versions: pin tags, confirm `ExactInputSingleParams` layout and `Actions` set on the deployed bytecode | Open — Phase 2 fork tests (unchanged). |
| R6 | Reserve | **Resolved** — `reserveTargetUsd = 0`; anchor is the inventory buffer; `swapToleranceUsd` stays 150. |
| R7 | UR address `0x6fF5…9b43` is the v2 router with `V4_SWAP` | Open but **non-blocking**: with `NoopSpark` and `swapMode: 'S0-only'` the UR is unused in phase 1; verify before enabling S1/S2. |
| R8 | **Block time.** Every upstream doc assumed 2 s; measured 0.2 s since ≈ 2026-11-06. This doc now uses seconds everywhere; `bot-blueprint.md`/`build-plan.md`/`edge-strategy.md` still say "≈ 600 blocks = 20 min" etc. | coordinator → fix wording in the other docs; no design change there. |
| R9 | **Volatility inputs are second-hand but verified.** This doc's first-draft 7-day scan was a 17-h scan (R8). The adopted σ/range/breach figures come from edge-strategy's 30-d scan; its block→timestamp table (`internal/edge-data/block-timestamps.json`, 52 real `eth_getBlockByNumber` anchors, Oct 9 → Nov 8) was spot-checked against the chain on 2026-11-08 and is exact, and publicnode `eth_getLogs` over blocks 54,523,000–54,911,993 returns the same 36 swaps GeckoTerminal lists for the last 24 h. The bot still recomputes σ from its own T3 stream; freeze the ±600/±780 switch thresholds only after 2 weeks of its own data. | canary |

---

## Appendix A — Where each signature was verified

| Symbol | Source |
|--------|--------|
| `IStateView.*` | `v4-periphery/src/interfaces/IStateView.sol` @ `c6e4754` |
| `IPositionManager.modifyLiquidities / nextTokenId / positionInfo / getPoolAndPositionInfo / getPositionLiquidity` | `v4-periphery/src/interfaces/IPositionManager.sol` |
| `INotifier.subscribe / unsubscribe / subscriber / unsubscribeGasLimit` | `v4-periphery/src/interfaces/INotifier.sol`; `base/Notifier.sol` (`onlyIfPoolManagerLocked`, `onlyIfApproved`, `AlreadySubscribed`) |
| `Actions.*` opcodes and param decoders | `v4-periphery/src/libraries/Actions.sol`; `PositionManager._handleAction` |
| `ActionConstants.MSG_SENDER = address(1)`, `ADDRESS_THIS = address(2)`, `OPEN_DELTA = 0`, `CONTRACT_BALANCE` | `v4-periphery/src/libraries/ActionConstants.sol` |
| `SlippageCheck.validateMaxIn / validateMinOut` errors | `v4-periphery/src/libraries/SlippageCheck.sol` |
| `PositionInfo` packing | `v4-periphery/src/libraries/PositionInfoLibrary.sol` |
| `IPoolManager.Swap / ModifyLiquidity` events | `v4-core/src/interfaces/IPoolManager.sol` @ `bea7f6d` |
| `TickMath.MIN_TICK/MAX_TICK = ∓887272` | `v4-core/src/libraries/TickMath.sol` |
| `LiquidityAmounts.getLiquidityForAmount0/1/Amounts` | `v4-periphery/src/libraries/LiquidityAmounts.sol` |
| UR `Commands.V4_SWAP = 0x10`, `V4_POSITION_MANAGER_CALL = 0x14`, `OnlyMintAllowed` | `universal-router/contracts/libraries/Commands.sol`, `modules/V3ToV4Migrator.sol` |
| `IV4Router.ExactInputSingleParams` | `v4-periphery/src/interfaces/IV4Router.sol` (main adds `minHopPriceX36`) |
| Registry `handleSubscribe → _index` (`PoolNotAllowed`, `LiquidityBelowThreshold`, `OutOfRange`), `_meetsMinimum` (false at L = 0), `pruneSubscription`, `resubscribe`, `whenPoolManagerLocked` | Sourcify full match, `contracts/telx/core/PositionRegistry.sol` |
| Merkl CL scoring semantics | docs.merkl.xyz "Concentrated Liquidity Campaigns" (variable reward rate; fake-volume / frequent-rebalancing blacklist note), fetched 2026-11-08 |
