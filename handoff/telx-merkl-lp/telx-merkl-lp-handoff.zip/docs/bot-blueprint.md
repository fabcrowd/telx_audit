# TELx Merkl LP Bot — Structural Blueprint

**Status:** design only. No production trading code, keys, or live tx scripts.  
**Venue:** Uniswap v4 on Base · TELx pools (TEL/eUSD or TEL/ETH)  
**Objective:** maximize Merkl reward share (~425k TEL/week/pool) via concentrated staggered brackets + subscription uptime, not trading fees.  
**Capital assumption:** ~$2k in ~$40–50k TVL pools.

Related: [`project-context.md`](./project-context.md) · [`telx-merkl-reward-rules.md`](./telx-merkl-reward-rules.md) (reward-rules research, 2026-11-08) · [`telx-private-repo-findings.md`](./telx-private-repo-findings.md) (verified addresses / subscribe wiring, 2026-11-08) · [`build-plan.md`](./build-plan.md) (structure review + phased plan).

> **Assumptions status (rewards):** Passive-only / ≤1 modify / 43_200-block JIT zeroing is **contested / stale for the live Merkl path** (and 43,200 blocks is now only ≈ 2.4 h: Base block time is ≈ 0.2 s since ~2026-11-06, 2 s before — `measure-rebalance-mechanics.md` D10). Merkl Base campaigns (verified 2026-11-08) score subscribed in-range liquidity via 50/25/25 fees/token0/token1 — see §2 and the research note. Rebalance atomicity stays a **configurable** choice driven by verified campaign params, not a hard default from the Essential Guide.

---

## 1. Stack recommendation

**Recommend: TypeScript + viem (+ `@uniswap/v4-sdk` / v4-periphery action encoding).**

| Factor | TypeScript / viem | Python / web3.py |
|--------|-------------------|------------------|
| Uniswap v4 SDK / action codecs | First-class (`v4-sdk`, PosM `Actions`, `PoolKey` helpers) | Manual ABI encoding; community ports lag |
| Permit2 + Multicall | Mature viem + Uniswap TS examples | Usable but more hand-rolled |
| Typed ABIs / simulate | Excellent | Good |
| Ops / scripts | Strong for bot workers | Strong for data science / notebooks |

Python remains viable for offline analytics (Merkl leaderboards, TIR backtests). The **hot path** (slot0 watch → plan → encode PosM unlock bundle → TELx subscribe → submit/verify) should be TS.

**Verified Base periphery (Uniswap docs — reconfirm before wiring):**

| Contract | Address |
|----------|---------|
| PoolManager | `0x498581fF718922c3f8e6A244956aF099B2652b2b` |
| PositionManager | `0x7C5f5A4bBd8fD63184577525326123B519429bDc` |
| StateView | `0xa3c0c9b65bad0b08107aa264b0f3db444b867a71` |
| Permit2 | `0x000000000022D473030F116dDEE9F6B43aC78BA3` |

| UniversalRouter | `0x6fF5693b99212Da76ad316178A184AB56D299b43` (confirm version at build time) |

**Verified TELx / Merkl targets on Base (from `telx-frontend` + labs contracts, 2026-11-08 — see [`telx-private-repo-findings.md`](./telx-private-repo-findings.md); re-read from chain at startup):**

| Item | Value |
|------|-------|
| Merkl PositionRegistry (live `subscriptionContract`) | `0xcebC0b00473Ca00e429eF431826d0A32cdc945E1` |
| Merkl TELxSubscriber (PosM `ISubscriber` target) | `0x19EDFa380ead0Bb26010Ca3d1C7AbC7213938c86` |
| Merkl Distributor (claims) | `0x3Ef3D8bA38EBe18DB133cEc108f4D14CE00Dd9Ae` |
| ETH/TEL poolId | `0x272e0968e2fb347236c6060cc9395f13591968f3f83056c600c755066dd214a6` |
| eUSD/TEL poolId | `0x1266df876a41a4f4250dbfa9887e70f20a40a3ccd802c8d75b51b7fd4eb36982` |
| PoolKey (both) | fee `3000`, tickSpacing `60`, **hooks `0x0`**; `currency1` = TEL v3 |
| TEL v3 | `0x7E13B43065380aCdeC1c2d138c579cbBbafA0731` (18 dec) — **confirm on-chain against PoolKey before wiring** |
| eUSD | `0x14913815bCFDE78BAeAd2111F463D038Ac9C2949` (6 dec) — `currency0` of eUSD/TEL |
| Native ETH | `address(0)` — `currency0` of ETH/TEL |

There is **no `IncentiveController`**. Subscribe is `PositionManager.subscribe(tokenId, MERKL_TELX_SUBSCRIBER, 0x)`; the subscriber's `notifySubscribe` calls `PositionRegistry.handleSubscribe`. Do **not** wire the predicted CREATE3 registry `0x00637F…Aa61` (labs: not deployed). Legacy hooked pool `0x727b…`, hook `0x23aB…`, registry `0x3994…` are archived — not Merkl targets.

---

## 2. Hard product constraints (design-critical)

1. **Subscribe or earn nothing.** Minting a v4 position NFT alone does not earn TELx Merkl rewards. Every new `tokenId` must be subscribed to the Merkl-era TELx `PositionRegistry` (`subscriptionContract`, Base live: `0xcebC0b00473Ca00e429eF431826d0A32cdc945E1`) in the same operational window as mint (preferably same tx). Mechanism: `PositionManager.subscribe(tokenId, 0x19EDFa380ead0Bb26010Ca3d1C7AbC7213938c86, 0x)` → `TELxSubscriber.notifySubscribe` → `PositionRegistry.handleSubscribe`. Subscribe requires PoolManager **locked** (i.e. a separate call after `modifyLiquidities`, composable in one PosM `multicall`) and an **in-range** position (`OutOfRange` revert otherwise).
2. **Reward scoring follows live Merkl campaign params (verified 2026-11-08) — not the Essential Guide’s Passive-only section.**
   - Live Base campaigns are Merkl `UNISWAP_V4_SUBSCRIPTION`: subscribed + **in-range only**; weights **50% fees / 25% token0 / 25% token1**; `genericTimeWeighted`; empty campaign blacklist.
   - The public Essential Guide still claims Passive-only (≤1 modify / ~24h / **43_200 Base blocks** — "24 h" assumed 2 s blocks; at today's ≈ 0.2 s/block that is ≈ 2.4 h; Active/JIT → 0%). That text matches the **legacy** registry `0x3994e3…BB04` (on-chain `PASSIVE_WEIGHT=10000`, `ACTIVE_WEIGHT=0`, `JIT_WEIGHT=0`, `MIN_PASSIVE_LIFETIME=43200`) which Merkl campaigns do **not** use as `subscriptionContract`.
   - **Assumptions status:** Passive-only / guide JIT period-zero → **contested (stale for Merkl path)**. Merkl subscribe + in-range + 50/25/25 → **verified** for current Base TEL/ETH and TEL/eUSD campaigns. Merkl platform anti-JIT/wash blacklisting → **verified as a platform risk**, distinct from TELx period weights.
3. **Eligibility = allowlisted pool + `liquidity ≥ minLiquidity[poolId]` (absolute, per-pool) + in-range** (`inRangeRequired` default on). The “1 bp of pool liquidity” rule is **stale** (legacy path). `notifyModifyLiquidity` is a **no-op** on the Merkl subscriber: increase/decrease does **not** auto-unsubscribe, but anyone may `pruneSubscription` a position that falls below `minLiquidity`; refill then permissionless `resubscribe(tokenId)` (v4 refuses a second `subscribe`). Read `minLiquidity[poolId]` at startup; **value not yet confirmed** for either pool.
4. **NFT transfer or burn unsubscribes.** Custody model must keep ownership stable; `BURN_POSITION` triggers the subscriber's burn path.
5. Fee claims (Essential Guide FAQ note 2025-11-28) are described as **not** liquidity modifications under the old taxonomy — keep claim path separate; re-verify if registry notify semantics change.

> **Implication for bracket shape:** because subscribe reverts `OutOfRange` and Merkl pays only in-range liquidity, every bracket must **contain spot at mint**. Literal one-sided B/C buffers cannot be subscribed; see [`build-plan.md`](./build-plan.md) §1.1 for the straddle alternatives (decision pending).
>
> **Implication for atomic burn+mint:** under **live Merkl** params, same-block burn→mint→subscribe is **not** shown to inherit the old “JIT → 0% for the period” TELx classifier. It remains a **capital-safety vs gaming-heuristic** tradeoff. Planner must support staggered and atomic modes; production `rebalanceMode` is selected from verified campaign/registry params (see §5, §7, §9 and [`telx-merkl-reward-rules.md`](./telx-merkl-reward-rules.md)).

---

## 3. Repo / module layout

```text
telx-merkl-lp-bot/
├── config/
│   ├── default.toml          # thresholds, splits, cooldowns
│   ├── pools.base.yaml       # verified PoolKeys (hooks=0), poolIds, registry + subscriber addrs
│   └── schema.ts             # zod/io-ts config validation
├── src/
│   ├── chain/
│   │   ├── client.ts         # viem public + wallet clients (RPC + WS)
│   │   ├── multicall.ts      # batched reads / simulateContract
│   │   └── abis/             # PosM, PoolManager, StateView, TELx (stubs)
│   ├── monitor/
│   │   ├── slot0.ts          # poll/watch sqrtPriceX96 + tick
│   │   └── swapActivity.ts   # last swap timestamp / volume spark trigger
│   ├── math/
│   │   ├── ticks.ts          # price↔tick, spacing snap, bracket builders
│   │   └── allocation.ts     # capital splits → liquidity amounts
│   ├── positions/
│   │   ├── manager.ts        # encode burn/mint PosM actions; track tokenIds
│   │   └── inventory.ts      # local + on-chain position state
│   ├── telx/
│   │   ├── subscribe.ts      # encode PosM.subscribe(tokenId, MERKL_TELX_SUBSCRIBER, 0x) per minted id
│   │   └── eligibility.ts    # registry reads: pool allowlisted? liquidity ≥ minLiquidity? in-range? subscribed?
│   ├── spark/
│   │   └── volumeSpark.ts    # tiny self-swap through core ticks when idle
│   ├── orchestrator/
│   │   ├── rebalance.ts      # breach detect → plan → bundle → submit → verify
│   │   └── planner.ts        # burns/mints + capital reuse plan
│   ├── safety/
│   │   ├── killSwitch.ts     # file/env/on-chain pause
│   │   ├── guards.ts         # gas, slippage, cooldown, max rebalances/day
│   │   └── custody.ts        # signer policy (no keys in repo)
│   └── index.ts              # main loop / worker entry
├── state/                    # durable bot state (sqlite/json) — positions, clocks
├── scripts/                  # dry-run planners, ABI dumpers (no live send)
└── docs/                     # this blueprint + runbooks
```

Single process is enough at $2k scale: one watcher + one executor with a mutex around tx submission.

---

## 4. Logic flow

```mermaid
flowchart TD
  A[Start / resume state] --> B{Kill switch?}
  B -->|on| Z[Idle / alert]
  B -->|off| C[Read slot0 via StateView]
  C --> D[Map sqrtPrice → tick → brackets]
  D --> E{Outer buffer breach\nor planned exit?}
  E -->|no| F{No pool swap > 3h?}
  F -->|yes| G[Volume spark: tiny swap via core]
  F -->|no| H[Sleep / next poll]
  G --> H
  E -->|yes| I{Rebalance guards OK?\nmode + campaign params}
  I -->|no| J[Defer rebalance; alert]
  J --> H
  I -->|yes| K[Plan burns + mints + capital]
  K --> L[Simulate PosM + subscribe]
  L --> M{Guards pass?}
  M -->|no| N[Abort; alert]
  N --> H
  M -->|yes| O[Submit atomic / staged bundle]
  O --> P[Verify: new tokenIds owned,\nsubscribed, liquidity ≥ minLiquidity]
  P --> Q[Update state + TIR assumptions]
  Q --> H
```

### Poll / watch

- Prefer **WS** `watchBlocks` + periodic `StateView.getSlot0(poolId)`; fall back to HTTP poll (5–15s) if WS drops. Express all cadences/cooldowns in **seconds**, not blocks: Base block time is ≈ 0.2 s since ~2026-11-06 (was 2 s), so block counts drift by 10× (`measure-rebalance-mechanics.md` D10; its default is a 12 s HTTP poll, no WS).
- Also index pool `Swap` events for `lastSwapAt` (volume-spark gate).

### Breach rule

Rebalance **only** when spot tick approaches outer buffer edges (e.g. within `breach_margin_ticks` of B.lower or C.upper), not on every micro-move of the ±1.5% core. That preserves Merkl time-weighting and avoids unnecessary TIR / concentration resets.

### Post-tx verification

1. New NFT `tokenId`s owned by bot wallet / vault.
2. `PositionManager.subscriber(tokenId) == MERKL_TELX_SUBSCRIBER` and the registry reports the id subscribed.
3. Each position `liquidity ≥ minLiquidity[poolId]` (absolute, from registry) — else top up and `resubscribe` (prune risk).
4. Record `lastLiquidityModifyBlock` → drive next cooldown.
5. Log assumed TIR reset (new ranges start fresh; Merkl indexing lag is off-chain — see §9).

---

## 5. Atomic multicall bundle (architecture)

Uniswap v4 does **not** expose free-standing “mint NFT” outside the unlock/callback model for PoolManager liquidity. Integrators use **PositionManager** as the action router:

1. Caller invokes `PositionManager.modifyLiquidities(unlockData, deadline)`.
2. PosM calls `PoolManager.unlock(...)`.
3. PoolManager re-enters PosM `unlockCallback`.
4. PosM executes packed `Actions` (burn/decrease, mint/increase, settle, take, sweep, …).
5. All currency deltas must net to zero before relock (flash accounting / EIP-1153 style deltas). Nonzero deltas → revert.

```mermaid
sequenceDiagram
  participant Bot
  participant PosM as PositionManager
  participant PM as PoolManager
  participant Sub as TELxSubscriber (0x19ED…)
  participant Reg as PositionRegistry (0xcebC…)

  Bot->>PosM: multicall([ modifyLiquidities(unlockData, deadline), subscribe(id1, Sub, 0x), subscribe(id2, Sub, 0x), subscribe(id3, Sub, 0x) ])
  PosM->>PM: unlock(actions)
  PM->>PosM: unlockCallback
  Note over PosM,PM: BURN OOR ids → MINT A/B/C → SETTLE_PAIR / TAKE_PAIR / SWEEP
  PM-->>PosM: deltas settled, lock
  Note over PosM: ids predicted from nextTokenId() pre-send; any mismatch reverts the whole multicall
  PosM->>Sub: notifySubscribe(tokenId, 0x)  (×3, PoolManager locked)
  Sub->>Reg: handleSubscribe(tokenId, …)
  Note over Reg: checks pool allowlist, liquidity ≥ minLiquidity, in-range
```

### Structural pseudo (not runnable)

```ts
// Conceptual — action opcodes from v4-periphery `Actions`; confirm BURN semantics on deployed Base PosM
const actions = encodePacked(
  ['uint8','uint8','uint8', /* ... */, 'uint8','uint8'],
  [
    Actions.DECREASE_LIQUIDITY, // or BURN for full exit
    Actions.DECREASE_LIQUIDITY,
    Actions.DECREASE_LIQUIDITY,
    Actions.MINT_POSITION,      // core ±1.5%
    Actions.MINT_POSITION,      // lower buffer
    Actions.MINT_POSITION,      // upper buffer
    Actions.SETTLE_PAIR,
    Actions.TAKE_PAIR,          // dust / residual
  ],
);

const params = [ /* per-action abi.encode(...) */ ];

const unlockData = encodeAbiParameters(
  [{ type: 'bytes' }, { type: 'bytes[]' }],
  [actions, params],
);

// Atomicity (verified pattern, mirrors telx-frontend `encodeMintAndSubscribe`):
// one PosM.multicall = [ modifyLiquidities(...), subscribe(id, SUBSCRIBER, 0x) × newMints ].
// PosM.subscribe needs PoolManager locked, so it must be a sibling call, not an Action.
// tokenIds are predicted: nextId = await posm.read.nextTokenId(); ids = nextId, nextId+1, nextId+2.
// If another mint lands first, subscribe(id) fails isApprovedOrOwner → whole multicall reverts → re-plan.
const MERKL_TELX_SUBSCRIBER = '0x19EDFa380ead0Bb26010Ca3d1C7AbC7213938c86';

const calls = [
  encodeFunctionData({ abi: posmAbi, functionName: 'modifyLiquidities', args: [unlockData, deadline] }),
  ...predictedIds.map((id) =>
    encodeFunctionData({ abi: posmAbi, functionName: 'subscribe', args: [id, MERKL_TELX_SUBSCRIBER, '0x'] }),
  ),
];

await wallet.writeContract({
  address: POSITION_MANAGER,
  abi: posmAbi,
  functionName: 'multicall',
  args: [calls],
  value: nativeEthNeeded, // ETH/TEL pool: currency0 = address(0)
});
// Alternative (staged modes): send modifyLiquidities, read Transfer events for real ids, then subscribe — two txs.
```

**Notes (architecture, not attack guidance):**

- Liquidity ops against PoolManager require an unlock context; bots should go through PosM (or an audited executor), not ad-hoc PoolManager calls.
- Merkl pools are **vanilla v4 (`hooks = 0x0`)** — `hookData` is empty; but the PoolKey must match exactly (fee 3000 / spacing 60 / TEL v3) or the poolId differs and the position is outside the campaign.
- Permit2 approvals for token0/token1 → PosM are a one-time setup; never commit private keys or permit signatures into the repo.
- Volume spark is a **separate** swap path (Universal Router / PosM swap actions), not inside the rebalance unlock unless deliberately batched after cooldown analysis.

**Reward-policy fork (configurable — driven by verified campaign params, not Essential Guide defaults):**

| Mode | Capital continuity | Merkl / TELx risk (as of 2026-11-08 research) |
|------|--------------------|-----------------------------------------------|
| `atomic_rebalance` | Best (one tx burn+mint+subscribe) | No TELx Passive/JIT period-zero on live Merkl path; residual Merkl anti-gaming blacklist + TIR reset on new NFTs |
| `mint_then_burn_staged` | Temporary double capital or partial | Safer vs predatory-JIT heuristics; more gas / inventory complexity |
| `burn_then_mint_gap` | Idle inventory gap | Most conservative; worst TIR / inventory gap |

**Planner supports all three**; production `rebalanceMode` is a config flag set after reading live Merkl opportunity params + registry. Do not hard-default to a 43_200-block Passive cooldown unless a future campaign/registry reintroduces that classifier. Optional `passiveCooldownBlocks` remains available as a soft ops throttle (if used, derive it from a seconds value at runtime — block time is ≈ 0.2 s, not 2 s; D10 in `measure-rebalance-mechanics.md`).

---

## 6. Data model

```ts
type BracketRole = 'core' | 'lower' | 'upper';

interface PositionRecord {
  tokenId: bigint;
  role: BracketRole;
  tickLower: number;
  tickUpper: number;
  liquidity: bigint;
  subscribed: boolean;
  lastModifyBlock: number;
  createdAtBlock: number;
}

interface BotState {
  chainId: 8453;
  poolId: `0x${string}`;           // v4 PoolId
  positions: PositionRecord[];     // normally 3
  capitalUsdNominal: number;       // ~2000
  allocation: { core: number; lower: number; upper: number }; // e.g. 0.5 / 0.25 / 0.25
  lastSwapAt: number;              // unix sec — pool-wide
  lastSparkAt?: number;
  lastRebalanceAt?: number;
  lastLiquidityModifyBlock: number;
  gas: {
    maxFeePerGasGwei: number;
    maxPriorityFeeGwei: number;
    maxTxCostEth: number;
    dailyGasBudgetEth: number;
    spentTodayEth: number;
  };
  killSwitch: boolean;
  mode: 'atomic_rebalance' | 'mint_then_burn_staged' | 'burn_then_mint_gap';
}
```

Persist to sqlite (preferred) or JSON with fsync; treat chain as source of truth on restart (enumerate owner NFTs via PosM + reconcile).

---

## 7. Config surface

```yaml
# config/pools.base.yaml — values verified 2026-11-08 (telx-frontend pool.json / contracts.ts);
# startup MUST recompute poolId = keccak256(abi.encode(PoolKey)) and assert equality.
chainId: 8453
rpcHttp: ${BASE_RPC_HTTP}
rpcWs: ${BASE_RPC_WS}

uniswap:
  poolManager: "0x498581fF718922c3f8e6A244956aF099B2652b2b"
  positionManager: "0x7C5f5A4bBd8fD63184577525326123B519429bDc"
  stateView: "0xa3c0c9b65bad0b08107aa264b0f3db444b867a71"
  permit2: "0x000000000022D473030F116dDEE9F6B43aC78BA3"
  universalRouter: "0x6ff5693b99212da76ad316178a184ab56d299b43"  # confirm version

tokens:
  telV3: "0x7E13B43065380aCdeC1c2d138c579cbBbafA0731"   # 18 dec — CONFIRM on-chain vs PoolKey.currency1
  eusd:  "0x14913815bCFDE78BAeAd2111F463D038Ac9C2949"   # 6 dec
  weth:  "0x4200000000000000000000000000000000000006"   # spark wrap only; pools use native ETH

pools:
  - name: "ETH/TEL"
    poolId: "0x272e0968e2fb347236c6060cc9395f13591968f3f83056c600c755066dd214a6"
    currency0: "0x0000000000000000000000000000000000000000"  # native ETH
    currency1: "0x7E13B43065380aCdeC1c2d138c579cbBbafA0731"  # TEL v3
    fee: 3000
    tickSpacing: 60
    hooks: "0x0000000000000000000000000000000000000000"
    merklOpportunityId: "10837281193255818234"
  - name: "eUSD/TEL"
    poolId: "0x1266df876a41a4f4250dbfa9887e70f20a40a3ccd802c8d75b51b7fd4eb36982"
    currency0: "0x14913815bCFDE78BAeAd2111F463D038Ac9C2949"  # eUSD
    currency1: "0x7E13B43065380aCdeC1c2d138c579cbBbafA0731"  # TEL v3
    fee: 3000
    tickSpacing: 60
    hooks: "0x0000000000000000000000000000000000000000"
    merklOpportunityId: "16270260351359923751"

activePool: "eUSD/TEL"                     # or ETH/TEL

telx:
  # Merkl-era Base PositionRegistry (live Merkl subscriptionContract, 2026-11-08)
  positionRegistry: "0xcebC0b00473Ca00e429eF431826d0A32cdc945E1"
  # ISubscriber passed to PositionManager.subscribe(tokenId, subscriber, 0x)
  subscriber: "0x19EDFa380ead0Bb26010Ca3d1C7AbC7213938c86"
  merklDistributor: "0x3Ef3D8bA38EBe18DB133cEc108f4D14CE00Dd9Ae"
  # Legacy native-rewards registry (Essential Guide / Passive weights) — NOT Merkl subscriptionContract; reference only
  legacyPositionRegistry: "0x3994e3ae3Cf62bD2a3a83dcE73636E954852BB04"
  # Read at startup; UNKNOWN until queried: minLiquidity[poolId], pool allowlist flag, inRangeRequired
  minLiquidityOverride: null
  # Merkl campaign params — re-fetch at startup (api.merkl.xyz/v4/campaigns?chainId=8453&tokenSymbol=TEL); assert
  # type == UNISWAP_V4_SUBSCRIPTION, subscriptionContract == positionRegistry, isOutOfRangeIncentivized == false
  expectedWeights: { fees: 5000, token0: 2500, token1: 2500 }

strategy:
  coreWidthPct: 0.015
  bufferWidthPct: 0.04
  allocation: { core: 0.50, lower: 0.25, upper: 0.25 }
  breachMarginTicks: 10
  pollIntervalMs: 8000
  volumeSpark:
    idleHours: 3
    notionalUsd: 5
    maxSparksPerDay: 8
  # Optional soft throttle only — NOT a verified Merkl eligibility rule as of 2026-11-08
  passiveCooldownBlocks: null
  minLiquidityHeadroom: 1.5                # mint ≥ 1.5 × registry minLiquidity[poolId] (prune safety)
  # Configurable: atomic_rebalance | mint_then_burn_staged | burn_then_mint_gap
  rebalanceMode: "atomic_rebalance"        # default after Merkl verification; override per ops risk

safety:
  maxSlippageBps: 30
  maxRebalancesPerWeek: 3
  maxTxCostEth: 0.002
  dailyGasBudgetEth: 0.01
  killSwitchPath: "./state/KILL"
```

Secrets (`PRIVATE_KEY`, RPC auth) via env / secret manager only — never files in git.

---

## 8. Operational risks & design mitigations

| Risk | Why it hurts | Mitigation (design) |
|------|--------------|---------------------|
| IL vs Merkl yield | Narrow brackets amplify IL; fees are secondary | Size for Merkl share; widen only if IL dominates weekly TEL; track mark-to-market vs claimed TEL |
| Ghost-pool zero volume | Merkl utilization / active-tick scoring weak | Volume spark through **own** core; cap daily sparks; never chase toxic flow |
| Failed / skipped subscribe | Capital deployed, **zero** Merkl | Same-tx or immediate follow-up subscribe; verify+alert; auto-retry; refuse further mints if any live position unsubscribed |
| Pruned below `minLiquidity` | Partial withdraw / dust bracket → permissionless `pruneSubscription` → zero Merkl | Mint ≥ headroom × `minLiquidity[poolId]`; verify after every modify; `resubscribe` runbook |
| Rebalance thrash | Resets Merkl time-weight / concentration; gas drag | Outer-buffer-only triggers; `maxRebalancesPerWeek`; optional soft cooldown |
| Atomic burn+mint flagged as predatory JIT | Merkl platform blacklist (distinct from old TELx period-zero) | Keep `rebalanceMode` configurable; prefer genuine re-centering, not swap-sandwich liquidity |
| Merkl indexing lag | UI/leaderboard lags on-chain truth | Trust on-chain subscribe + in-range; don’t rebalance based on Merkl UI alone |
| Base RPC flakiness | Missed breach or double-submit | Dual RPC; idempotent nonce manager; simulate before send; WS resubscribe |
| Key custody | $2k + approvals | Hardware / turnkey / policy signer; spend limits; kill switch; separate spark wallet optional |
| Wrong pool key | Different fee/spacing/token (e.g. TEL v2, legacy hooked pool) → different poolId → no campaign | Startup asserts `keccak256(PoolKey) == configured poolId` and poolId ∈ Merkl campaign params |
| Subscribe reverts (`OutOfRange`, mismatched predicted tokenId, pool not allowlisted) | Whole multicall reverts → no capital moved, but rebalance stalls | Simulate; re-read `nextTokenId`; retry with fresh plan; alert after N failures |
| Subscribe silently missing (staged mode) | Capital deployed, zero Merkl | Post-tx `PositionManager.subscriber(tokenId)` check; refuse new mints while any live id unsubscribed |

---

## 9. Unknowns / discovery checklist

Mark each item verified before any mainnet capital path.

### TELx / Merkl

- [x] Merkl-era **PositionRegistry** on Base for live campaigns: `0xcebC0b00473Ca00e429eF431826d0A32cdc945E1` (2026-11-08).
- [x] Live Merkl weights Base TEL/ETH + TEL/eUSD: **50/25/25**, in-range only, `UNISWAP_V4_SUBSCRIPTION` (2026-11-08).
- [x] Passive-only / 43_200 classifier: present on **legacy** registry only; **not** Merkl `subscriptionContract` (2026-11-08) — see [`telx-merkl-reward-rules.md`](./telx-merkl-reward-rules.md).
- [x] ABI / wiring: `PositionManager.subscribe(tokenId, 0x19ED…8c86, 0x)` → `TELxSubscriber.notifySubscribe` → `PositionRegistry.handleSubscribe` (SUBSCRIBER_ROLE); `notifyModifyLiquidity` no-op (2026-11-08, telx-frontend + labs source).
- [ ] Per-pool on-chain `minLiquidity[poolId]` numeric value (absolute; “1 bp” rule is stale) — read via eth_call before any mint sizing.
- [ ] Owner-side allowlist on the registry (EOA vs contract wallets; `MAX_SUBSCRIPTIONS = 1_000` per owner) — confirm an EOA hot wallet can subscribe without approval.
- [ ] Whether Merkl ever flags **honest** same-block full rebalances (vs predatory JIT) — dust-test before size-up.
- [ ] Indexing lag from subscribe → first reward root inclusion.
- [ ] Whether volume-spark self-swaps trip Merkl wash-trading blacklist.

### Uniswap v4 pool identity

- [x] Canonical `PoolKey` for both Merkl pools: fee 3000 / spacing 60 / hooks 0 / currency1 = TEL v3 (2026-11-08, `pool.json`).
- [x] `PoolId`s: ETH/TEL `0x272e…14a6`, eUSD/TEL `0x1266…6982`; no hook (2026-11-08).
- [ ] TEL v3 address `0x7E13…0731` + 18 decimals: **confirm on-chain** (`PoolManager`/StateView `slot0` for the configured poolId must be initialized; token `decimals()`).
- [ ] Price orientation: eUSD (6 dec) / TEL (18 dec) and ETH (18) / TEL (18) tick math fixtures.
- [ ] PosM action set for full exit on deployed Base periphery (`BURN_POSITION` with `amount0Min/amount1Min` vs `DECREASE_LIQUIDITY` + `BURN_POSITION`) — confirm against the deployed PosM version on a fork.
- [x] `hookData`: empty (hooks = 0).

### Ops

- [ ] Gas envelope for 3-burn + 3-mint + 3×subscribe multicall on Base under congestion (measure on fork).
- [ ] Custody pattern (EOA vs Safe + module) — `subscribe` is `isApprovedOrOwner`-gated, so a Safe owner works; confirm the registry does not reject contract owners.
- [ ] Merkl indexing lag from subscribe → first reward root inclusion.
- [ ] Alerting channel (Pager/Slack) for unsubscribed inventory.

### Sources skimmed (re-verify at build time)

- Uniswap v4 PositionManager / unlock+deltas guides; Base deployments page.
- TELx: Merkl-managed rewards; LP quick start; Liquidity Mining Essential Guide (**Passive section contested / stale vs Merkl** — still published 2026-11-08).
- Merkl API + app: Base ETH-TEL / eUSD-TEL `(Subscribed)` campaigns; research note [`telx-merkl-reward-rules.md`](./telx-merkl-reward-rules.md).
- TELxIP Merkl rollout + POC summary (Campaign F 50/25/25).

---

## 10. Implementation phases (no capital until gates pass)

> Superseded by the detailed phased plan in [`build-plan.md`](./build-plan.md); kept as the gate summary.

1. **Read-only monitor** — slot0, swaps, mock breach alerts.
2. **Planner dry-run** — emit intended burns/mints/ticks without sending.
3. **Testnet / dust fork** — mint one position, subscribe, verify registry; measure cooldown semantics.
4. **Mode decision** — lock `rebalanceMode` from live Merkl/registry verification (not Essential Guide alone).
5. **Guarded mainnet dust** — below economic size; full verify path; watch Merkl inclusion / blacklist.
6. **Scale to ~$2k** — only with kill switch, subscribe verifier, and campaign-param guards in code.

---

## 11. Non-goals (this blueprint)

- Live deployment scripts with funded keys.
- MEV / sandwich / competitor-attack tooling.
- Cross-protocol incentive farming beyond TELx Merkl on these pools.
- Full runnable bot binary.
