# TELx Merkl LP Bot — Build Plan

**Status:** design / planning. No production bot code in this doc.  
**Date:** 2026-11-08  
**Inputs:** [`bot-blueprint.md`](./bot-blueprint.md) (patched today with verified facts) · [`telx-merkl-reward-rules.md`](./telx-merkl-reward-rules.md) · [`telx-private-repo-findings.md`](./telx-private-repo-findings.md) · [`design-references.md`](./design-references.md) · [`project-context.md`](./project-context.md)

---

## 0. TL;DR

- Stack is final: **TypeScript + viem + `@uniswap/v4-sdk` / v4-periphery `Actions`**, Node LTS, pnpm, vitest, Foundry `anvil` Base fork.
- Subscribe is **`PositionManager.subscribe(tokenId, 0x19EDFa380ead0Bb26010Ca3d1C7AbC7213938c86, 0x)`**, composed as sibling calls in one PosM `multicall` after `modifyLiquidities`. No `IncentiveController` exists; `telx/` shrinks to registry reads + Merkl API asserts.
- **Design defect to resolve before Phase 1:** the registry enforces `inRangeRequired` at subscribe (`OutOfRange` revert) and Merkl pays only in-range liquidity. One-sided B/C buffers are out of range at mint and **cannot be subscribed**. Brackets must each straddle spot (recommended: asymmetric straddles) or the bot needs a subscribe-on-entry job. See §1.1.
- First build step: Phase 0 scaffold + a read-only script that proves `keccak256(PoolKey) == poolId`, reads `slot0` for both pools, reads `minLiquidity[poolId]`, and asserts live Merkl campaign params.
- Canary pool: **eUSD/TEL** (same daily reward as ETH/TEL at ~45% of the TVL → ~2× reward density; stable-side IL profile).

---

## 1. Structure review

### 1.1 Strategy-level issue the layout must absorb (blocker for Phase 1)

| Fact (verified) | Consequence |
|-----------------|-------------|
| Registry `inRangeRequired = 1`; `handleSubscribe` reverts `OutOfRange` | A position whose range does not contain the current tick **cannot be subscribed at mint** |
| Merkl `isOutOfRangeIncentivized: false` | Out-of-range liquidity earns nothing even if subscribed |
| In-range test is `tickLower ≤ tick < tickUpper` | Two adjacent one-sided buffers `[−4%, spot)` and `[spot, +4%)` can never both be in range in the same block |

Blueprint §A ("B ±4% below spot, C ±4% above spot") as literal one-sided buffers would mint two unsubscribable, unrewarded positions holding single-token inventory. Options, in recommended order:

| Option | Shape | Pros | Cons |
|--------|-------|------|------|
| **A. Asymmetric straddles (recommended)** | A `[−1.5%, +1.5%]`, B `[−4%, +1.5%]`, C `[−1.5%, +4%]` | All three in range and subscribable at mint; when spot drifts up past +1.5%, C alone stays in range (and vice versa) → staggered uptime preserved; rebalance trigger stays "spot within `breachMarginTicks` of −4% / +4%" | B/C each hold both tokens (more capital in the ±1.5% band than the blueprint's picture implies) |
| B. Nested symmetric | A `±1.5%` ($1000), B `±4%` ($1000) | Simplest; two NFTs, fewer gas/ids | Loses asymmetric drift coverage; same as A with B∪C merged |
| C. One-sided buffers + subscribe-on-entry | As blueprint; orchestrator watches for a buffer entering range and sends `subscribe` | Matches original picture | Unsubscribed/unrewarded until bot reacts; extra tx; single-token inventory sits idle; **not** recommended |

**Decision needed from user** (default to A if silent). Planner API takes `brackets: {role, lowerPct, upperPct, weight}[]` so A/B/C are config, not code.

### 1.2 Module layout verdicts

Blueprint tree: `config/ chain/ monitor/ math/ positions/ telx/ spark/ orchestrator/ safety/`.

| Module | Verdict | Change |
|--------|---------|--------|
| `config/` | **Keep, move schema** | `config/schema.ts` → `src/config/schema.ts` (compiled, importable by tests). `pools.base.yaml` carries the full verified `PoolKey`s; startup recomputes `poolId` and asserts. Drop `hook`, `hooksBitmap`, `minPoolLiquidityBps`, `legacyPositionRegistry` (reference comment only). Add `tokens`, `telx.subscriber`, `telx.merklDistributor`, `expectedWeights`. |
| `chain/` | **Keep + absorb** | Add `txQueue.ts` (single nonce/mutex queue, simulate-before-send, receipt wait) and `signer.ts` (moved from `safety/custody.ts` — it is signer policy, not a guard). `abis/` holds PosM, StateView, PoolManager (Swap event), PositionRegistry, TELxSubscriber, UniversalRouter, ERC20, Permit2. |
| `monitor/` | **Keep** | `slot0.ts` via StateView `getSlot0(poolId)`. `swapActivity.ts` = PoolManager `Swap(id indexed, …)` log filter by poolId → `lastSwapAt`. Only consumer in Phases 0–3 is logging/metrics; spark gate wires in Phase 4. |
| `math/` | **Keep, split** | `ticks.ts` (price↔tick, spacing-60 snap, pct→tick), `brackets.ts` (straddle planner from §1.1), `liquidity.ts` (LiquidityAmounts: amounts↔L, token-decimal aware: eUSD 6 / TEL 18 / ETH 18). Pure functions, zero chain imports, 100% unit-tested. |
| `positions/` | **Rename + split** | `manager.ts` (name collides with PositionManager) → `encode.ts` (pure: `Actions` bytes + params for MINT/BURN/DECREASE/SETTLE_PAIR/TAKE_PAIR/SWEEP, plus `subscribe` calldata, plus `multicall` assembly) and `inventory.ts` (chain reconciliation: owner NFTs via `Transfer` logs + `positionInfo`/`getPoolAndPositionInfo`, `subscriber(tokenId)`). **Subscribe encoding lives here**, not in `telx/`, because it is a PosM call. |
| `telx/` | **Shrink + repurpose** | Delete `subscribe.ts` (moved). Keep `eligibility.ts` (reads: pool allowlisted, `minLiquidity[poolId]`, `inRangeRequired`, is-subscribed). Add `merklApi.ts`: fetch `api.merkl.xyz/v4/campaigns?chainId=8453&tokenSymbol=TEL`, zod-parse, assert `type == UNISWAP_V4_SUBSCRIPTION`, `subscriptionContract == 0xcebC…`, `isOutOfRangeIncentivized == false`, poolId present, weights == expected; refuse to start on mismatch (no silent drift when TELx changes campaigns). |
| `spark/` | **Keep, isolate, defer** | Behind `SparkStrategy` interface with a `NoopSpark` default. Not built until Phase 4; may be dropped if Phase 5 data shows the fee axis is immaterial at $5 notional. |
| `orchestrator/` | **Keep, simplify** | `planner.ts` emits a pure `RebalancePlan {burns[], mints[], predictedTokenIds[], expectedDeltas}`; `rebalance.ts` = detect → plan → simulate → submit → verify → persist. Implement **`atomic` mode first**; `burn_then_mint_gap` is the fallback when simulation of the atomic multicall fails. **Drop `mint_then_burn_staged`** from scope: it needs double capital we do not have at $2k. Add `subscribeOnEntry` job only if option C in §1.1 is chosen. |
| `safety/` | **Keep, trim** | `killSwitch.ts`, `guards.ts` (gas cap, daily gas budget, slippage, `maxRebalancesPerWeek`, "refuse mint while any live id unsubscribed", optional soft `passiveCooldownBlocks`). No hard Passive clock — verified not a Merkl rule. `custody.ts` moves to `chain/signer.ts`. |
| `state/` | **Simplify** | JSON state + append-only JSONL event log with fsync; chain is source of truth on restart (reconcile from `inventory.ts`). Skip sqlite until there is a reporting need. |
| `scripts/` | **Keep** | `verify-pools.ts` (Phase 0 gate), `dry-run-plan.ts` (Phase 1), `fork-smoke.ts` (Phase 2). |

Resulting tree (delta only):

```text
src/
├── config/{schema.ts,load.ts}
├── chain/{client.ts,txQueue.ts,signer.ts,abis/}
├── monitor/{slot0.ts,swapActivity.ts}
├── math/{ticks.ts,brackets.ts,liquidity.ts}
├── positions/{encode.ts,inventory.ts}
├── telx/{eligibility.ts,merklApi.ts}
├── spark/{index.ts (interface + Noop),universalRouter.ts (Phase 4)}
├── orchestrator/{planner.ts,rebalance.ts,loop.ts}
├── safety/{killSwitch.ts,guards.ts}
└── index.ts
```

### 1.3 What stays as-is (correct in the blueprint)

- Off-chain decide → PosM execute; no custom hooks, no custom unlock router.
- Outer-buffer-only breach trigger; `maxRebalancesPerWeek`.
- Post-tx verification before state commit; chain-as-truth on restart.
- Single process, one wallet, one nonce queue; one process **per pool**.
- Kill switch file/env checked every loop; secrets via env only.
- Mermaid flow in blueprint §4 (still accurate after patch).

---

## 2. Stack decision (final)

| Layer | Choice | Why |
|-------|--------|-----|
| Language / runtime | TypeScript 5, **Node 22 LTS**, ESM | Uniswap periphery tooling is TS-first; `bigint` native |
| Chain client | **viem** (public + wallet clients, `simulateContract`, `multicall`, WS `watchBlocks`) | Typed ABIs, built-in batching, deterministic encoding helpers (`encodePacked`, `encodeAbiParameters`) |
| Uniswap | **`@uniswap/v4-sdk`** (TickMath, SqrtPriceMath, `Pool`/`Position`, `V4PositionManager` call builders) + v4-periphery `Actions` constants | Official encoders; our `positions/encode.ts` only adds `subscribe` siblings and the `multicall` wrapper. Pin versions; golden-vector test against SDK output |
| Package manager | **pnpm** | Lockfile determinism, workspace-ready if analytics package is added later |
| Tests | **vitest** (unit, contract) + **Foundry `anvil --fork-url <Base>`** (integration) | Real Base bytecode for PosM, registry, subscriber; `anvil_impersonateAccount` / storage `deal` for TEL/eUSD funding |
| Config | YAML + **zod** schema | Fail-fast on placeholder/garbage addresses |
| Logging | pino JSON + Basescan links | Grep-able, ships to any sink |
| Lint | eslint + prettier, `tsc --noEmit` in CI | — |

Python stays allowed for offline analytics (Merkl leaderboard pulls) in a sibling folder; not in the hot path.

---

## 3. Phased build

```mermaid
flowchart LR
  P0[Phase 0\nScaffold + read-only] --> P1[Phase 1\nMath + planner dry-run]
  P1 --> P2[Phase 2\nPosM encode + fork tests]
  P2 --> P3[Phase 3\nOrchestrator + safety]
  P3 --> P5[Phase 5\nSoak + $100 canary + $2k]
  P3 -.optional.-> P4[Phase 4\nVolume spark]
  P4 -.-> P5
  D{{Decision: bracket shape §1.1}} --> P1
```

### Phase 0 — Scaffold, config, read-only chain + Merkl

Build:
- [ ] pnpm repo, tsconfig (ESM, strict), eslint/prettier, vitest, CI (`tsc`, `vitest`, `pnpm audit`).
- [ ] `config/schema.ts` (zod) + `pools.base.yaml` with both verified PoolKeys; loader rejects zero/placeholder addresses.
- [ ] `chain/client.ts`: HTTP + WS public clients, two RPC URLs with failover; wallet client behind `signer.ts` (env key; no key needed for Phase 0).
- [ ] `monitor/slot0.ts`: StateView `getSlot0`, `getLiquidity` for both pools.
- [ ] `telx/eligibility.ts`: read `minLiquidity[poolId]`, `inRangeRequired`, pool allowlist flag on `0xcebC…`; `telx/merklApi.ts` fetch + assert.
- [ ] `scripts/verify-pools.ts`: computes `poolId = keccak256(abi.encode(PoolKey))`, asserts equality with config, prints slot0, tick, liquidity, `minLiquidity`, token `decimals()`, campaign params.

Acceptance:
- [ ] `verify-pools.ts` passes against Base mainnet RPC for **both** pools (poolId match, slot0 initialized, TEL v3 `decimals()==18`, eUSD `==6`).
- [ ] Startup refuses to run when Merkl campaign assert fails (test by flipping expected weight).
- [ ] Unknowns resolved: `minLiquidity` values, allowlist flag, TEL v3 address confirmed from `currency1` of initialized pool.

### Phase 1 — Range math, bracket planner, breach detector, dry-run

Build:
- [ ] `math/ticks.ts`: `pctToTickDelta`, `snapToSpacing(60)`, price↔tick with decimals orientation for eUSD/TEL and ETH/TEL.
- [ ] `math/brackets.ts`: `planBrackets(tick, config)` → three `{tickLower, tickUpper, weight}`; option A straddles by default; invariant: every bracket contains `tick`.
- [ ] `math/liquidity.ts`: capital USD → token amounts → `L`; check `L ≥ headroom × minLiquidity`.
- [ ] `orchestrator/planner.ts`: breach detector (`tick` within `breachMarginTicks` of outer edges), `RebalancePlan` with predicted tokenIds (`nextTokenId + i`).
- [ ] `scripts/dry-run-plan.ts`: prints the plan for live slot0; no sends.

Acceptance:
- [ ] Unit tests: tick snap, pct↔tick round-trip, decimals orientation (golden values hand-checked), bracket invariants (in-range at mint, spacing-aligned, non-degenerate), liquidity sizing vs `minLiquidity`, breach detector edge cases (exactly at margin, inside, hysteresis).
- [ ] Property test: for random ticks, planned brackets all contain spot.
- [ ] Dry-run on live Base prints a plan for both pools with no RPC writes.

### Phase 2 — PosM encoding + atomic subscribe on Base fork

Build:
- [ ] `positions/encode.ts`: `MINT_POSITION`, `BURN_POSITION` (or `DECREASE_LIQUIDITY`+`BURN_POSITION` per deployed PosM), `SETTLE_PAIR`, `TAKE_PAIR`, `SWEEP` (native ETH); `modifyLiquidities(unlockData, deadline)`; `subscribe(tokenId, SUBSCRIBER, 0x)`; `multicall(bytes[])`; `value` for native ETH leg.
- [ ] `positions/inventory.ts`: enumerate owner tokenIds, `positionInfo`, `subscriber(tokenId)`, registry subscribed check.
- [ ] Permit2 approval helpers (one-time setup script; TEL v3 + eUSD → Permit2 → PosM).
- [ ] Fork harness: `anvil --fork-url $BASE_RPC --fork-block-number N`; fund test EOA with ETH, TEL v3, eUSD via storage writes.

Acceptance (all on fork, vitest + viem against anvil):
- [ ] **Mint + subscribe atomically**: one `multicall` mints 3 brackets and subscribes all 3; `subscriber(id) == 0x19ED…` and registry reports subscribed; liquidity ≥ `minLiquidity`.
- [ ] **Burn + mint + subscribe atomically**: move fork price (impersonated swap) past outer edge; one `multicall` burns 3 old ids, mints 3 new, subscribes 3; old ids gone, no stray currency deltas, wallet balance delta == expected ± slippage.
- [ ] **Negative tests**: out-of-range bracket → whole multicall reverts `OutOfRange`, no state change; stale `nextTokenId` (mint one position in between) → whole multicall reverts; second `subscribe` on same id reverts.
- [ ] `encode.ts` golden-vector test matches `@uniswap/v4-sdk` `V4PositionManager` output for the mint leg.
- [ ] Gas of the 3-burn/3-mint/3-subscribe multicall measured and recorded (feeds `maxTxCostEth`).

### Phase 3 — Orchestrator, safety, observability

Build:
- [ ] `orchestrator/loop.ts`: timer (12 s default; Base blocks are ≈ 0.2 s since ~2026-11-06, so per-block loops are not used — `measure-rebalance-mechanics.md` D10/§1.2) → slot0 → breach? → plan → `simulateContract(multicall)` → guards → `txQueue.send` → receipt → verify → persist; optional WS logs.
- [ ] `safety/guards.ts`: `maxTxCostEth`, `dailyGasBudgetEth`, `maxSlippageBps`, `maxRebalancesPerWeek`, refuse-mint-while-unsubscribed, optional soft cooldown.
- [ ] `safety/killSwitch.ts`: file + env; checked every loop; blocks sends, not reads.
- [ ] `chain/txQueue.ts`: mutex, nonce from `pending`, replace-by-fee on stuck tx after N seconds (≈ 20 s; block counts are unreliable at 0.2 s/block — D10), idempotency key per plan hash.
- [ ] State file + JSONL event log; restart reconciliation from chain.
- [ ] pino logs with Basescan links; alerts (Slack/Telegram webhook) on: unsubscribed live id, failed simulate ×N, guard trip, RPC failover, kill switch engaged; heartbeat/deadman every loop.

Acceptance:
- [ ] Fork soak: scripted price path crossing outer edges twice → exactly two rebalances, both verified; third crossing within week blocked by `maxRebalancesPerWeek` and alerted.
- [ ] Kill switch mid-plan → no send; removal → resumes.
- [ ] Kill the process after send, before persist → restart reconciles positions from chain and does not double-rebalance.
- [ ] Primary RPC blackholed → failover within one poll interval; no duplicate tx (nonce idempotency test).
- [ ] Simulation failure never results in a send.

### Phase 4 — Volume spark (optional, gated)

Build:
- [ ] `spark/universalRouter.ts`: UR `V4_SWAP` with `SWAP_EXACT_IN_SINGLE` + `SETTLE_ALL` + `TAKE_ALL`, exact-in ≈ `notionalUsd`, non-zero `amountOutMinimum` from quoted slot0, direction alternates.
- [ ] Gate: `lastSwapAt > idleHours`, `maxSparksPerDay`, gas cap, simulate, not within N seconds of a rebalance (seconds, not blocks — D10).

Acceptance:
- [ ] Fork test: spark executes through the core range (tick stays inside A), fee accrues to own positions, `amountOutMinimum` enforced.
- [ ] Gate unit tests: idle timer, daily cap, proximity-to-rebalance lockout.
- [ ] **Go/no-go input:** Phase 5 canary data showing whether the fee axis moves our Merkl share at $5 notional; otherwise leave `NoopSpark`.

### Phase 5 — Soak, canary, scale

- [ ] 48h fork soak with recorded Base price path (replay) → zero unexpected sends.
- [ ] Mainnet **$100 canary** on eUSD/TEL: mint+subscribe; confirm appearance in Merkl API `positions`/rewards after indexing lag; one forced rebalance (tight brackets) to exercise burn+mint+subscribe live; claim once via Distributor.
- [ ] Review canary gas, rebalance count, Merkl share vs TVL share; confirm no blacklist.
- [ ] Scale to $2k only after: canary rewarded, zero unsubscribed events, alerts proven end-to-end, runbook (§5) rehearsed once.

---

## 4. Test strategy

| Layer | Tool | Scope | Runs |
|-------|------|-------|------|
| Unit | vitest | `math/*`, `positions/encode.ts`, planner, guards, config schema; golden vectors vs v4-sdk; property tests for bracket invariants | every push |
| Fork integration | `anvil --fork-url Base` + vitest | mint+subscribe, burn+mint+subscribe, negatives (`OutOfRange`, stale tokenId, double subscribe), gas, restart reconciliation, kill switch | every push (pinned fork block), nightly on latest block |
| Merkl API contract | vitest + recorded fixtures + zod | schema of `/v4/campaigns`, `/v4/opportunities`; live smoke asserts current params still match `expectedWeights` | fixtures every push; live nightly + at bot startup |
| Chaos | toxiproxy/in-process fault injector | RPC timeouts, dropped WS, duplicated receipts, reorg of 1 block, nonce gap | nightly |
| Soak | replayed price path on fork | 48h loop, zero unexpected sends | before canary |

Rules: no test touches mainnet with a funded key; fork block is pinned in CI; every revert path has a test.

---

## 5. Ops / custody

| Topic | Decision |
|-------|----------|
| Wallets | **Hot EOA** holds only operating capital + gas; **cold wallet** receives periodic TEL sweeps. Merkl pays the NFT owner, so claims land on hot and are swept. Optional separate spark wallet (Phase 4). |
| Secrets | `PRIVATE_KEY`, RPC URLs, webhook URLs via env / secret manager; `.env` git-ignored; schema refuses defaults. Migrate to KMS/Turnkey signer in `chain/signer.ts` if capital grows. |
| Approvals | Permit2 allowances to PosM scoped per token with expiry; revoke script in `scripts/`. |
| Monitoring | pino JSON → any sink; metrics: tick, in-range flags per id, subscribed flags, gas spent today, rebalances this week, last swap age; deadman alert if no heartbeat 10 min. |
| Alerts (page) | any live id unsubscribed; simulate failing 3× in a row; all three brackets out of range; RPC both down; kill switch engaged |
| Kill switch | `touch state/KILL` or `KILL_SWITCH=1`; blocks sends only |

Runbooks (write in Phase 3, rehearse in Phase 5):

1. **Failed subscribe / unsubscribed id**: read `PositionManager.subscriber(id)`. If zero → send `subscribe(id, 0x19ED…, 0x)` (must be in range). If registry says pruned → increase liquidity above `minLiquidity`, then `resubscribe(id)`. If `OutOfRange` → let orchestrator rebalance or widen manually.
2. **Stuck position (all brackets OOR, guards blocking)**: engage kill switch, run `dry-run-plan.ts`, raise `maxRebalancesPerWeek` or widen brackets in config, release switch.
3. **Stuck tx**: `txQueue` RBF after N seconds (≈ 20 s); manual: same-nonce zero-value self-send at higher fee.
4. **RPC outage**: failover automatic; if both down, bot idles and pages; positions stay subscribed and in range (no action needed short-term).
5. **Key compromise**: kill switch, revoke Permit2, burn positions to cold wallet via manual multicall, rotate key.
6. **Campaign params changed** (startup assert fails): do not start; re-verify Merkl API; update `expectedWeights`/pool list consciously.

---

## 6. Open questions

| # | Question | Needs | Blocks |
|---|----------|-------|--------|
| 1 | **Bracket shape** (§1.1): asymmetric straddles (A), nested (B), or one-sided + subscribe-on-entry (C)? | user | Phase 1 |
| 2 | TEL v3 `0x7E13…0731` is the `currency1` of both initialized Merkl pools (vs any other TEL deployment)? | on-chain (Phase 0 script) | Phase 0 gate |
| 3 | `minLiquidity[poolId]` numeric for ETH/TEL and eUSD/TEL; `inRangeRequired`; pool allowlist flags | on-chain | Phase 1 sizing |
| 4 | Does the registry restrict **owners** (EOA vs contract, any allowlist) beyond `MAX_SUBSCRIPTIONS = 1_000`? | on-chain source / fork test | Phase 2, custody |
| 5 | Merkl indexing lag subscribe → first root; does a new NFT inherit nothing (pure time-weight) or is there a lineage penalty? | canary observation | Phase 5 |
| 6 | Deployed Base PosM burn semantics: `BURN_POSITION` alone collects + burns, or needs `DECREASE_LIQUIDITY` first? | fork test | Phase 2 |
| 7 | Which pool first: eUSD/TEL (recommended) or ETH/TEL? | user | Phase 5 |
| 8 | Build Phase 4 spark at all? Merkl wash/JIT blacklist risk vs 50% fee axis | user + canary data | Phase 4 |
| 9 | `rebalanceMode` fallback: keep `burn_then_mint_gap` or atomic-only? | user | Phase 3 |
| 10 | Weekly budget: live ≈ 500k TEL/week/pool vs 425k in project context — update targets? | Merkl API (startup fetch) | reporting only |
| 11 | Alert channel (Slack vs Telegram) and who is on-call | user | Phase 3 |

---

## 7. Estimated effort

| Phase | Dev-days | Notes |
|-------|----------|-------|
| 0 Scaffold + read-only | 1.5 | Most time in Permit2/ABI collection and the verify script |
| 1 Math + planner | 2 | Decimals orientation and property tests dominate |
| 2 PosM encode + fork tests | 3 | Fork funding (storage deal), burn semantics, negative tests |
| 3 Orchestrator + safety | 3 | txQueue/RBF, restart reconciliation, alerts |
| 4 Spark (optional) | 1.5 | Skip unless Phase 5 says fee axis matters |
| 5 Soak + canary + scale | 2 active | Plus wall-clock waiting on soak and Merkl indexing (not effort) |
| **Total** | **~11.5–13** | Excludes user decision latency |

---

## 8. First concrete build step

`pnpm init` the repo, add viem + zod + vitest, write `config/pools.base.yaml` from blueprint §7, and ship `scripts/verify-pools.ts` that:

1. recomputes both poolIds from the PoolKeys and asserts equality,
2. reads `slot0`/`liquidity` via StateView for both pools,
3. reads `minLiquidity[poolId]`, `inRangeRequired`, allowlist on `0xcebC…`,
4. reads `decimals()` of `currency1` (expects 18, TEL v3) and eUSD (6),
5. fetches Merkl campaigns and asserts the expected params.

Green output closes open questions 2, 3 and part of 10, and is the Phase 0 acceptance gate.
