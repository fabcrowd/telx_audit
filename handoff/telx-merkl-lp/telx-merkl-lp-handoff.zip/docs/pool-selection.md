# TELx pool selection — which live Merkl pool pays a $2k multi-bracket LP best

**Status:** design research only (no trading code, no keys, no transactions).  
**Accessed / measured:** 2026-11-08, 21:40–22:05 UTC. Merkl API at 21:50 UTC; chain state at Base 54,921,079 / Polygon 96,979,464–713 / Ethereum 26,372,989 (Base eUSD/TEL reuses the 21:20 UTC snapshot, block 54,912,240, from [`edge-strategy.md`](./edge-strategy.md) so its numbers stay on the same basis). Logs: 30 days per pool.  
**Model:** $2k as the edge-strategy layout — **$1k core ±600 ticks, re-centred after 60 min outside; $1k anchor ±2220 ticks** — replayed on each pool's real 30-day swap tick path against each pool's live competitor set, scored with the Merkl 50/25/25 formula (validated against every pool's leaderboard, see §3). The build-plan straddle (A ±180t / B [−420,+180] / C [−180,+420], 50/25/25) is reported for comparison under the mechanics-doc trigger rules.  
**Raw data and scripts:** `/cursor/stores/bc-01a1bcd2-3013-7934-9c8a-85bdaadc427d/internal/pool-selection-data/` (per-pool `state.json`, `logs-30d.jsonl`, `analysis.json`, `sim-results.json`, `sim-output.txt`; `merkl/`; `summary-tables.md`).

---

## 0. Ranking

Seven live TELx `UNISWAP_V4_SUBSCRIPTION` campaigns exist (not two): three chains, identical params, **each 2,142,857 TEL for Nov 1–30 ≈ 500k TEL/week**. TEL priced at Merkl's $0.001536 (pool-implied prices are ≈ $0.00139–0.00141, −9%; edge-strategy used $0.00141 — multiply USD reward figures by 0.92 for that basis).

| Rank | Pool (chain, fee) | In-range subscribed TVL | Reward density (TEL/wk per $ in range) | **Expected TEL/week, edge layout** (30d replay · stress 7d · calm 7d) | Share | Re-centres/wk | IL + rebalance cost $/wk (30d) | Fees $/wk | **Net USD/wk** (30d · stress 7d · calm 7d) | With +$5k tight competitor (TEL/wk · net) | Confidence |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **1** | **Base eUSD/TEL 0.3%** | $29.3k | **17.1** | **71k · 94k · 95k** | 14.3% | 4.2 | −92 | 46 | **+64 · −64 · +133** | 32k · −26 | High on rank, medium on level (whale re-entry swings ±50%) |
| 2 | Ethereum eUSD/TEL 0.3% | $34.5k | 14.5 | 46k · 57k · 59k | 9.2% | 4.7 | −143 | 51 | −22 · −290 · +85 | 26k · −78 | Medium; highest vol of the set (117–178% ann.), L1 gas tail |
| 3 | Ethereum ETH/TEL 0.3% | $46.4k | 10.8 | 41k · 47k · 47k | 8.2% | 5.1 | −151 | 23 | −65 · −294 · −23 | 24k · −102 | Medium; negative net in every window |
| 4 | Base ETH/TEL 0.3% | $64.0k | 7.8 | 37k · 41k · 41k | 7.4% | 4.2 | −110 | 43 | −10 · −91 · +52 | 23k · −51 | High (one $56k wide whale holds 69% of L; stable book) |
| 5 | Polygon eUSD/TEL 0.3% | $56.2k | 8.9 | 34k · 39k · 39k | 6.9% | 4.7 | −120 | 56 | −10 · −14 · +46 | 22k · −55 | High (32 positions, most diversified book) |
| 6 | Polygon WETH/TEL 0.3% | $59.1k | 8.5 | 26k · 30k · 31k | 5.2% | 3.3 | −93 | **107** | +54 · −101 · +78 | 19k · +20 | Medium; net is fee-driven ($3.8M/30d volume), 36% of active L is unsubscribed |
| 7 | Polygon eUSD/eMXN 0.05% | $73.8k | 6.8 | 8.7k · 7.8k · 8.5k | 1.7% | 0.2 | −5 | 0 | +8 · +12 · −9 | 8k · +7 | High that it is last: $50k already sits in ±0.4–1.2% bands, our L share at spot is 0.2–6% whatever the width |

Reading the table:

- **Base eUSD/TEL stays the recommendation.** It ranks first on TEL/week in all 7 window × competitor combinations tested (§5) and first or third on net USD. The reason is purely structural: it is the thinnest book ($29k in range, 17 TEL/week per in-range dollar, 2× the next pool), and the in-range capital is almost entirely full-range or one-sided wide positions, so $1k at ±600 ticks takes ≈ 39% of the liquidity axis at today's tick (24% time-weighted over the last 30 days once the whale's re-entries are counted).
- The **straddle layout loses on every pool** (§4): under the mechanics-doc trigger rules it caps out at 5 re-centres/week and spends 13–26% of the time fully out of range; without caps it re-centres 8–16×/week and pays $220–360/week in IL and swap cost. Net USD is below the edge layout on every TEL pool except Ethereum eUSD/TEL where both are near zero.
- **Net USD is small everywhere.** With TEL at 100–190% annualised volatility, IL plus re-centring cost on the $1k core ($75–150/week) is the same order as the reward ($40–145/week). Only Base eUSD/TEL (reward density) and Polygon WETH/TEL (fee income from $900k/week of arbitrage flow) are reliably positive over 30 days; both go negative in the Nov 1–8 stress week.
- **Splitting $2k across two pools does not beat concentrating** (§6): share saturates as L/(L+L_others), but the second-best pool's $1k earns less (25k TEL/wk) than the marginal $1k in Base eUSD/TEL (31k TEL/wk). Net USD of a Base eUSD/TEL + Polygon WETH/TEL split is $72 vs $64 — inside the noise, and it costs a second chain, wallet and process.

---

## 1. Live campaigns (Merkl API, 2026-11-08 21:42 UTC)

`GET https://api.merkl.xyz/v4/campaigns?tokenSymbol=TEL&items=100` → 51 campaigns, creator `0x7E1C409D…1544` (TELx), 7 live `UNISWAP_V4_SUBSCRIPTION` with `startTimestamp 1793491200` (Nov 1) → `endTimestamp 1796083140` (Nov 30 23:59 UTC). All share `subscriptionContract 0xcebC…45E1`, `weightFees 5000 / weightToken0 2500 / weightToken1 2500`, `isOutOfRangeIncentivized false`, `genericTimeWeighted`, empty black/whitelists. Pool ids are identical across chains because the TEL v3, eUSD and eMXN contracts are CREATE2-deployed at the same addresses.

| Chain | Pair | poolId | Opportunity | Campaign | TEL/week | Merkl TVL | Merkl APR | On-chain check (PosM `poolKeys` → keccak(PoolKey) == poolId; registry `poolAllowed`, `minLiquidity`) |
|---|---|---|---|---|---|---|---|---|
| Base 8453 | eUSD/TEL 0.3%, spacing 60 | `0x1266df87…6982` | [16270260351359923751](https://app.merkl.xyz/opportunities/16270260351359923751) | `0x9d7de727…` | 500,012 | $30,153 | 132.8% | match; allowed; minLiquidity 0 |
| Base 8453 | ETH/TEL 0.3%, 60 | `0x272e0968…14a6` | [10837281193255818234](https://app.merkl.xyz/opportunities/10837281193255818234) | `0x56cc27c5…` | 500,012 | $67,857 | 59.0% | match; allowed; 0 |
| Polygon 137 | eUSD/TEL 0.3%, 60 | `0x1266df87…6982` | [10830042735387005267](https://app.merkl.xyz/opportunities/10830042735387005267) | `0x7f3a99f6…` | 500,012 | $59,573 | 67.2% | match; allowed; 0 |
| Polygon 137 | WETH/TEL 0.3%, 60 | `0xa22a3fb3…de0d` | [13504248474540896351](https://app.merkl.xyz/opportunities/13504248474540896351) | `0x0537e28d…` | 500,012 | $63,206 | 63.3% | match; allowed; 0 |
| Polygon 137 | eUSD/eMXN 0.05%, 10 | `0xe604df8f…a135` | [17210139955992544415](https://app.merkl.xyz/opportunities/17210139955992544415) | `0xee945ad0…` | 500,012 | $73,787 | 54.3% | match; allowed; 0 |
| Ethereum 1 | eUSD/TEL 0.3%, 60 | `0x1266df87…6982` | [15168878178363073459](https://app.merkl.xyz/opportunities/15168878178363073459) | `0x8f0835c2…` | 500,012 | $36,759 | 108.9% | match; allowed; 0 |
| Ethereum 1 | ETH/TEL 0.3%, 60 | `0x272e0968…14a6` | [11002303021148388696](https://app.merkl.xyz/opportunities/11002303021148388696) | `0x4e64aa5d…` | 500,012 | $49,214 | 81.3% | match; allowed; 0 |

Per-chain v4 periphery verified by `StateView.poolManager()` / `PositionManager.poolManager()` / registry `positionManager()`: Base PM `0x4985…2b2b`, PosM `0x7C5f…9bDc`, StateView `0xa3c0…a71`; Polygon PM `0x6736…5cD6`, PosM `0x1Ec2…eef9`, StateView `0x5eA1…BA5a`; Ethereum PM `0x0000…8A90`, PosM `0xbD21…ee9e`, StateView `0x7fFE…7227`. Registry `0xcebC…45E1` and subscriber `0x19ED…8c86` have code on all three chains with `inRangeRequired = true`. Protocol fee is on everywhere (`protocolFee 2048500` = 0.05% on the 0.3% pools, `512125` on eUSD/eMXN). Gas price at access: Base 0.006 gwei, Polygon 272 gwei POL ($0.088), Ethereum 0.055 gwei → one 1.2M-gas re-centre bundle ≈ **$0.016 / $0.029 / $0.15**.

Not live: Polygon eUSD/eMXN campaigns before Oct 1 came from a different creator; two `INVALID` campaigns (opportunity 12615830478756537233) are dead. No TELx campaigns on other chains were returned for `tokenSymbol=TEL`.

## 2. Pool facts (per pool, as of the access blocks above)

| Pool | In-range subscribed $ (token0 / token1) | Positions in range / owners | $ in ≤±1.5% bands · ≤±4% | Liquidity profile L(±1.5%)/L(spot), L(±4%)/L(spot) | $100 / $1k swap impact (in pool) | Swaps 7d / 30d | Volume 7d / 30d | LP fees 30d | σ annualised 30d / last 7d (from tick path) | 30d drift (token1) | Daily range median / max | ±600t breaches/wk · ±180t | Non-TEL leg | Unsubscribed in-range L |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Base eUSD/TEL | $29.3k ($19.3k / $10.0k) | 12 / 10 | $30 (dust ladder) · $0 | 1.0 / 1.0 above; 2.1 below −3.2% (the $16.6k TEL whale re-enters) | 0.61% / 7.1% | 805 / 5,168 | $43k / $291k | $875 | 108% / 180% | −22.5% | 6.8% / 32% | 4.9 · 36.9 | eUSD (stable) | 0% |
| Base ETH/TEL | $64.0k ($21.2k / $42.8k) | 9 / 8 | $0 · $189 | 0.96–1.0 | 0.14% / 1.4% | 1,995 / 10,690 | $177k / $517k | $1,552 | 98% / 161% | −13.6% | 5.9% / 29% | 5.1 · 31.5 | ETH (vol ≈ 50–60%) | 0% |
| Polygon eUSD/TEL | $56.2k ($24.3k / $32.0k) | 32 / 23 | $0 · $0 | 1.0–1.5 | 0.15% / 1.6% | 1,944 / 6,450 | $222k / $747k | $2,242 | 102% / 146% | −23.7% | 7.2% / 23% | 5.6 · 40.1 | eUSD | 0% |
| Polygon WETH/TEL | $59.1k ($19.2k / $39.9k) | 22 / 16 | $410 · $1.7k | 0.59–1.02 | 0.04% / 0.44% | 6,259 / 28,333 | $905k / $3.84M | $11,527 | 96% / 150% | −14.9% | 6.3% / 22% | 5.6 · 34.8 | WETH | **36%** |
| Polygon eUSD/eMXN | $73.8k ($54.3k / $19.6k) | 13 / 9 | **$50.3k (9 positions)** · $264 | 0.04–0.24 at ±1.5%, 0.013 at ±4% | 0.00% / 0.02% | 248 / 534 | $588k / $1.0M | $503 | 20% / 12% | −5.2% | 1.1% / 6.8% | 0.2 · 0.2 | eMXN (FX, ~12–20%) | 1% |
| Ethereum eUSD/TEL | $34.5k ($11.0k / $23.5k) | 13 / 9 | $0 · $0 | 1.0 | 0.27% / 2.7% | 416 / 1,718 | $122k / $536k | $1,609 | 117% / 178% | −23.0% | 8.2% / 34% | 10.7 · 41.7 | eUSD | 0% |
| Ethereum ETH/TEL | $46.4k ($13.5k / $32.9k) | 10 / 10 | $0 · $0 | 0.98–1.0 | 0.09% / 0.9% | 522 / 1,615 | $195k / $376k | $1,128 | 123% / 193% | −12.6% | 7.8% / 34% | 8.9 · 42.4 | ETH | 1% |

How each column was obtained: in-range subscribed capital from registry `getSubscribed → getSubscriptions → getPosition` filtered by poolId, PosM `getPositionLiquidity`, amounts via `getAmountsForLiquidity` maths at the current tick, USD at Merkl token prices (eUSD $1.002, ETH/WETH $2,222.6, eMXN $0.0534, TEL $0.001536); width classes from `tickUpper − tickLower`; liquidity profile from StateView `getTickBitmap`/`getTickLiquidity` over the whole tick range; price impact by walking that profile with an exact-input swap (fee excluded); swaps/volume/fees and the tick path from PoolManager `Swap` logs (token0 leg × token0 USD price; LP fees = volume × lpFee); volatility = stdev of hourly tick changes on a last-value-resampled path (ticks × 1e-4 ≈ %), annualised ×√8760; drift = tick change over 30d expressed as token1 price change; breach rates = immediate-re-centre count on the swap path. Merkl TVL/APR from `/v4/opportunities/<id>`. The "non-TEL leg" volatility matters for IL in USD terms only; Merkl share and the tick path already capture TEL-vs-leg moves.

Competitive structure in one line each: Base eUSD/TEL — two $10k wide positions (0x3b0b full-range, 0x5702 one-sided) plus a $16.6k all-TEL whale just below spot; Base ETH/TEL — one $56k ±100% position (0xd0c5, the same whale address) holds 69% of L and took 82% of the Oct 1–8 rewards; Polygon eUSD/TEL — five $5–10k full-range LPs and a $3.9k ±8.8% bot (0x8087) with 37% of L; Polygon WETH/TEL — $12.8k ±100% and $12.5k ±42% plus two ±7–9% bots, and a third of active L never subscribed; Polygon eUSD/eMXN — three LPs (0x8087, 0x878c, 0x327d) run ±0.4–1.2% ladders worth $50k, 0x878c re-mints weekly; Ethereum eUSD/TEL — $12.4k ±37% (0xcffb, 57% of L) and $9.4k ±67% (0x5429); Ethereum ETH/TEL — $28.5k ±20% (0x71d4, 74% of L) and $10.7k ±45% (0x5429). Address 0xe77D (the ±5% ERC-4337 bot from edge-strategy) is active on Base eUSD/TEL, Base ETH/TEL and Ethereum ETH/TEL.

## 3. Reward model validation (why the share numbers can be trusted)

For each pool, every position was rebuilt from 30 days of `ModifyLiquidity` logs plus current registry state, the campaign-window swaps replayed, and `0.5·TW(L share) + 0.25·TW(token0 share) + 0.25·TW(token1 share)` over subscribed-and-in-range positions compared with the live Merkl leaderboard (`/v4/rewards?campaignId=…`, 7.9 days into the campaign). Sum of squared share errors across all rewarded positions:

| Pool | Rewarded positions | SSE | Leaderboard TEL not reconstructed |
|---|---|---|---|
| Base eUSD/TEL | 60 | 6e-5 | 0 |
| Base ETH/TEL | 18 | 2e-5 | 4.1k of 554k |
| Polygon eUSD/TEL | 49 | 3e-4 | 34k of 547k (positions with no in-window `ModifyLiquidity` and no current subscription) |
| Polygon WETH/TEL | 197 | 1e-4 | 1.5k |
| Polygon eUSD/eMXN | 44 | 2e-4 | 0 |
| Ethereum eUSD/TEL | 27 | 9e-6 | 0 |
| Ethereum ETH/TEL | 26 | 3e-4 | 0 |

The formula from edge-strategy holds on all seven pools. Eligibility used for the replay: positions currently subscribed or ever rewarded in this campaign; that matters only on Polygon WETH/TEL, where 36% of active liquidity is unsubscribed (it dilutes fee income, not Merkl share).

## 4. $2k model results

Engine: `simulate_pool.py` (generalised from `edge-data/simulate.py`). Positions are built around the swap-path tick with the pool's spacing; a re-centre liquidates at the current tick, pays gas plus 0.6% on the inventory that has to be swapped to rebuild the mix (external venue; in-pool impact in §2 is why), and rebuilds. Competitors: wide positions static at today's values; positions narrower than ±1.5% are treated as re-centring bots that keep their width and L around spot (they are, on every pool where they exist — the eUSD/eMXN ladders, the Base dust ladder). Fees = lpFee × swap volume × our share of all active L. IL = end value vs HODL of the initial inventory with the non-TEL leg's USD price held fixed. Windows: last 30d; Nov 1–8 (stress, 10–34% daily ranges on TEL pools); Oct 25–Nov 1 (calm).

### 4.1 Edge layout ($1k core ±600t, 1h hysteresis; $1k anchor ±2220t)

Anchor re-centred when spot comes within 300 ticks of its edge (edge-strategy §5 rule). Static-anchor variant (edge-strategy's §3.2 table row) in `summary-tables.md`; it earns 10–15% less TEL on Base eUSD/TEL because the −22% October drift pulled spot to the anchor's edge.

| Pool | Static share at today's tick (TEL/wk) | 30d: TEL/wk · share · re-centres/wk · uptime core/any · IL+cost · fees · **net** | Stress 7d: TEL/wk · net | Calm 7d: TEL/wk · net |
|---|---|---|---|---|
| Base eUSD/TEL | 22.9% (114k) | 71.5k · 14.3% · 4.2 · 97%/100% · −$92 · $46 · **+$64** | 94.0k · −$64 | 94.8k · +$133 |
| Base ETH/TEL | 8.1% (41k) | 37.1k · 7.4% · 4.2 · 97%/100% · −$110 · $43 · **−$10** | 41.1k · −$91 | 41.1k · +$52 |
| Polygon eUSD/TEL | 8.7% (43k) | 34.4k · 6.9% · 4.7 · 97%/100% · −$120 · $56 · **−$10** | 39.5k · −$14 | 39.5k · +$46 |
| Polygon WETH/TEL | 5.2% (26k) | 25.9k · 5.2% · 3.3 · 97%/100% · −$93 · $107 · **+$54** | 30.4k · −$101 | 30.6k · +$78 |
| Polygon eUSD/eMXN | 1.8% (9k) | 8.7k · 1.7% · 0.2 · 100%/100% · −$5 · $0 · **+$8** | 7.8k · +$12 | 8.5k · −$9 |
| Ethereum eUSD/TEL | 14.1% (71k) | 46.0k · 9.2% · 4.7 · 96%/100% · −$143 · $51 · **−$22** | 57.2k · −$290 | 58.6k · +$85 |
| Ethereum ETH/TEL | 6.7% (33k) | 40.8k · 8.2% · 5.1 · 96%/100% · −$151 · $23 · **−$65** | 46.8k · −$294 | 47.3k · −$23 |

Base eUSD/TEL vs edge-strategy: that doc's "1h hysteresis" row is 70k TEL/wk · 14.0% · 3.5 re-centres · −$98 · +$46 net at $0.00141/TEL. This engine gives 61.7k (static anchor) to 71.5k (anchor rule) at 4.0–4.2 re-centres. Differences: exact ±600/±2220-tick widths instead of 6%/25% snapped, the dust ladder modelled as tracking, and the hysteresis timer firing at exactly +60 min instead of at the next swap event (a block-driven bot would do the former). Same conclusion either way.

### 4.2 Straddle A/B/C for comparison (build-plan §1.1 option A, mechanics-doc triggers)

Mechanics rules: arm band 60 ticks inside an outer edge held 20 min, or outside the envelope held 6 min; 6 h cooldown; hard cap 5/week (rolling).

| Pool | Mechanics rules: TEL/wk · share · re-centres · uptime (any bracket) · IL+cost · **net** (30d) | Immediate re-centre, no caps: TEL/wk · re-centres · IL+cost · **net** (30d) | Stress 7d net (rules / immediate) |
|---|---|---|---|
| Base eUSD/TEL | 85.3k · 17.1% · 4.2 · 75% · −$147 · **+$39** | 99.8k · 11.0 · −$263 · **−$33** | −$56 / −$462 |
| Base ETH/TEL | 52.1k · 10.4% · 4.7 · 82% · −$158 · **−$9** | 66.4k · 8.2 · −$221 · **−$30** | −$99 / −$254 |
| Polygon eUSD/TEL | 50.6k · 10.1% · 4.2 · 74% · −$149 · **+$7** | 59.2k · 9.3 · −$233 · **−$30** | −$58 / −$257 |
| Polygon WETH/TEL | 36.0k · 7.2% · 4.7 · 84% · −$183 · **+$170** (fees $298) | 39.4k · 8.4 · −$222 · **+$215** | +$166 / +$32 |
| Polygon eUSD/eMXN | 10.1k · 2.0% · 0.2 · 100% · −$10 · **+$6** | 10.1k · 0.2 · −$10 · **+$6** | +$16 / +$16 |
| Ethereum eUSD/TEL | 64.9k · 13.0% · 4.2 · 83% · −$115 · **+$67** | 47.4k · 15.6 · −$345 · **−$198** | −$82 / −$733 |
| Ethereum ETH/TEL | 57.1k · 11.4% · 4.7 · 87% · −$161 · **−$40** | 42.3k · 15.2 · −$361 · **−$261** | −$151 / −$839 |

The straddle's static share is 1.7× the edge layout's (38.7% vs 22.9% on Base eUSD/TEL) but at 100–190% volatility the ±420-tick envelope is breached 8–18×/week; the mechanics caps then strand it out of range 13–26% of the time, and without caps the swap cost of 8–16 re-centres/week erases the extra TEL. The one place it nets more TEL than the edge layout at positive net is Ethereum eUSD/TEL under caps (+$67), which is the pool with the second-highest reward density; it still trails Base eUSD/TEL on TEL/week.

Other widths (30d, current competitors, TEL/wk · net): Base eUSD/TEL ±420t 103k · +$4, ±600t single 88k · +$35, ±1200t 67k · +$72, full-range 18k · +$28; Ethereum eUSD/TEL ±600t 62k · +$10; Polygon WETH/TEL ±180t 59k · +$146 (fees); eUSD/eMXN ±30t 20k · −$11, ±100t 12k · +$8. Full table in `summary-tables.md`.

### 4.3 Cost per re-centre (assumptions used)

| Item | Base | Polygon | Ethereum | Source |
|---|---|---|---|---|
| Gas, 1.2M-gas burn/mint/subscribe bundle | $0.016 | $0.029 | $0.15 at 0.055 gwei; **$2.7 at 1 gwei, $13 at 5 gwei** | `eth_gasPrice` at access; ETH $2,222, POL $0.088 |
| Inventory swap | 0.6% of the token amount that must be swapped (0.3% fee + ~0.3% impact, external venue) | same | same | edge-strategy assumption; in-pool impact of a $1k swap is 0.4–7% (§2), so never swap in-pool on Base eUSD/TEL or Ethereum eUSD/TEL |
| Typical swapped amount on a core re-centre | $250–500 | | | half the core is one-sided after an exit |
| Zero-in-range gap during a 3-tx re-centre | ≈ 10 min on Base/Polygon, ≈ 3–5 blocks ≈ 1 min on Ethereum | | | mechanics §4.4 |

Gas is immaterial on Base and Polygon. On Ethereum it is immaterial only at today's 0.05 gwei; a 1–5 gwei regime would add $13–65/week at 4.7 re-centres, which alone moves both Ethereum pools to clearly negative net.

## 5. Robustness

**Rank by TEL/week of the edge layout across windows and competitor scenarios** (1 = best):

| Pool | 30d | 30d +$5k@±4% | 30d +$5k@±1.5% | stress 7d | stress +$5k@±4% | calm 7d | Range |
|---|---|---|---|---|---|---|---|
| Base eUSD/TEL | 1 | 1 | 1 | 1 | 1 | 1 | **1–1** |
| Ethereum eUSD/TEL | 2 | 2 | 3 | 2 | 2 | 2 | 2–3 |
| Ethereum ETH/TEL | 3 | 3 | 2 | 3 | 3 | 5 | 2–5 |
| Base ETH/TEL | 4 | 4 | 4 | 4 | 4 | 3 | 3–4 |
| Polygon eUSD/TEL | 5 | 5 | 5 | 5 | 5 | 4 | 4–5 |
| Polygon WETH/TEL | 6 | 6 | 6 | 6 | 6 | 6 | 6 |
| Polygon eUSD/eMXN | 7 | 7 | 7 | 7 | 7 | 7 | 7 |

Rank by net USD is noisier (Base eUSD/TEL 1/3/1 over 30d/stress/calm; Polygon WETH/TEL 2/5/3; eUSD/eMXN 3/1/6 because it barely moves) — the net column is dominated by the TEL vol regime, which is common to all TEL pools, so it does not re-order the TEL pools much; it only says that in a week like Nov 1–8 no TEL pool is positive with this layout.

**One extra $5k competitor entering tight** (30d replay, edge layout): tracking ±4% costs us 56% of TEL on Base eUSD/TEL (71k → 32k, net +$64 → −$26), 28–44% on the other TEL pools, 8% on eUSD/eMXN; tracking ±1.5% costs 46–72% on TEL pools (72% on Base eUSD/TEL). Base eUSD/TEL is the most sensitive because it is the thinnest book, yet it remains first in absolute TEL in both cases (32k vs 26k for the runner-up).

**Whale re-entry (Base eUSD/TEL only):** the $16.6k all-TEL position at tick < 341,640 (TEL ≥ $0.001457) is in the replay whenever the path crosses it (56% of the last 30 days, 37% of the last 7). edge-strategy §3.3 quantifies the swing at ±60–80% of our TEL; it is the main reason the level (not the rank) is medium-confidence.

**Base eUSD/TEL vs Ethereum eUSD/TEL** is the only close call on fundamentals (17.1 vs 14.5 TEL/week per in-range dollar). Ethereum loses on three counts: higher realised vol (10.7 vs 4.9 breaches/week at ±600t), concentrated competitors already at ±37–67% (our static L share 22% vs 39%), and L1 gas tail risk.

## 6. Split or concentrate?

Edge layout at $1k per pool (sim-results-1000.json) vs $2k in one pool, 30d replay:

| Allocation | TEL/wk | Net $/wk |
|---|---|---|
| $2k Base eUSD/TEL | **71.5k** | +64 |
| $1k Base eUSD/TEL + $1k Ethereum eUSD/TEL | 65.5k (40.8k + 24.6k) | +36 |
| $1k Base eUSD/TEL + $1k Base ETH/TEL | 60.5k | +41 |
| $1k Base eUSD/TEL + $1k Polygon WETH/TEL | 54.3k | +72 (fee-driven) |

Share saturates ($1k earns 57% of what $2k earns in Base eUSD/TEL), but the second pool's $1k is worth less than the marginal $1k at home. Concentrate; keep Ethereum eUSD/TEL as the fallback if the Base book thickens (e.g. a copycat), since its reward density is next and its competitors are static.

## 7. Data gaps and caveats

- **Competitors held static** for 30 days (except sub-±1.5% positions modelled as tracking). Polygon eUSD/TEL (0x8087 ±8.8%), WETH/TEL (±7–9% bots) and both Ethereum pools have mid-width bots that do re-mint; the replay therefore overstates our share slightly on those pools. 0xe77D runs ±5% on three pools; its L is small.
- **Ethereum log source:** `rpc.flashbots.net` silently returned empty ranges ("pruned history"); the final data uses `mainnet.gateway.tenderly.co` (10k-block chunks) and reconciles with the leaderboard to SSE ≤ 3e-4. Polygon via `polygon-bor-rpc.publicnode.com` (10k chunks), Base via `base-rpc.publicnode.com` (50k).
- **Block → time** interpolated between 50k-block samples (±2 min on Base/Polygon, ±10 min on Ethereum).
- **USD basis:** TEL at Merkl's $0.001536; pools trade at $0.00139–0.00142. ETH/WETH USD held fixed inside the replay (IL on ETH pairs is in ETH terms × $2,222). eUSD at $1.002.
- **Fee income** assumes our fee share equals our share of all active L at the current tick; it ignores protocol fee (0.05% of the 0.3%), which overstates fees by ≈ 17% — relevant for the Polygon WETH/TEL net only.
- **Ethereum gas** sampled once (0.055 gwei). **Polygon eUSD/eMXN** leaderboard join is good (SSE 2e-4) but its tick path has only 534 swaps in 30 days, so its breach statistics are coarse; the conclusion (≤ 6% L share at any width) comes from the current book, not the path.
- Merkl's sampling cadence and "frequent rebalancing" blacklist thresholds remain unknown (edge-strategy §6); nothing here changes those.
- Polygon eUSD/TEL: 34k of 547k leaderboard TEL (6%) belongs to tokenIds with no in-window liquidity event and no current subscription — probably positions opened before Oct 9 and burned before Nov 1; they do not affect the current competitor set.

## 8. Sources (all accessed 2026-11-08)

| Item | How |
|---|---|
| Campaign list, params, status | `https://api.merkl.xyz/v4/campaigns?tokenSymbol=TEL&items=100` (21:42 UTC) → `internal/pool-selection-data/merkl-campaigns-tel.json` |
| Opportunity TVL/APR/token prices | `https://api.merkl.xyz/v4/opportunities/<id>?campaigns=true` (21:50 UTC) → `merkl/opportunity-<slug>.json` |
| Leaderboards | `https://api.merkl.xyz/v4/rewards?chainId=<c>&campaignId=<id>&items=500` → `merkl/leaderboard-<slug>.json` |
| v4 periphery / registry verification | `verify_chains.py` → `verify-chains.json` (`poolKeys`, `getSlot0`, `getLiquidity`, `poolAllowed`, `minLiquidity`, `inRangeRequired`, `poolManager()` cross-checks) |
| Pool state, tick profile, subscriptions | `collect.py <slug>` → `<slug>/state.json` (multicall3-batched StateView / PosM / registry reads) |
| Swap + ModifyLiquidity logs, 30d | `collect.py` → `<slug>/logs-30d.jsonl`, `<slug>/block-timestamps.json` |
| Reconstruction, validation, stats | `analyze_pool.py <slug>` → `<slug>/analysis.json`, `<slug>/analysis.log` |
| Replay | `simulate_pool.py <slug> [budget]` → `<slug>/sim-results.json`, `<slug>/sim-results-1000.json`, `<slug>/sim-output.txt` |
| Cross-pool tables | `summarize.py` → `summary-tables.md`, `summary-table.json` |
| Base eUSD/TEL inputs | copied from `internal/edge-data/` (state block 54,912,240; logs 52,394,741→54,911,753) to keep parity with edge-strategy |
| Gas / native prices | `eth_gasPrice` per chain; ETH price from Merkl token list; POL from Merkl `/v4/tokens?chainId=137&symbol=POL` ($0.0882) and CoinGecko ($0.0886) |
