# TELx Merkl LP Bot — Project Context

## Core objectives

- **Target:** Automate liquidity provision for TELx pools on Uniswap v4 (Base), especially low-volume TEL/eUSD or TEL/ETH.
- **Optimize for:** Merkl reward paybacks (fixed weekly ~425,000 TEL per pool), not Uniswap v4 trading fees.
- **Capital:** ~$2,000 inside ~$40k–$50k TVL (~4–5% raw pool ownership).
- **Mission:** Capture an outsized share (target 20–50%) of fixed weekly Merkl rewards via concentration and uptime vs wide-range passive LPs.
- **Unit of account (user decision 2026-11-08):** the user wants to hold TEL and the goal is **acquiring more TEL**. Score strategies by expected TEL accumulated (Merkl TEL + fees in TEL + inventory TEL change), with USD only as a secondary exposure check. Downside conversion (eUSD → TEL as price falls) is a gain; the cost is upside conversion (TEL → eUSD on rallies) and gas.
- **Pool (user decision 2026-11-08):** eUSD/TEL on Base first; confirmed by [`pool-selection.md`](./pool-selection.md) across all 7 live TELx campaigns.

## Technical constraints

- Uniswap v4: pools live in a singleton `PoolManager`; liquidity changes use flash accounting (EIP-1153). Cheap on Base L2.
- Merkl: off-chain, time-weighted; live Base TELx campaigns (verified 2026-11-08) score **subscribed + in-range** liquidity with **50% fees / 25% token0 / 25% token1** — not a flat snapshot, and **not** the Essential Guide’s Passive/Active/JIT period classifier (that classifier lives on a legacy registry Merkl does not use). Details: [`telx-merkl-reward-rules.md`](./telx-merkl-reward-rules.md).
- **Mandatory:** minting a Uniswap v4 position alone does not earn rewards. Every new position ID must be subscribed to the Merkl-era TELx registry.
- Base TELx pools are currently low-volume (“ghost pools”): wide passive ranges leave the active ticks uncontested, but zero volume also hurts fee-weighted Merkl scores.

## Strategy architecture

### A. Staggered-bracket layout (TIR uptime)

| Position | Capital | Range |
|----------|---------|--------|
| A (core) | $1,000 | ±1.5% around spot |
| B (lower buffer) | $500 | ±4% below spot |
| C (upper buffer) | $500 | ±4% above spot |

Rebalance only when spot threatens to exit the outer buffer boundaries (ignore micro-ticks). Avoid razor-thin single ranges that force frequent burns and reset Merkl time-weighting.

### B. Rebalance bundle (atomicity configurable)

Preferred capital-safe shape (when `rebalanceMode=atomic_rebalance`) is one Base transaction / tight nonce sequence that:

1. Burns out-of-range position IDs (via PositionManager unlock actions)
2. Mints new centered staggered brackets
3. Subscribes new IDs on the Merkl-era TELx registry

Staggered mint/burn modes remain supported; do **not** treat same-block burn+mint as automatically Merkl-illegal based on the Essential Guide alone (see reward-rules research).

### C. Volume-spark keep-alive

If `no_volume_duration > 3 hours`, route a negligible internal swap (e.g. ~$5 TEL) through the bot’s own core tick so Merkl logs utilization. Net cost ≈ Base gas (fee returns to own LP).

## Immediate deliverable

Structural blueprint for a Python (web3.py) or TypeScript (viem) bot: slot0 monitoring, bracket-breach detection, configurable rebalance + Merkl subscribe path. Design first; no live deployment until addresses, ABIs, campaign params, and risk controls are verified.

## Out of scope (for now)

- Live mainnet capital deployment
- MEV / sandwich attack tooling
- Competing with other protocols’ incentives beyond TELx Merkl on these pools
