# Adaptive range-width controller (Base eUSD/TEL, Merkl)

**Status:** design only — no trading code, no secrets, no transactions.  
**Date:** 2026-11-08.  
**Pool / campaign:** same as [`edge-strategy.md`](./edge-strategy.md) and [`measure-rebalance-mechanics.md`](./measure-rebalance-mechanics.md) (Base `0x1266df87…6982`, 500k TEL/week, 50/25/25 time-weighted).  
**Scripts / data:** `/cursor/stores/bc-01a1bcd2-3013-7934-9c8a-85bdaadc427d/internal/adaptive-width-data/` (`backtest.py`, `tel_objective.py`, `telx_adaptive.py`, `backtest-output.txt`, `backtest-results.json`).

**Related:** [`project-context.md`](./project-context.md) (TEL unit of account) · [`edge-strategy.md`](./edge-strategy.md) (fixed ±600 / ±2220 baseline) · [`measure-rebalance-mechanics.md`](./measure-rebalance-mechanics.md) (triggers, slot model, config shell).

---

## 0. Deltas vs fixed layout (edge-strategy §5 / mechanics D11)

| # | Prior default | This doc | Why |
|---|----------------|----------|-----|
| D1 | Core ±600, anchor ±2220, 50/50 split, symmetric | **Ship v1 fixed**; optional **skew** (`−360/+840` core when solver agrees) and **split** nudges on natural core re-centre only | Monte Carlo (+2–3k ex-HODL TEL/wk vs symmetric at σ₃₀d) is smaller than replay noise; full width reshape loses ≈34k total TEL/wk vs fixed (§6). |
| D2 | Inventory-matched centre only | Add **token-tilt tie-break**: among inventory-matched centres, prefer higher `0.25·tok0Share + 0.25·tok1Share` (TEL scarcer in-range today → slight downward skew) | `skew-and-levers.md`: +2.7k ex-HODL at `−360/+840` vs `−600/+600`. |
| D3 | — | **Competitor-adaptive policy:** on **tight tracking entrant** (±240 t, ≥$1k), **widen** core toward ±1200–1500 t and/or **raise anchor weight** to 60–85%; **do not match** tight width | Solver + replay: matching ±240 loses 46–72% Merkl; widening retains share with less IL. |
| D4 | — | **Width reshape off by default** (`controller.widthReshapeEnabled: false`); when on, changes piggyback **only** on scheduled core re-centre (60-min dwell), never forced mid-range except `forceMultiple × switchCost` race guard | Event replay: 9 forced reshapes → −40k IL TEL/wk vs fixed. |
| D5 | Merkl claim manual | **Claim-and-compound** via `INCREASE_LIQUIDITY` on core or anchor when marginal ex-HODL gain ≥ `evMultiple × (claim + increase + swap)` over remaining horizon; else hold TEL wallet inventory | Backtest: compound on fixed **reduces** total TEL/wk in actual scenario (IL from mid-book top-ups); still document for long campaigns. |
| D6 | `total_tel_wk` objective optional | **Primary objective:** `total_ex_hodl_tel_wk` (drift-neutral TEL accumulation); report `total_tel_wk` and `tel_count_delta_wk` for user preference | User holds TEL: upside eUSD→TEL is counted in `hodl_mix_term`; ex-HODL strips intentional exposure. |

---

## 1. TEL objective

Merkl budget **R = 500_000 TEL/week**. For our bot over window *T*:

\[
\text{TEL}(T) = \underbrace{\int_0^T \text{share}(t)\,R_{TEL}(t)\,dt}_{\text{Merkl (dominates)}} + \underbrace{\int \text{fees}_{TEL}(t)\,dt}_{\text{small}} + \underbrace{\Delta \text{TEL}_{\text{inventory}}(T)}_{\text{LP concavity ± HODL exposure}}
\]

**Share** (in-range, subscribed only):

\[
\text{share} = 0.50\,\frac{L_{us}}{\sum L} + 0.25\,\frac{x_0^{eUSD}}{\sum x_0} + 0.25\,\frac{x_1^{TEL}}{\sum x_1}
\]

**Numeraire** `W_TEL = TEL + eUSD × (TEL/eUSD at pool tick)` — same as `telx_adaptive.w_tel`. Weekly decomposition used in simulation and solver:

| Term | Meaning | Sign for TEL-holder |
|------|---------|---------------------|
| `merkl_tel_wk` | Campaign stream | Always + |
| `fees_tel_wk` | 0.3% LP fees on others’ swaps, converted to TEL | Small + |
| `hodl_mix_term_tel_wk` | Value of **starting token mix** at end price minus start (`W_TEL` of HODL mix) | **+ when TEL falls** (eUSD → more TEL); **− when TEL rallies** |
| `il_tel_wk` | LP value vs that HODL mix (concavity) + re-centre swap/gas, in TEL | Usually − |
| `delta_w_tel_wk` | End `W_TEL` − start | Net inventory |
| **`total_tel_wk`** | Merkl + fees + `delta_w_tel` (compounded Merkl already inside liquidity) | User-facing gross |
| **`total_ex_hodl_tel_wk`** | `total_tel_wk` − `hodl_mix_term_tel_wk` | **Controller objective** — “did we beat holding the initial bag in TEL?” |

**Compounding:** claimed Merkl TEL increases `W_TEL` immediately; `INCREASE_LIQUIDITY` moves it into L without changing TEL count until the eUSD leg is swapped. Objective includes gas + 0.6% swap on the eUSD fraction of the target range (`backtest.py` `_compound_now`).

**Implementation:** `tel_objective.Evaluator` — 256-path × 72h bootstrap on hourly tick increments (trailing 7d σ, fat tails preserved), common random numbers for layout comparison. Runtime ≈50–100 ms per solve on measurement refresh.

---

## 2. Competitor model

### 2.1 Inputs (measurement T2)

From registry `getSubscribed` → positions in poolId, plus **historical** `ModifyLiquidity` replay (`telx_adaptive.build_history`) for backtests:

- Per position: `(tickLower, tickUpper, liquidity, owner, tokenId)`.
- **`L_others(tick)`** = sum of competitor `liquidity` with `tickLower ≤ tick < tickUpper` (tick profile grid ±6000 t, step 60).
- **Token denominators** at tick: competitor `amount0/amount1` sums for 25/25 axes.
- **Map signature** for refresh: `(round(L_others(spot)/1e16), position_count)` — re-solve when signature changes or every `resolveEveryS` (default 30 min).

### 2.2 Owner classes (30d mint behaviour + live book)

Source: `competitor-profiles.json` / `.md` (block 54,912,240 spot 341,966).

| Class | Examples | Median width | Behaviour | Threat |
|-------|----------|--------------|-----------|--------|
| **full-range passive** | `0x4041…`, `0x3b0b…` | ~1.77M t | Rare mint; huge L, dilutes L-axis | Low per $; stable |
| **wide static** | `0x5702…` | ~120k t | Weekly remint | Medium on token axes |
| **whale OOR** | `0xd0c5…` | 5580 t | $16.6k TEL wall; **+3.2% TEL rally** → +1.85e18 L | **Dilution event** |
| **mid-width bot** | `0xe77D…` | 780 t (±5%) | ~43 mints/30d, tracks spot | **Primary race** (33.5% L today) |
| **dust ladder** | `0xbbe5…`, `0xe70E…` | 240 t slots | Pre-subscribed staging; refill `INCREASE` | Operational template, not share threat |
| **tight bot** | various | 60–180 t | JIT-style | Blacklist tail if abused |

**Concentration around spot** (`L_others` only):

| ±k ticks | min L | mean L | note |
|--------|-------|--------|------|
| 60–180 | 8.74e17 | 8.74e17 | At spot, book ≈ flat |
| 300 | 8.07e17 | 8.56e17 | Dust ladder below spot |
| **600** | **5.14e17** | 1.22e18 | **Whale wall** if TEL weakens into band |
| 2220 | 5.14e17 | 1.30e18 | Anchor width still sees wall |

### 2.2.1 Synthetic overlays (stress)

| Overlay | Trigger | Modelling |
|---------|---------|-----------|
| `tight5k_midmonth` | t = window + 15d | $5k, ±240 t, re-centres with spot |
| `whale_midmonth` | t = window + 15d | 1.85e18 in ±25% band in range |

### 2.3 Match vs widen (solver, σ₃₀d trailing)

From `skew-and-levers.md` “Response to tight entrant”:

| Entrant $ | Fixed ±600 ex-HODL | **Match ±240** | **Widen (best sym)** | Full solve (skew + split) |
|-----------|-------------------|----------------|----------------------|---------------------------|
| 0 | 67.5k | — | ±360 → 69.8k | −360/+360 40% + anchor 60% → **70.9k** |
| 1k | 42.5k | 33.5k | ±480 → 42.6k | anchor-heavy 70% → 44.9k |
| 5k | 19.7k | **0.4k** | ±1500 → **23.7k** | **−1260/+1740 60% + anchor 40% → 23.9k** |
| 10k | 13.0k | −10.5k | ±1500 → 19.4k | anchor 85% → 19.8k |

**Rule:** `if tight_tracking_entrant: widen_core_and_anchor_heavy` else `if L_others(spot) jumped (whale): anchor_heavy + accept lower liq share`. Never narrow to match a ±1.5% bot.

---

## 3. Layout levers (search space)

Symmetric widths use **half-width in ticks** (spacing 60). Asymmetric core: `Bracket(tel_side, eusd_side, weight)` → `[c − tel_side, c + 60 + eusd_side)` (tick ↑ = TEL cheaper; **more tel_side = range shifted below spot** → more TEL inventory).

| Lever | Grid | Default |
|-------|------|---------|
| Core half (symmetric) | 180 … 1500 | **600** (widen to 780 if σ_ann > 170%, 1200–1500 under tight entrant) |
| Core skew | `tel_side / (tel+eusd)` ∈ {0.42, 0.50, 0.58} | **0.58/0.42 → −360/+840** when σ₃₀d and no tight race |
| Anchor shape | `(2220,2220)`, `(3000,1440)` | **(2220,2220)** |
| Core/anchor split | 15% … 70% core | **50/50**; **30/70 or 15/85** when `L_others(spot) > 2× baseline` |
| Vol switch | σ_h 7d | coreHalf 780 if `volAnn7d > 1.70` (exit < 1.50) |

**Static L share** at spot is **not** the objective — time-weighted share with uptime + IL matters (`edge-strategy` §3).

---

## 4. Controller (hysteresis, guards, execution)

Two layers:

1. **Re-centre engine** (unchanged from mechanics §3): core 60-min dwell / 200-t immediate; anchor 300-t margin; caps 3/day soft, 12/week hard; EV gate on `hard` triggers.
2. **Adaptive solver clock** (every `resolveEveryS`, on competitor map change): run `tel_objective.solve`, compare to **current layout**, optionally set **pending layout**.

### 4.1 Decision rule (plain language)

On each solver tick, evaluate the current two-bracket layout and the best layout from coordinate descent (`core` → `asym` → `anchor` → `split`). Let `gain_wk` = improvement in `total_ex_hodl_tel_wk`, `gain_h` = `gain_wk × min(72h, 168/recentres_wk) / 168`, `switch_cost_tel` = swap to new token mix + 2× gas. **Adopt pending layout** only if:

1. **Persistence:** best layout unchanged for **`persistN` ≥ 3** consecutive solves (~90 min).  
2. **EV:** `gain_h ≥ evMultiple × switch_cost_tel` (default **3**).  
3. **Deadband:** `gain_wk ≥ max(10% × |current objective|, 3000 TEL/wk)`.  
4. **Rate limits:** same as re-centre (2 h cooldown, 12/week hard).  
5. **Width reshape:** if `widthReshapeEnabled` is false, pending may only change **skew** (same total core width ±120 t) and **split**, not core half-width.

**Application:** apply pending on the **next core re-centre** (`fire`), not a standalone reshape. **Exception:** if `gain_h ≥ forceMultiple × switch_cost` (default **10**) and caps allow, one **forced** reshape (logged; max 1/day).

### 4.2 State machine (additive to mechanics §3.5)

```
IN_RANGE_HEALTHY ──(solver: pending layout)──► PENDING_LAYOUT
PENDING_LAYOUT ──(core trigger fires)──► EXECUTING (Shape R/M with new bounds)
PENDING_LAYOUT ──(persistence lost / map reverted)──► IN_RANGE_HEALTHY
```

### 4.3 Guards summary

| Guard | Default | Blocks |
|-------|---------|--------|
| `persistN` | 3 | Whipsaw on noisy L_others |
| `evMultiple` | 3 | Low-value reshapes |
| `deadbandFrac` / `deadbandMinTelWk` | 0.10 / 3000 | chatter |
| `widthReshapeEnabled` | **false** | mid-book width changes |
| `maxRebalancesPerWeek` | 12 | forced + core recentres |
| `killSwitch` | — | all applies |

### 4.4 Competitor reaction shortcut (no solver)

If a subscribed position **new in 24h** with width ≤ 300 t and USD ≥ $1000 is classified **tight bot** and tracks spot:

- Set **`raceMode = widen`**: target core ±1200–1500, anchor weight ≥ 60%, skew toward TEL-heavy (−1260/+1740 style) until entrant leaves or 7d elapsed.  
- Do **not** enter `raceMode = match`.

---

## 5. Skew and inventory

1. **Inventory-matched core centre** (mechanics §5.2 `planCore`) — default on every re-centre.  
2. **Token tilt tie-break:** if multiple centres with `imbalanceUsd ≤ swapToleranceUsd`, pick max `tok0Share + tok1Share` on 25/25 axes (favours holding scarcer in-range token). Today TEL is scarcer → **downward skew** (`−360/+840`).  
3. **Do not** skew so far that near-side USD &lt; 1% of core (mechanics `minNearSideFraction`).

Anchor asymmetry `(−3000,+1440)` raises Merkl slightly but adds anchor recentres; **keep symmetric ±2220** unless solver gains &gt; deadband **and** reshape piggybacks on anchor move.

---

## 6. Claim-and-compound

**Cadence:** Merkl roots ≈ every 8 h; rewards claimable after `ROOT_LAG_S` ≈ 3 h (`backtest.py`).

**Rule (`Strategy._compound_now`):**

1. When `claimable_tel ≥ 5000` (~$7) and at least 24 h since last compound (or piggyback on re-centre).  
2. Bootstrap marginal: current layout at `V` vs `V + ΔV` with ΔV added to core or anchor weight; pick higher `total_ex_hodl_tel_wk` over remaining horizon `h_rem`.  
3. Compound if marginal gain ≥ `3 × (claim_gas + increase_gas + eusd_leg_swap)`; else **leave claimed TEL in wallet** (still counts toward TEL).  
4. Execution: `Distributor.claim` → `INCREASE_LIQUIDITY` on chosen slot (same subscribed range); **no** `subscribe` again.

**Backtest note:** on **actual** 30d replay, fixed+compound **underperforms** plain on `total_tel_wk` (44k vs 49k) because top-ups interact with volatile path; compounding helps more in calm σ windows. Ship with `compoundEnabled: true` but marginal gate strict (`evMultiple` 3).

---

## 7. Backtest tables (30d event replay, Nov 2026 window)

Method: historical competitor liquidity from logs; swap tick path; overlays mid-month; strategies in `backtest.py`. **Fixed** = symmetric ±600/±2220, 50/50, mechanics triggers. **Controller** = full solve + reshape enabled (research upper bound — **not** v1 default).

### 7.1 Scenario `actual` (historical competitors)

| Strategy | Merkl TEL/wk | fees | IL | costs | HODL mix | **Total TEL/wk** | **ex-HODL** | TEL count Δ/wk | reb/wk | wchg |
|----------|-------------|------|-----|-------|----------|------------------|-------------|----------------|--------|------|
| fixed plain | 59,384 | 17,551 | −59,261 | 6,311 | 37,858 | **49,221** | **11,363** | 40,937 | 4.2 | 0 |
| fixed compound | 63,263 | 18,608 | −68,356 | 7,436 | 37,858 | 43,937 | 6,079 | 80,571 | 4.2 | 0 |
| controller plain | 68,240 | 23,080 | −99,704 | 14,141 | 37,858 | 15,333 | −22,525 | 23,780 | 9.1 | 9 |
| controller compound | 71,875 | 23,949 | −93,076 | 11,799 | 37,858 | 28,807 | −9,051 | 31,493 | 6.1 | 7 |
| straddle plain | 74,284 | 27,495 | −81,014 | 11,957 | 39,684 | 48,492 | 8,808 | −19,714 | 3.7 | 0 |

**Uplift vs fixed ±600/±2220 (actual):** full controller **−33,888 TEL/wk** on **total** (49,221 → 15,333); **+8,856** on Merkl only; **−33,888 ex-HODL**. Conclusion: **do not enable unconstrained width reshape**; use fixed baseline + §4.4 widen-on-entrant.

### 7.2 Stress overlays (fixed plain vs controller plain)

| Scenario | fixed Total TEL/wk | fixed ex-HODL | controller Total | controller ex-HODL |
|----------|-------------------|---------------|------------------|-------------------|
| tight5k mid-month | 17,832 | −20,026 | 3,596 | −34,262 |
| whale mid-month | 23,687 | −14,171 | 2,107 | −35,751 |

Fixed layout degrades under entrant/whale; controller does not rescue in replay because reshape costs dominate — **entrant widen policy** is preventive (set wide **before** dilution), not reactive reshape.

### 7.3 Ex-post optimum tracking

Fraction of controller time within **one grid step** of the best fixed symmetric half-width that day (`expost` column): **≈0.09–0.21** — adaptive width does not track daily optimum; fixed ±600 is within one step ~**21%** of days.

### 7.4 Monte Carlo width curve (static competitors, not replay)

From `objective-curves.md` (σ₃₀d 115 t/h): best ex-HODL **±360** (69.8k) vs ±600 (67.5k) — **+2.3k TEL/wk** potential if uptime were free; replay IL erases this. Under σ₇d stress, **±1500** beats ±600 on ex-HODL (+16.1k vs −14.9k in MC).

---

## 8. Typed configuration

Extends `BotConfig` in mechanics §7:

```ts
export interface AdaptiveWidthConfig {
  enabled: boolean;                          // master switch (default false for v1)
  objective: "total_ex_hodl_tel_wk" | "total_tel_wk";  // default ex-HODL
  measurement: {
    resolveEveryS: number;                     // 1800
    sigmaWindowsH: [number, number];           // [24, 168]
    competitorRefresh: "on_modify_log" | "poll"; // on_modify_log + 12 min poll
  };
  solver: {
    paths: number;                             // 256 live; 160 backtest controller
    horizonH: number;                          // 72
    seed: number;
    coreHalfs: number[];                       // tel_objective.SolverCfg
    asymFracs: number[];
    anchorShapes: [number, number][];
    splits: number[];
    stages: ("core" | "asym" | "anchor" | "split")[];
  };
  controller: {
    persistN: number;                          // 3
    evMultiple: number;                        // 3
    forceMultiple: number;                     // 10
    deadbandFrac: number;                      // 0.10
    deadbandMinTelWk: number;                  // 3000
    widthReshapeEnabled: boolean;              // false (v1)
    skewOnlyEnabled: boolean;                  // true — allow asym on re-centre
    raceMode: "off" | "widen" | "match";       // widen only; match forbidden
    tightEntrantMaxWidthTicks: number;         // 300
    tightEntrantMinUsd: number;                // 1000
    widenCoreHalfTarget: number;               // 1200–1500
    anchorHeavyMinWeight: number;              // 0.60 under race
  };
  compound: {
    enabled: boolean;
    minClaimTel: number;                       // 5000
    minHoursBetween: number;                   // 24
    evMultiple: number;                        // 3
    targetPreference: "marginal_solver" | "core" | "anchor"; // marginal_solver
  };
  defaults: {
    layout: Layout;                            // sym(600), sym(2220), 0.5/0.5
    highVolCoreHalf: number;                   // 780
    volAnnEnter: number;                       // 1.70
    volAnnExit: number;                        // 1.50
  };
}

export interface Layout {
  core: Bracket;    // { telSide, eusdSide, weight }
  anchor: Bracket;
}
```

**Zod:** `raceMode !== "match"`; if `!widthReshapeEnabled`, solver stages must exclude `"core"` width changes or controller filters candidates to fixed `tel_side+eusd_side`; `persistN ≥ 2`; `forceMultiple ≥ evMultiple`.

Wire into planner: measurement layer passes `Market` snapshot → `solve` → `pending Layout` on `RebalancePlan` when armed.

---

## 9. Recommended rollout

| Phase | Behaviour |
|-------|-----------|
| **0 – Canary** | Fixed `AdaptiveWidthConfig.enabled = false`; skew via `planCore` token tilt only. |
| **1 – Skew** | `skewOnlyEnabled = true`; solver runs, updates **only** `tel_side/eusd_side` on core re-centre if persisted + EV pass. |
| **2 – Race** | `raceMode = widen` on tight entrant detection (§4.4); manual confirm first week. |
| **3 – Research** | `widthReshapeEnabled = true` only on fork with forced cap 1/week and A/B vs fixed ex-HODL. |

---

## 10. Sources

| Item | Location |
|------|----------|
| 30d logs, state | `internal/edge-data/` |
| Competitor profiles | `internal/adaptive-width-data/competitor-profiles.json` |
| Objective curves, skew | `objective-curves.md`, `skew-and-levers.md`, `.json` |
| Replay output | `internal/adaptive-width-data/backtest-output.txt` (2026-11-08 run) |
| Merkl scoring | [`telx-merkl-reward-rules.md`](./telx-merkl-reward-rules.md), `edge-strategy` §1.3 |

---

## 11. One-liners (handoff)

- **Objective:** maximise **`total_ex_hodl_tel_wk`** = Merkl TEL + fees in TEL + Δ`W_TEL` − holding the initial token mix at the final price (TEL numeraire).  
- **Controller:** every 30 min (or competitor map change), solve layout; adopt only after **3 persisted solves**, **EV ≥ 3× switch cost**, and **deadband**; apply on **core re-centre**; **default: no core half-width reshape**; on tight entrant **widen + anchor-heavy**, never match.  
- **Backtest uplift vs fixed ±600/±2220:** **−33.9k TEL/wk total** (full adaptive reshape on actual 30d); **+8.9k Merkl only**; v1 ships **fixed** with widen-on-race and optional skew.
