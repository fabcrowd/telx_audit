# TELx Merkl LP Bot — Deployment stack review, subscribe assurance, and wireframe

**Status:** design review. No code, no keys, no transactions.  
**Date:** 2026-11-08 (pool comparison read live at ~22:30 UTC).  
**Inputs reviewed:** [`build-plan.md`](./build-plan.md) §2 (stack), [`bot-blueprint.md`](./bot-blueprint.md) §5 (subscribe bundle), [`measure-rebalance-mechanics.md`](./measure-rebalance-mechanics.md) §3–4 (slot model, execution), [`edge-strategy.md`](./edge-strategy.md) (layout, thresholds).  
**Data:** `/cursor/stores/bc-01a1bcd2-3013-7934-9c8a-85bdaadc427d/internal/edge-data/pool_compare.py` → `pool-compare.json`, `merkl-campaigns-tel-all.json`.

---

## 0. Verdicts

| Question | Answer |
|---|---|
| Is the chosen pool the best TELx pool? | **Yes — Base eUSD/TEL.** All 7 live TELx campaigns pay the same 500k TEL/week; Base eUSD/TEL has the least in-range capital ($29k) and the smallest full-range incumbents, so $2k at ±6% takes a static 28.7% share (143k TEL/wk) — 1.5× the next best (Ethereum eUSD/TEL, 18.7%) and 2.6× Base ETH/TEL (11.0%). §1. |
| Is the proposed stack right? | **Yes with four changes:** (a) slot model replaces burn-all/mint-all, so `subscribe` is only ever called for *new* slots; (b) add a dedicated WS RPC (Alchemy/QuickNode free tier) with publicnode HTTP fallback — the public `mainnet.base.org` endpoint 429s on `eth_getLogs` and is not usable for the bot's hot path; (c) drop `spark/` and Universal Router from Phase 1–3 scope entirely; (d) add a Merkl claim job (Distributor) and a reward-reconciliation job that compares realised share to the estimator. §2. |
| How is "subscribe is done" guaranteed? | Five layers: eligibility pre-check → `simulateContract` of the exact multicall → atomic `[modifyLiquidities, subscribe×n]` → post-receipt verification of `PosM.subscriber(id)` **and** `registry.isTokenSubscribed(id)` → continuous invariant with REPAIR path and a "no new mints while any slot unsubscribed" guard. §3. |
| Where does it run? | One Docker container on a small always-on host (Fly.io / Railway / Hetzner CX22-class), systemd or Fly restart policy, encrypted env for the key, persistent volume for state + JSONL, Telegram alerts, dead-man heartbeat. §4. |

---

## 1. Pool selection (all live TELx Merkl campaigns, 2026-11-08)

Source: Merkl `/v4/campaigns?tokenSymbol=TEL&status=LIVE` (7 campaigns, all `UNISWAP_V4_SUBSCRIPTION`, all 2,142,857 TEL / 30 d, all 50/25/25, in-range only, registry `0xcebC…45E1` on every chain); per-pool registry + StateView + PosM reads via `mainnet.base.org`, `ethereum-rpc.publicnode.com`, `polygon-bor-rpc.publicnode.com`; TEL $0.00141, ETH $2,123–2,227, POL $0.087 (CoinGecko).

| Chain | Pair | Merkl TVL | In-range subscribed $ | Positions (in range / all) | Tight (<30% wide) share of in-range L | $2k ±6% static share → TEL/wk | $2k ±12% | Rebalance bundle gas (1.2M gas) |
|---|---|---|---|---|---|---|---|---|
| **Base** | **eUSD/TEL** | $19.8k | **$29.1k** | 12 / 26 | 0.41 | **28.7% → 143k** | 21.1% | $0.03 |
| Ethereum | eUSD/TEL | $36.4k | $34.6k | 13 / 14 | **0.00** | 18.7% → 94k | 12.9% | $1.70 |
| Polygon | eUSD/TEL | $59.1k | $56.7k | 31 / 38 | 0.55 | 11.7% → 59k | 7.7% | $0.03 |
| Base | ETH/TEL | $66.0k | $64.1k | 9 / 11 | 0.21 | 11.0% → 55k | 7.2% | $0.03 |
| Ethereum | ETH/TEL | $47.8k | $46.3k | 10 / 11 | 0.06 | 9.0% → 45k | 6.2% | $1.79 |
| Polygon | WETH/TEL | $61.3k | $59.6k | 22 / 26 | 0.64 | 5.3% → 27k | 3.7% | $0.03 |
| Polygon | eUSD/eMXN 0.05% | $73.5k | not analysed | — | — | — | — | $0.03 |

Reading:

- **Base eUSD/TEL** wins on the only thing that matters under this formula — the least *active* liquidity per TEL of budget. Static share has risen since the earlier read (tick 341,966 → 342,475; TEL −5%) because the all-TEL whale (3204934) is now 8.6% out of range instead of 3.3%.
- **Ethereum eUSD/TEL is the natural second pool** if capital grows: zero tight competitors today, 2.3× our L/$ advantage intact, and mainnet gas at 0.64 gwei makes a rebalance ≈ $1.7 (fine at 3–6/week). Its 12-s blocks and $1.7 bundles argue for wider bands (±8–12%) there. Not recommended for the first $2k: two chains doubles ops surface for ~65% of the Base yield.
- ETH/TEL pools and Polygon pools are dominated by larger in-range books (Polygon already has 55–64% of active L in tight bands — the edge is being competed away there).
- **eUSD/eMXN (Polygon)** is the one candidate not analysed: an FX pair (~10% annualised vol vs TEL's 147%) where a ±1% band would almost never be breached, so the liquidity axis would be decided purely by who is tightest. Worth a separate look later; outside this task's eUSD/TEL scope.

Stale-price note: the Base pool marks TEL ≈ 9% below Merkl's oracle ($0.001535). That does not change the share maths (Merkl scores on-chain L and token amounts) but it does mean the USD value of rewards and inventory should use one consistent mark in P&L.

---

## 2. Stack review

### 2.1 What stands (from `build-plan.md` §2)

TypeScript 5 / Node 22 LTS / ESM · **viem** (public, wallet, WS clients, `simulateContract`, `multicall`) · `@uniswap/v4-sdk` + v4-periphery `Actions` constants (pinned to the deployed Base PosM version — see mechanics doc R5) · zod config · vitest · Foundry `anvil --fork-url` for integration · pino JSON logs · pnpm. Python only for the offline analytics already in `internal/edge-data/`.

### 2.2 Changes

| # | Change | Why |
|---|---|---|
| S1 | **Slot model is the execution primitive** (mechanics D3): persistent subscribed NFTs; refill = `INCREASE_LIQUIDITY`, drain = `DECREASE_LIQUIDITY` to `dustL ≥ 1e13`; `MINT_POSITION` + `subscribe` only when no slot exists for the target range. | Registry checks in-range only at `handleSubscribe`; `notifyModifyLiquidity` is a no-op. Cuts subscribe calls to ~1 per new range, removes the `nextTokenId` race for the common path, keeps tokenIds long-lived (lower "frequent rebalancing" optics). |
| S2 | **RPC: dedicated provider for the hot path.** Primary: Alchemy or QuickNode Base (free tier is enough: ~1 `eth_call` batch per 2-s block + WS `newHeads`). Secondary: `base-rpc.publicnode.com` (HTTP, 50k-block `getLogs` range). Never `mainnet.base.org` for logs. | Measured today: `mainnet.base.org` returns 429 on any `eth_getLogs`; publicnode is fine for reads but has no WS guarantee. |
| S3 | **Remove `spark/` and Universal Router from scope.** `swapRoute: 'off'` by default; the ±25% anchor supplies inventory (edge-strategy §5–6). | Liquidity axis is swap-independent; self-trades are a documented blacklist trigger. |
| S4 | **Add `rewards/`**: (a) hourly poll of Merkl `/v4/rewards?chainId=8453&campaignId=…` filtered to our address → `realisedShare`; (b) weekly claim via Merkl Distributor `0x3Ef3…9Ae` using proofs from `/v4/users/{addr}/rewards?chainId=8453`; (c) sweep claimed TEL to cold wallet above a threshold. | Reward reconciliation is the primary tuning signal (mechanics §6.4); claims are the whole point. |
| S5 | **Signer:** viem `privateKeyToAccount` from env for the canary; move to a KMS/Turnkey-backed `LocalAccount` implementation behind `chain/signer.ts` before scaling past $2k. Permit2 allowances scoped to PosM, 30-day expiry, renew job. | Hot key holds operating capital; keep the blast radius to one pool's inventory. |
| S6 | **State:** single JSON state file + append-only JSONL events on a persistent volume; chain is truth on restart (enumerate `Transfer` logs to our address + `getSubscriptionsRaw(ours)` from the registry). No sqlite until reporting needs it. | Restart reconciliation is cheap: ≤ 10 tokenIds. |
| S7 | **Geometry defaults** from edge-strategy §6: `coreHalf 600`, `anchorHalf 2220`, hard trigger + 1 h dwell on the core, immediate anchor re-centre at 300 t margin, cooldown 2 h, caps 3/day soft, 12/week hard, reserve 0, dust ladder on. | Replaces the mechanics doc's 180/420/5-per-week defaults, which were derived from a 30× too-low volatility read. |

### 2.3 Module map (final)

```text
src/
├── config/        schema.ts (zod) · load.ts · pools.base.yaml (PoolKey, poolId, registry, subscriber, distributor, weights)
├── chain/         client.ts (HTTP+WS, dual provider failover) · signer.ts · txQueue.ts (mutex, nonce, RBF, idempotency) · abis/
├── monitor/       slot0.ts (per block) · logs.ts (Swap/ModifyLiquidity backfill) · competitors.ts (registry scan, every 15 blocks)
├── math/          ticks.ts · liquidity.ts · share.ts (Merkl 50/25/25 estimator) · inventoryMatch.ts (build_matched port)
├── positions/     encode.ts (Actions + subscribe + multicall) · inventory.ts (our slots, reconcile from chain)
├── telx/          eligibility.ts (poolAllowed, minLiquidity, inRangeRequired, isTokenSubscribed, belowSubscriptionThreshold) · merklApi.ts (campaign assert)
├── rewards/       realised.ts (leaderboard poll) · claim.ts (Distributor) · sweep.ts
├── orchestrator/  engine.ts (state machine) · planner.ts (core/anchor/dust plans) · execute.ts (plan → simulate → send → verify)
├── safety/        guards.ts · killSwitch.ts · invariants.ts (REPAIR path)
└── index.ts
```

---

## 3. Subscribe assurance (the part that must never fail)

**Facts the design relies on (verified on chain / in source, 2026-11-08):**

- `PositionManager.subscribe(uint256 tokenId, address subscriber, bytes data)` is `onlyIfApproved` and `onlyIfPoolManagerLocked`; it reverts `AlreadySubscribed` on a second call. Subscriber must be `0x19EDFa380ead0Bb26010Ca3d1C7AbC7213938c86`, which has `SUBSCRIBER_ROLE` on registry `0xcebC…45E1` (`hasRole` = true).
- `TELxSubscriber.notifySubscribe` → `PositionRegistry.handleSubscribe` → `_index`: reverts `PoolNotAllowed`, `LiquidityBelowThreshold` (L = 0 or < `minLiquidity`, currently 0), `OutOfRange` (`tickLower ≤ tick < tickUpper` false). Any revert reverts the whole PosM `multicall`, so **capital never moves without the subscription landing**.
- A subscribed position stays subscribed through `INCREASE`/`DECREASE` (no-op notify) and through going out of range. It is removed only on transfer, burn, explicit unsubscribe, or a third-party `pruneSubscription` when L < `minLiquidity` (L = 0 counts).
- `getSubscriptions(owner)` (votable) hides out-of-range slots; use **`getSubscriptionsRaw(owner)`** and `isTokenSubscribed(id)` for truth.

### 3.1 Five layers

| Layer | When | Check / action | Failure handling |
|---|---|---|---|
| L1 Pre-flight eligibility | before planning | `poolAllowed`, `inRangeRequired`, `minLiquidity` re-read; every **new** range satisfies `tickLower ≤ tick − 60` and `tick + 60 < tickUpper` (`mintSafetyTicks`); planned L ≥ max(`dustL`, 2 × `minLiquidity`) | plan rejected, re-plan next block |
| L2 Simulation | before send | `simulateContract(PosM.multicall([modifyLiquidities, subscribe(id_i, SUB, 0x)…]))` with `id_i = nextTokenId + i`; decode revert selectors (`OutOfRange`, `AlreadySubscribed`, `LiquidityBelowThreshold`, `NotApproved`) | 3 consecutive sim failures → `DEFERRED` + warn; never send unsimulated |
| L3 Atomic bundle | send | One PosM `multicall`; `subscribe` calls are **siblings after** `modifyLiquidities` (PoolManager must be locked) — never inside the unlock actions, never with a swap in between | revert = nothing happened; re-read `nextTokenId`, re-plan |
| L4 Post-receipt verification | +3 blocks | For each new id: `PosM.ownerOf(id) == signer`, `PosM.subscriber(id) == 0x19ED…`, `registry.isTokenSubscribed(id) == true`, `registry.belowSubscriptionThreshold(id) == false`, `PosM.getPositionLiquidity(id) ≥ planned × (1 − slippage)`. For refilled ids: liquidity delta matches, still subscribed. | any mismatch → `REPAIR` (below); state not committed until verified |
| L5 Continuous invariant | every 15 blocks (~30 s) | For every slot with L > `dustL`: `subscriber(id) == SUB` **and** `isTokenSubscribed(id)`; `!belowSubscriptionThreshold(id)`; `ownerOf(id) == signer`. Guard: **no new mints while any live slot is unsubscribed.** | `REPAIR`: if PosM says unsubscribed and slot is in range → `subscribe(id)` (one tx); if PosM subscribed but registry not → `resubscribe(id)` (permissionless); if below threshold → `INCREASE` to `2 × dustL` then `resubscribe`; if out of range and unsubscribed → wait for re-entry or re-centre; 3 failed attempts → `HALTED` + page |

### 3.2 Sequence (wireframe)

```mermaid
sequenceDiagram
  autonumber
  participant E as Engine
  participant P as Planner
  participant R as Registry 0xcebC (read)
  participant RPC as Base RPC (sim)
  participant Q as txQueue
  participant PosM as PositionManager
  participant Sub as TELxSubscriber 0x19ED
  participant Reg as Registry (write)
  participant V as Verifier

  E->>P: trigger(core breach ≥1h | anchor margin | dust-slot entry)
  P->>R: poolAllowed, minLiquidity, inRangeRequired, isTokenSubscribed(our ids)
  P->>P: plan: refill existing slot? → INCREASE ; else MINT new + subscribe
  P->>PosM: nextTokenId()  (predict ids for mints)
  P->>RPC: simulateContract(multicall([modifyLiquidities, subscribe×n]))
  RPC-->>P: ok / revert(OutOfRange | AlreadySubscribed | LiquidityBelowThreshold)
  alt simulation ok and guards pass
    P->>Q: send(multicall, idempotencyKey = planHash)
    Q->>PosM: multicall([...])
    PosM->>PosM: modifyLiquidities → unlock → DECREASE/INCREASE/MINT/SETTLE/TAKE
    PosM->>Sub: subscribe(id_i) → notifySubscribe
    Sub->>Reg: handleSubscribe(id_i) → _index (allowlist, L≥min, in-range)
    Reg-->>PosM: ok (or revert → whole multicall reverts)
    Q-->>V: receipt (+3 blocks)
    V->>PosM: ownerOf, subscriber, getPositionLiquidity (each id)
    V->>Reg: isTokenSubscribed, belowSubscriptionThreshold (each id)
    V-->>E: verified → commit state, start cooldown
  else
    P-->>E: DEFERRED (retry next block) / HALT after 3
  end
  loop every 15 blocks
    E->>Reg: isTokenSubscribed(all live ids), belowSubscriptionThreshold
    E->>PosM: subscriber(id), ownerOf(id)
    E->>E: REPAIR if any mismatch; block new mints meanwhile
  end
```

### 3.3 Fork tests that gate Phase 2 (add to build-plan acceptance)

1. Mint core + anchor + 2 dust slots and subscribe all in one multicall; assert L4 checks.
2. Move fork price out of the core; `INCREASE_LIQUIDITY` on an out-of-range **subscribed** dust slot succeeds with no subscribe; move price back in; `isInRange` true; Merkl-style estimator counts it.
3. Negative: mint with `tickLower > tick` → whole multicall reverts `OutOfRange`; balances unchanged.
4. Negative: second `subscribe` on same id → `AlreadySubscribed`.
5. `DECREASE` a slot to L = 0 → `belowSubscriptionThreshold` true → third party `pruneSubscription` succeeds (proves the dust floor is needed); refill → `resubscribe` succeeds.
6. Kill process between send and verify → restart reconciles from `getSubscriptionsRaw(signer)` + `Transfer` logs, no duplicate action.

---

## 4. Deployment wireframe

```mermaid
flowchart LR
  subgraph Host["Always-on host (Fly.io / Railway / small VPS), 1 container, restart=always"]
    direction TB
    B[bot process<br/>Node 22 · TS · viem]
    S[(persistent volume<br/>state.json · events.jsonl · KILL file)]
    B <--> S
  end
  subgraph Secrets["Encrypted env (host secret store)"]
    K[PRIVATE_KEY<br/>RPC_PRIMARY_WS/HTTP<br/>RPC_FALLBACK_HTTP<br/>ALERT_WEBHOOK]
  end
  K -.inject at start.-> B
  subgraph RPC["Base RPC"]
    A[Primary: Alchemy/QuickNode<br/>WS newHeads + HTTP calls]
    P2[Fallback: base-rpc.publicnode.com<br/>HTTP, getLogs ≤50k blocks]
  end
  B <-- "slot0/liquidity per block,<br/>registry scan /15 blocks,<br/>simulate + send" --> A
  B -. failover .-> P2
  subgraph Chain["Base contracts"]
    PM[PoolManager 0x4985…]
    PosM[PositionManager 0x7C5f…<br/>multicall · modifyLiquidities · subscribe]
    SV[StateView 0xa3c0…]
    Reg[TELx PositionRegistry 0xcebC…]
    Sub[TELxSubscriber 0x19ED…]
    Dist[Merkl Distributor 0x3Ef3…]
    Permit2[Permit2 0x0000…22D4]
  end
  A --> PosM & SV & Reg & Dist & Permit2
  PosM --> PM
  PosM --> Sub --> Reg
  subgraph Merkl["Merkl API (hourly)"]
    M1[/v4/campaigns — assert params/]
    M2[/v4/rewards — realised share/]
    M3[/v4/users/addr/rewards — claim proofs/]
  end
  B <--> M1 & M2 & M3
  subgraph Ops["Ops"]
    T[Telegram/Slack webhook<br/>page · warn · info]
    D[Dead-man endpoint<br/>heartbeat each loop]
    C[Cold wallet<br/>TEL sweeps]
  end
  B --> T & D
  Dist -- claim → hot --> B -- sweep --> C
```

**Runtime loop (per 2-s block):** WS head → batched `eth_call` {slot0, liquidity, our slot liquidity} → engine state machine (edge-strategy §5 thresholds) → if armed: plan → simulate → guards → send → verify → commit. Every 15 blocks: registry scan + invariants (§3.1 L5). Hourly: Merkl campaign assert (fail closed), realised-share poll. Weekly: claim + sweep. Always: kill switch check before any send; heartbeat after every loop.

**Environments:** `dry-run` (full loop, no sends, logs the decoded bundle) → `fork` (anvil, scripted price paths, §3.3 tests) → `live-canary` ($100, one forced re-centre, one claim) → `live` ($2k). Promotion criteria unchanged from build-plan Phase 5.

**Sizing:** one vCPU / 512 MB is ample; RPC usage ≈ 45k calls/day (free tiers allow 1–3M/day). Monthly cost ≈ $5–10 host + $0 RPC + ≈ $1 gas.

---

## 5. Open items (carry to coordinator)

| # | Item | Needs |
|---|---|---|
| 1 | Confirm Merkl claim endpoint/proof format for `UNISWAP_V4_SUBSCRIPTION` rewards on Base (`/v4/users/{address}/rewards?chainId=8453` → `claim(users[], tokens[], amounts[], proofs[][])`) | Phase 0 read-only test against an address on the leaderboard |
| 2 | Pin deployed Base PosM/UR versions (mechanics R5) | Phase 2 |
| 3 | Alert channel (build-plan Q11) | user |
| 4 | Second-pool decision (Ethereum eUSD/TEL) once the Base canary has run two weeks | user |
| 5 | eUSD/eMXN (Polygon) FX-pair analysis as a separate task | coordinator |
