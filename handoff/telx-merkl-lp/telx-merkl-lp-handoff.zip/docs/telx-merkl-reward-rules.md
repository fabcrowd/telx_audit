# TELx Merkl reward rules on Base — research findings

**Access date:** 2026-11-08  
**Scope:** Design research only for TELx Uniswap v4 LP rewards on Base (TEL/ETH, TEL/eUSD). No bot implementation.

---

## Verdict (crisp)

| # | Question | Answer |
|---|----------|--------|
| 1 | Is Passive-only / ≤1 modify / ~24h (43_200 Base blocks) still **in force for Merkl-paid TELx rewards** on Base? | **No** (for live Merkl scoring). **Contested / stale** as a public-guide claim. |
| 2 | What does Merkl currently score? | Subscribed + **in-range** Uniswap v4 liquidity; **50% fees / 25% token0 / 25% token1**; time-weighted; empty campaign blacklist; Merkl platform anti-JIT/wash blacklisting still applies. |
| 3 | Implication for same-block burn+mint+subscribe | **Not automatically zeroed** by TELx Passive/JIT period weights under live Merkl campaigns. Still a **configurable** ops choice: capital continuity vs Merkl anti-gaming risk / TIR reset. |
| 4 | Primary sources | Listed at bottom with access dates. |

### Assumptions status

| Claim | Status | Evidence |
|-------|--------|----------|
| Passive-only / ≤1 modify / 43_200 blocks zeros rewards | **Contested → treat as stale for Merkl path** | Live Merkl campaigns use new `PositionRegistry` with **no** Passive/Active/JIT weights; Essential Guide still describes old model and links old registry |
| Merkl manages TELx Base LP incentives today | **Verified** | Live `UNISWAP_V4_SUBSCRIPTION` campaigns Nov 2026 for ETH-TEL and eUSD-TEL |
| Subscribe required | **Verified** | Campaign type + TELx docs + new registry purpose |
| In-range required for Merkl rewards | **Verified** | `isOutOfRangeIncentivized: false`; new registry `inRangeRequired() == 1` |
| Same-block burn+mint = 0 Merkl weight for period | **Unknown / unlikely under Merkl CLAMM math**; old native JIT weight still 0 on **retired** registry | Merkl params have no TELx JIT period classifier; Merkl may still blacklist predatory JIT |
| Weekly budget ~425k TEL/pool | **Unknown vs live** | Live Nov campaigns ≈ **500k TEL/week** each (~2.14M TEL / 30d). 425k appears in a rebalancing TELxIP contingent on Telcoin Network launch |

---

## What changed

TELx ran a Merkl POC on Base TEL–ETH (periods p37–p40, Apr–May 2026), then approved Merkl as the ongoing distribution partner ([TELxIP #850](https://forum.telcoin.org/t/telxip-implementation-of-merkl-across-telx-pools/850)). Governance intent explicitly included **replacing reliance on the custom v4 incentive-hook reward model** with Merkl campaign parameters (active-tick / token0 / token1 weights).

Two Base `PositionRegistry` contracts now matter:

| Role | Address | Passive/JIT levers? | Used by live Merkl? |
|------|---------|------------------|---------------------|
| **Legacy native rewards registry** (Essential Guide “Advanced” link) | `0x3994e3ae3Cf62bD2a3a83dcE73636E954852BB04` | **Yes** — `MIN_PASSIVE_LIFETIME`, `PASSIVE_WEIGHT`, `ACTIVE_WEIGHT`, `JIT_WEIGHT`, `JIT_LIFETIME` | **No** (not in Merkl `subscriptionContract`) |
| **Merkl-era subscription registry** | `0xcebC0b00473Ca00e429eF431826d0A32cdc945E1` | **No** — subscribe / minLiquidity / in-range only; rewards owned by Merkl | **Yes** |

On-chain read 2026-11-08 (Base, via `base.drpc.org`):

- Legacy: `MIN_PASSIVE_LIFETIME = 43200`, `JIT_LIFETIME = 1`, `PASSIVE_WEIGHT = 10000`, `ACTIVE_WEIGHT = 0`, `JIT_WEIGHT = 0` (still Passive-only **if that contract’s formula were used**).
- Merkl-era: `inRangeRequired() = 1`; `MIN_PASSIVE_LIFETIME()` **reverts** (selector absent).

New registry verified source states rewards are **owned by Merkl**; the contract is a thin subscription index for governance / Merkl eligibility — no reward math.

---

## Live Merkl campaigns (Base, accessed 2026-11-08)

| Pool | Merkl opportunity | Status | TVL (API) | Daily rewards (USD, API) |
|------|-------------------|--------|-----------|--------------------------|
| Uniswap v4 ETH-TEL 0.3% (Subscribed) | [10837281193255818234](https://app.merkl.xyz/opportunities/10837281193255818234) | LIVE | ~$68.0k | ~$109.84 |
| Uniswap v4 eUSD-TEL 0.3% (Subscribed) | [16270260351359923751](https://app.merkl.xyz/opportunities/16270260351359923751) | LIVE | ~$30.2k | ~$109.84 |

**Current campaign window (both):** 2026-11-01 → 2026-11-30; amount `2142857142750000000000000` wei TEL ≈ **2,142,857 TEL / ~30 days ≈ 500k TEL/week**.

**Shared campaign params (creator `0x7E1C…1544`):**

```text
type: UNISWAP_V4_SUBSCRIPTION
subscriptionContract: 0xcebC0b00473Ca00e429eF431826d0A32cdc945E1
weightFees: 5000          # 50% — Merkl “liquidity contribution” / fees axis
weightToken0: 2500        # 25%
weightToken1: 2500        # 25%
isOutOfRangeIncentivized: false
computeScoreParameters.computeMethod: genericTimeWeighted
distributionMethod: DUTCH_AUCTION
hooks: []
blacklist: []
whitelist: []
forwardingEnabled: true
```

Pool IDs in params match TELx Liquidity Framework:

- TEL/ETH Base: `0x272e0968e2fb347236c6060cc9395f13591968f3f83056c600c755066dd214a6`
- TEL/eUSD Base: `0x1266df876a41a4f4250dbfa9887e70f20a40a3ccd802c8d75b51b7fd4eb36982`

These weights match POC “Campaign F (50/25/25)” cited as the most equitable variant in the [POC summary](https://forum.telcoin.org/t/telx-poc-summary-report/849).

Merkl schema for `UNISWAP_V4_SUBSCRIPTION` (type 170) exposes **no** Passive / Active / modify-frequency / 43_200 fields — only subscription contract, fee/token weights, OOR flag, lists, forwarding.

---

## How this relates to the Essential Guide

[TELx Liquidity Mining: Essential Guide for LPs](https://www.telx.network/about/telx-liquidity-mining-essential-guide-for-lps) (still live 2026-11-08) states:

> Currently, only “Passive” behavior is rewarded.  
> Passive = ≤1 liquidity modify per ~24h; Active / JIT → 0% weight.  
> Base threshold: **43200 blocks**.  
> Advanced link → legacy registry `0x3994e3…BB04`.

That text matches the **legacy** registry’s weight model (`PASSIVE_WEIGHT=10000`, others 0). It does **not** match live Merkl campaign configuration.

Separately, Merkl-managed-rewards marketing pages correctly say: subscribe + stay in range; Merkl computes off-chain; claim via TELx or Merkl. They do **not** restate Passive-only.

**Uncertainty:** TELx has not clearly deprecated the Essential Guide Passive section after Merkl cutover. Until TELx updates that page or confirms in Discord/governance, treat Passive-only as **documentation debt**, not as the Merkl engine rule.

---

## Merkl scoring vs TELx labels

| Mechanism | Still applies to Merkl TELx Base? | Notes |
|-----------|-----------------------------------|-------|
| TELx Passive / Active / JIT period weights | **No evidence in live Merkl path** | Live on legacy registry only; unused by Merkl `subscriptionContract` |
| Subscribe NFT to TELx registry | **Yes** | Campaign type requires subscription |
| In-range only | **Yes** | Campaign + `inRangeRequired` |
| Time-weighted liquidity / fee share (50/25/25) | **Yes** | Live params |
| Campaign blacklist/whitelist | Empty today | Configurable per campaign |
| Merkl platform JIT / wash blacklist | **Yes (platform-level)** | Merkl KB: withdrawing before a swap and re-adding after can get an address blacklisted — distinct from TELx same-block period zeroing |
| 1 bp min size / auto-unsubscribe | **Likely still via registry** | New registry has `minLiquidity` / `belowSubscriptionThreshold`; Essential Guide 1 bp rule not re-verified per-pool value on-chain in this pass |
| NFT transfer unsubscribes | **Likely** | Consistent with registry design + Essential Guide; not re-proven tx-by-tx here |

There is **no Merkl “volume” weight** separate from the fees/liquidity-contribution axis. TIR enters via time-weighted in-range presence, not a named TIR knob in campaign JSON.

---

## Implication for atomic burn + mint + subscribe

Under **live Merkl** params:

1. Burning ends the old position’s contribution when liquidity is gone.
2. Minting a new NFT starts a new position; rewards require **subscribe** on the Merkl-era registry and **in-range**.
3. There is **no Merkl campaign parameter** that zeros the whole reward period because two liquidity mods occurred inside 43_200 blocks.
4. Therefore same-block burn→mint→subscribe is **not proven to inherit the old “JIT → 0% for the period” TELx rule**.

Residual risks (keep configurable, do not hard-default from the guide):

- Merkl may still flag **predatory** JIT (liquidity only around swaps) via platform blacklist — different pattern than a full-range re-center rebalance.
- New positions reset time-weight / concentration history (TIR-style opportunity cost even without a hard zero).
- Subscribe failure still means **zero** Merkl eligibility.
- Legacy guide language may confuse LPs / support; ops should follow **campaign params + registry**, not the Passive FAQ alone.

**Design recommendation:** keep `atomic_jit` | `mint_then_burn_staged` | `burn_then_mint_next_window` as **config flags** driven by verified campaign/registry params each deploy. Do **not** hard-code Passive cooldown as the production default solely from the Essential Guide. Prefer verifying current Merkl opportunity params in CI/startup.

---

## What we did **not** fully close

- Exact per-pool `minLiquidity` numeric vs “1 bp of pool liquidity” marketing.
- Whether any off-chain Merkl hook/script still reads legacy `MIN_PASSIVE_LIFETIME` (no such hook in campaign `hooks: []`; low likelihood).
- Merkl’s precise heuristic thresholds for JIT blacklisting.
- Whether Essential Guide will be updated; no dated TELx announcement found that explicitly says “Passive classification retired.”
- Polygon / Ethereum parity (out of Base scope; same Merkl pattern expected per TELxIP but not checked).

---

## Primary sources

| Source | URL | Accessed |
|--------|-----|----------|
| TELx Essential Guide (Passive/Active/JIT) | https://www.telx.network/about/telx-liquidity-mining-essential-guide-for-lps | 2026-11-08 |
| TELx Merkl-managed rewards | https://telcoin.network/telx/about/merkl-managed-rewards/ | 2026-11-08 |
| TELx Liquidity Framework (Base pool IDs) | https://telcoin.network/telx/about/telx-liquidity-framework/ | 2026-11-08 |
| TELxIP: Merkl across TELx pools | https://forum.telcoin.org/t/telxip-implementation-of-merkl-across-telx-pools/850 | 2026-11-08 |
| TELx Merkl POC summary | https://forum.telcoin.org/t/telx-poc-summary-report/849 | 2026-11-08 |
| Merkl API opportunities / campaigns (Base TEL) | `https://api.merkl.xyz/v4/opportunities?chainId=8453…`, `…/v4/campaigns?tokenSymbol=TEL&chainId=8453` | 2026-11-08 |
| Merkl app opportunities | https://app.merkl.xyz/opportunities/10837281193255818234 , `…/16270260351359923751` | 2026-11-08 |
| Merkl schema `UNISWAP_V4_SUBSCRIPTION` (type 170) | `https://api.merkl.xyz/v4/schemas/campaignType/170` | 2026-11-08 |
| Merkl customization / anti-gaming (blacklist, JIT mention in KB search) | https://docs.merkl.xyz/merkl-mechanisms/customization-options ; Merkl KB blacklist article (search hit) | 2026-11-08 |
| Legacy PositionRegistry (Sourcify + eth_call) | `0x3994e3ae3Cf62bD2a3a83dcE73636E954852BB04` | 2026-11-08 |
| Merkl-era PositionRegistry (Sourcify + eth_call) | `0xcebC0b00473Ca00e429eF431826d0A32cdc945E1` | 2026-11-08 |
| TELx contracts README/spec (Merkl owns rewards) | https://github.com/Telcoin-Association/telcoin-laboratories-contracts (telx core / spec) | 2026-11-08 |
