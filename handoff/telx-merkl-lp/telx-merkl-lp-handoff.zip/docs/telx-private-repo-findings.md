# TELx private-repo findings (Base Merkl LP bot)

**Access date:** 2026-11-08  
**Auth:** Cloud Agent `gh` is still Cursor integration (`cursor`), **not** fabcrowd — **no private repos readable** even after a dashboard reconnect (this VM’s App install only lists `fabcrowd/telx_audit`). Inventory: [`../internal/telx-private-repo-inventory.md`](../internal/telx-private-repo-inventory.md).  
**Scope:** Design research only. Related: [`telx-merkl-reward-rules.md`](./telx-merkl-reward-rules.md), [`bot-blueprint.md`](./bot-blueprint.md), [`design-references.md`](./design-references.md).

---

## Verdict

Public Telcoin-Association repos (especially **telx-frontend** + **telcoin-laboratories-contracts**) already hold the bot’s missing addresses, PoolKeys, and subscribe encoding. Private access is still needed to catch anything the Cursor SCM catalog hides; it is **not** required to unblock stack/subscribe design from the facts below.

---

## Repos that mattered

| Repo | Why |
|------|-----|
| [Telcoin-Association/telx-frontend](https://github.com/Telcoin-Association/telx-frontend) | Live Merkl registry/subscriber/pool IDs; mint+subscribe multicall; `pool.json` keys |
| [Telcoin-Association/telcoin-laboratories-contracts](https://github.com/Telcoin-Association/telcoin-laboratories-contracts) | Thin `PositionRegistry` / `TELxSubscriber` source; eligibility; deploy runbook; hook removal |
| [Telcoin-Association/telcoin-application-network-issuance](https://github.com/Telcoin-Association/telcoin-application-network-issuance) | Legacy reward calculator + Merkl campaign report tooling |
| [fabcrowd/telx_audit](https://github.com/fabcrowd/telx_audit) + issuance fork | Older native-era calculators; prefer TA upstream |
| [fabcrowd/lpsubgraph](https://github.com/fabcrowd/lpsubgraph) | Legacy Base ABIs / Passive-JIT subgraph (do not treat as Merkl truth) |

Low/empty: most Telx-lab mirrors, `fabcrowd/subgraph2` (empty), TN/marketing forks.

---

## New facts vs prior public research

### Confirmed / filled gaps (blueprint placeholders)

| Item | Value | Path |
|------|-------|------|
| Merkl PositionRegistry (Base/ETH/Poly) | `0xcebC0b00473Ca00e429eF431826d0A32cdc945E1` | `telx-frontend/src/lib/contracts.ts` |
| Merkl TELxSubscriber (same on those chains) | `0x19EDFa380ead0Bb26010Ca3d1C7AbC7213938c86` | same |
| Merkl Distributor | `0x3Ef3D8bA38EBe18DB133cEc108f4D14CE00Dd9Ae` | `src/merkl/merklConstants.ts` |
| Base Merkl ETH/TEL poolId | `0x272e0968e2fb347236c6060cc9395f13591968f3f83056c600c755066dd214a6` | contracts.ts + pool.json |
| Base Merkl eUSD/TEL poolId | `0x1266df876a41a4f4250dbfa9887e70f20a40a3ccd802c8d75b51b7fd4eb36982` | same |
| Merkl PoolKey shape | fee **3000**, spacing **60**, **hooks = 0**, currency1 = **TEL v3** `0x7E13…0731` | `src/data/pool.json` |
| Subscribe call | `PositionManager.subscribe(tokenId, MERKL_TELX_SUBSCRIBER, 0x)` | `src/lib/v4/positionManager.ts` |
| Atomic mint+subscribe | `encodeMintAndSubscribe` / PosM `multicall` | same |

Legacy hooked Base ETH/TEL (`poolId 0x727b…`, hook `0x23aB…`, registry `0x3994…`) is **archived** in frontend pool list — not the Merkl target.

### Architecture deltas (strengthen reward-rules.md)

1. **Hook deleted (2026-05).** Labs `INVARIANTS.md` / core README: `TELxIncentiveHook` removed; pools are vanilla v4; Merkl owns reward math off-chain.  
2. **Three registry generations:** (a) legacy Passive/JIT `0x3994…`, (b) **live Merkl** `0xcebC…` (frontend), (c) predicted CREATE3 thin registry `0x00637…` for the TEL-v3 catalog — labs still mark (c) “not yet deployed”; `deployments/base.json` is `{}`. Do **not** wire the bot to `0x00637…` until confirmed.  
3. **Subscribe eligibility (thin registry source):** allowlist + absolute `minLiquidity` + `inRangeRequired` (default on). **Not** “1 bp of pool liquidity.”  
4. **`notifyModifyLiquidity` is a no-op.** Rebalance does not auto-unsubscribe; Essential Guide’s “modify under 1 bp → unsubscribed” is **legacy-path stale**. Still: Merkl scores in-range subscribed liquidity; out-of-range mint/subscribe reverts (`OutOfRange`).  
5. **Recovery:** permissionless `pruneSubscription` / `resubscribe` after drain+refill (v4 refuses a second subscribe).  
6. **Essential Guide in-repo** (`content/about/TELx-liquidity-mining-essential-guide-for-lps.md` and fabcrowd subgraph docs) still documents Passive-only / 43_200 blocks → same stale claim already flagged in reward-rules.

### Reward math

- Live path: Merkl campaign params (fees/token0/token1) — unchanged from reward-rules research.  
- Native calculator still useful as **historical** fee-share mental model (`TELxRewardsCalculator.ts` → Base registry `0x3994…`, pool `0x727b…`, period amounts ~64.8M TEL units/week in 2-dec TEL). Do not use its Passive weights for Merkl ops policy.

---

## Bot design implications (short)

1. Target **Merkl** poolIds + **TEL v3** + **hooks=0**; subscribe via **`0x19ED…`**.  
2. Prefer **mint+subscribe multicall** (frontend pattern); keep range in-range at subscribe.  
3. Treat rebalance atomicity as **Merkl anti-gaming / TIR** policy, not TELx Passive/JIT zeroing.  
4. Copy ABIs/selectors from labs `IPositionRegistry.sol` + frontend PosM helpers — not from lpsubgraph legacy ABIs alone.  
5. After fabcrowd GitHub connect: re-scan for private deploy notes explaining why live Merkl addresses ≠ predicted CREATE3 salts.

---

## Blocker (re-checked after “should be connected”)

Dashboard connect did **not** change this agent’s token. Still: **0 private repos**. Fix one of:

1. **GitHub → Settings → Applications → Cursor → Configure** → Repository access = **All repositories** (or every private TELx repo), signed in as fabcrowd; org privates also need org-admin App grant.  
2. **Best for this running agent:** add secret **`GITHUB_TOKEN`** (PAT with repo read), reply here — agent will re-auth `gh` and re-scan.  
3. Or start a **new** Cloud Agent after App grants are widened (old VMs often keep the old install token).
