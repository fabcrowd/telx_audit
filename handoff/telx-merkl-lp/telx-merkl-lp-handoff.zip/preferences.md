# Preferences

- Optimize the LP strategy for TEL accumulated, not USD value: the user wants to hold TEL and acquire more of it; USD is only a secondary exposure check. (added 2026-11-08)
- No paid RPC: designs must fit free-tier or public Base endpoints. (added 2026-11-08)
- Design and research only for now; no production trading code, no live mainnet deployment, no secrets in docs. (added 2026-11-08)
