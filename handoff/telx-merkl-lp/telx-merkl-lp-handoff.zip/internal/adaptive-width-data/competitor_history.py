"""Per-competitor behaviour from 30 days of ModifyLiquidity history (design doc §1).

Outputs ``competitor-profiles.json`` and ``competitor-profiles.md``: per owner — positions minted,
widths, lifetimes, re-centre cadence, where spot sat inside the band at mint, USD deployed,
classification; plus the current competitor set with concentration around spot and the
time-varying L_others(spot) series.
"""
from __future__ import annotations

import json
import statistics
from collections import defaultdict
from typing import Any

import numpy as np

import telx_adaptive as T


def tick_at(path: list[tuple[float, int, float]], ts: float) -> int:
    """Tick in force at ``ts`` (last swap before)."""
    lo, hi = 0, len(path) - 1
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if path[mid][0] <= ts:
            lo = mid
        else:
            hi = mid - 1
    return path[lo][1]


def main() -> None:
    """Build profiles."""
    h = T.build_history()
    spot = h.spot_end
    by_owner: dict[str, dict[str, Any]] = defaultdict(lambda: {"tokenIds": set(), "mints": [], "burns": [], "increases": 0, "decreases": 0})
    life_open: dict[int, tuple[float, int, int, float]] = {}
    for e in h.events:
        o = by_owner[e.owner]
        o["tokenIds"].add(e.token_id)
        k = (e.tl, e.tu, e.token_id)
        tk = tick_at(h.tick_path, e.ts)
        if e.delta > 0:
            a0, a1 = T.amounts(e.delta, e.tl, e.tu, tk)
            rec = {"ts": e.ts, "tokenId": e.token_id, "tl": e.tl, "tu": e.tu, "width": e.tu - e.tl,
                   "usd": T.usd(a0, a1, tk), "spot_offset_frac": (tk - e.tl) / (e.tu - e.tl),
                   "in_range": e.tl <= tk < e.tu, "eusd_frac": T.usd(a0, 0, tk) / max(1e-9, T.usd(a0, a1, tk))}
            if e.token_id not in life_open and k not in h.initial:
                o["mints"].append(rec)
                life_open[e.token_id] = (e.ts, e.tl, e.tu, float(e.delta))
            else:
                o["increases"] += 1
        else:
            if e.token_id in life_open:
                t0, tl, tu, L0 = life_open.pop(e.token_id)
                o["burns"].append({"ts": e.ts, "tokenId": e.token_id, "lifetime_h": (e.ts - t0) / 3600,
                                   "exit_in_range": tl <= tk < tu})
            else:
                o["decreases"] += 1

    cur = h.competitor_map(h.t_end)
    cur_comps = [T.Competitor(k[0], k[1], v, h.owners.get(k[2], "unknown"), k[2]) for k, v in cur.items()]
    profiles = []
    for owner, o in by_owner.items():
        mints = sorted(o["mints"], key=lambda m: m["ts"])
        widths = [m["width"] for m in mints]
        gaps = [(b["ts"] - a["ts"]) / 3600 for a, b in zip(mints, mints[1:])]
        lifetimes = [b["lifetime_h"] for b in o["burns"]]
        live = [c for c in cur_comps if c.owner == owner]
        live_usd = sum(T.usd(*T.amounts(c.liq, c.tl, c.tu, spot), spot) for c in live)
        live_in_range = [c for c in live if c.tl <= spot < c.tu]
        cls = sorted({T.classify(c, spot, T.usd(*T.amounts(c.liq, c.tl, c.tu, spot), spot)) for c in live})
        profiles.append({
            "owner": owner, "tokenIds_touched": len(o["tokenIds"]), "mints_30d": len(mints), "burns_30d": len(o["burns"]),
            "increases": o["increases"], "decreases": o["decreases"],
            "median_width_ticks": statistics.median(widths) if widths else None,
            "width_range_ticks": [min(widths), max(widths)] if widths else None,
            "median_mint_usd": statistics.median([m["usd"] for m in mints]) if mints else None,
            "median_hours_between_mints": statistics.median(gaps) if gaps else None,
            "median_lifetime_h": statistics.median(lifetimes) if lifetimes else None,
            "mint_eusd_frac_median": statistics.median([m["eusd_frac"] for m in mints]) if mints else None,
            "mint_spot_offset_median": statistics.median([m["spot_offset_frac"] for m in mints]) if mints else None,
            "live_positions": len(live), "live_in_range": len(live_in_range), "live_usd": live_usd,
            "live_L_in_range": sum(c.liq for c in live_in_range), "classes_now": cls,
        })
    profiles.sort(key=lambda p: -(p["live_usd"] + 10 * p["mints_30d"]))

    # current set table
    L_active = sum(c.liq for c in cur_comps if c.tl <= spot < c.tu)
    cur_table = []
    for c in sorted(cur_comps, key=lambda c: -c.liq):
        v = T.usd(*T.amounts(c.liq, c.tl, c.tu, spot), spot)
        cur_table.append({"tokenId": c.token_id, "owner": c.owner, "tl": c.tl, "tu": c.tu, "width": c.tu - c.tl, "L": c.liq,
                          "usd": v, "in_range": c.tl <= spot < c.tu, "L_share_if_active": c.liq / L_active,
                          "class": T.classify(c, spot, v)})

    conc = T.concentration(cur_comps, spot)
    # L_others at spot over time (every 2 h) and whale in-range flag
    series = []
    t = h.tick_path[0][0]
    while t <= h.t_end:
        m = h.competitor_map(t)
        tk = tick_at(h.tick_path, t)
        comps = [T.Competitor(k[0], k[1], v) for k, v in m.items()]
        L = float(T.liquidity_at(np.array([tk]), comps)[0])
        a0, a1 = T.competitor_amounts_at(np.array([tk]), comps)
        series.append({"ts": t, "tick": tk, "L_others_at_spot": L, "inrange_eusd_usd": float(a0[0]) / 1e6 * T.EUSD_USD,
                       "inrange_tel_usd": float(a1[0]) / 1e18 * T.tel_usd(tk),
                       "whale_in_range": any(k[:2] == T.WHALE_KEY and k0 <= tk < k1 for (k0, k1, _), _ in m.items() for k in [(k0, k1)])})
        t += 2 * 3600
    out = {"spot": spot, "t_end": h.t_end, "L_active_competitors": L_active, "concentration": conc,
           "profiles": profiles, "current": cur_table, "series_2h": series}
    json.dump(out, open("competitor-profiles.json", "w"), indent=1, default=str)

    lines = ["| owner | ids | mints/30d | burns | med width (t) | med mint $ | med h between mints | med lifetime h | mint eUSD frac | live $ | live in-range L share | class |", "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for p in profiles:
        if p["mints_30d"] == 0 and p["live_usd"] < 1:
            continue
        f = lambda x, fmt: (fmt % x) if isinstance(x, (int, float)) else "—"
        lines.append(f"| `{p['owner'][:10]}` | {p['tokenIds_touched']} | {p['mints_30d']} | {p['burns_30d']} | {f(p['median_width_ticks'], '%.0f')} | {f(p['median_mint_usd'], '%.0f')} | {f(p['median_hours_between_mints'], '%.1f')} | {f(p['median_lifetime_h'], '%.1f')} | {f(p['mint_eusd_frac_median'], '%.2f')} | {p['live_usd']:.0f} | {p['live_L_in_range'] / L_active * 100:.1f}% | {', '.join(p['classes_now']) or '—'} |")
    lines += ["", f"L_others at spot (competitors only, tick {spot}): {L_active:.3e}", "", "| k (ticks) | min L_others within ±k | mean | max |", "|---|---|---|---|"]
    for k in (60, 180, 300, 600, 1200, 2220):
        lines.append(f"| {k} | {conc[f'min_within_{k}']:.2e} | {conc[f'mean_within_{k}']:.2e} | {conc[f'max_within_{k}']:.2e} |")
    open("competitor-profiles.md", "w").write("\n".join(lines) + "\n")
    print("\n".join(lines))
    print("whale in range fraction (2h grid):", np.mean([s["whale_in_range"] for s in series]))


if __name__ == "__main__":
    main()
