"""§2 evidence: TEL objective vs core width under several competitor sets and σ regimes; tight-entrant response; compounding gain.

Outputs objective-curves.json and objective-curves.md.
"""
from __future__ import annotations

import json
from typing import Any

import numpy as np

import telx_adaptive as T
import tel_objective as O


def main() -> None:
    """Sweep widths × scenarios × σ and the race-response table."""
    h = T.build_history()
    spot = h.spot_end
    cur = h.competitor_map(h.t_end)
    comps = [T.Competitor(k[0], k[1], v, h.owners.get(k[2], "?"), k[2]) for k, v in cur.items()]
    inc7 = T.hourly_increments(h.tick_path, h.t_end - 7 * 86400, h.t_end)
    inc30 = T.hourly_increments(h.tick_path, h.tick_path[0][0], h.t_end)
    sig7, sig30 = float(inc7.std()), float(inc30.std())
    cfg = O.SolverCfg(paths=256, horizon_h=72)

    def tight(usd: float, half: int) -> T.Competitor:
        c = T.snap_down(spot)
        tl, tu = c - half, c + 60 + half
        return T.Competitor(tl, tu, usd / T.usd(*T.amounts(1.0, tl, tu, spot), spot), f"synthetic ${usd:.0f} ±{half}", -1)

    whale_in = T.Competitor(T.snap_down(spot) - 2790, T.snap_down(spot) + 60 + 2790, 1.853e18, "whale in range", -2)
    no_e77d = [c for c in comps if not c.owner.startswith("0xe77d")]
    scenarios = {
        "today (L_o 8.7e17)": comps,
        "today + $5k tight bot ±240": comps + [tight(5000, 240)],
        "today + whale in range (+1.85e18)": comps + [whale_in],
        "today − 0xe77D (mid bot leaves)": no_e77d,
        "October regime: + $1.5k ±120 ladder bot (L 3e18)": comps + [T.Competitor(T.snap_down(spot) - 120, T.snap_down(spot) + 180, 3.0e18, "0xe70e-like", -3)],
    }
    out: dict[str, Any] = {"spot": spot, "sigma_h_7d": sig7, "sigma_h_30d": sig30, "curves": {}, "race": [], "compound": []}
    md = [f"spot {spot}; σ_h 7d = {sig7:.0f} t, 30d = {sig30:.0f} t; 256 bootstrapped paths × 72 h; $2k = {2000 / T.tel_usd(spot):,.0f} TEL-equiv; 50/50 core/anchor(±2220)", ""]
    for sname, cs in scenarios.items():
        for label, sig, inc in (("σ7d", sig7, inc7), ("σ30d", sig30, inc30)):
            m = O.Market(spot, cs, sig, inc)
            rows = O.width_curve(m, cfg)
            out["curves"][f"{sname}|{label}"] = rows
            best = max(rows, key=lambda r: r["total_ex_hodl_tel_wk"])
            md.append(f"### {sname} — {label} ({sig:.0f} t/√h)")
            md.append("| core ±t | ±% | static core L share | Merkl TEL/wk | fees | IL | costs | HODL-mix | total | **ex-HODL** | core uptime | re-centres/wk | USD net/wk |")
            md.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|")
            for r in rows:
                b = "**" if r is best else ""
                md.append(f"| {b}{r['half']}{b} | {r['pct']:.1f} | {r['static_core_share'] * 100:.0f}% | {r['merkl_tel_wk']:,.0f} | {r['fees_tel_wk']:,.0f} | {r['il_tel_wk']:,.0f} | {r['costs_tel_wk']:,.0f} | {r['hodl_mix_term_tel_wk']:,.0f} | {r['total_tel_wk']:,.0f} | {b}{r['total_ex_hodl_tel_wk']:,.0f}{b} | {r['core_uptime'] * 100:.0f}% | {r['recentres_wk']:.1f} | {r['usd_net_wk_vs_hodl_usd']:.0f} |")
            md.append("")
    # race response: optimal symmetric width and split vs tight-entrant size (σ7d)
    md.append("### Response to a tight entrant (±240 t, tracking) — σ7d")
    md.append("| entrant $ | L_o at spot | best core ±t (sym sweep, 50/50) | ex-HODL TEL/wk at best | ex-HODL at ±600 | full solve: layout | ex-HODL | Merkl TEL/wk |")
    md.append("|---|---|---|---|---|---|---|---|")
    for usd in (0, 1000, 2500, 5000, 10000, 20000):
        cs = comps + ([tight(usd, 240)] if usd else [])
        m = O.Market(spot, cs, sig7, inc7)
        rows = O.width_curve(m, cfg)
        best = max(rows, key=lambda r: r["total_ex_hodl_tel_wk"])
        at600 = next(r for r in rows if r["half"] == 600)
        sol = O.solve(m, cfg, "total_ex_hodl_tel_wk")
        Lo = float(T.liquidity_at(np.array([float(spot)]), cs)[0])
        out["race"].append({"entrant_usd": usd, "L_o": Lo, "best_half": best["half"], "best_obj": best["total_ex_hodl_tel_wk"], "at600": at600["total_ex_hodl_tel_wk"], "solve": sol.best.label(), "solve_eval": sol.best_eval})
        md.append(f"| {usd:,} | {Lo:.2e} | {best['half']} | {best['total_ex_hodl_tel_wk']:,.0f} | {at600['total_ex_hodl_tel_wk']:,.0f} | {sol.best.label()} | {sol.best_eval['total_ex_hodl_tel_wk']:,.0f} | {sol.best_eval['merkl_tel_wk']:,.0f} |")
    md.append("")
    # compounding marginal gain: +ΔV into core vs anchor at today's set
    md.append("### Marginal value of compounding ΔV TEL into core vs anchor (today, σ7d, fixed ±600/±2220)")
    md.append("| ΔV (TEL) | ΔV $ | Δ ex-HODL TEL/wk, into core | into anchor | Δ Merkl TEL/wk core | anchor |")
    md.append("|---|---|---|---|---|---|")
    m = O.Market(spot, comps, sig7, inc7)
    base = O.Evaluator(m, cfg, 2000.0).evaluate(T.sym(600))
    for dv_usd in (10, 25, 50, 100):
        tot = 2000 + dv_usd
        wc = (1000 + dv_usd) / tot
        core_more = O.Evaluator(m, cfg, tot).evaluate(T.Layout(T.Bracket(600, 600, wc), T.Bracket(2220, 2220, 1 - wc)))
        anc_more = O.Evaluator(m, cfg, tot).evaluate(T.Layout(T.Bracket(600, 600, 1 - wc), T.Bracket(2220, 2220, wc)))
        dv_tel = dv_usd / T.tel_usd(spot)
        out["compound"].append({"dv_usd": dv_usd, "dv_tel": dv_tel, "core": core_more, "anchor": anc_more, "base": base})
        md.append(f"| {dv_tel:,.0f} | {dv_usd} | {core_more['total_ex_hodl_tel_wk'] - base['total_ex_hodl_tel_wk']:,.0f} | {anc_more['total_ex_hodl_tel_wk'] - base['total_ex_hodl_tel_wk']:,.0f} | {core_more['merkl_tel_wk'] - base['merkl_tel_wk']:,.0f} | {anc_more['merkl_tel_wk'] - base['merkl_tel_wk']:,.0f} |")
    json.dump(out, open("objective-curves.json", "w"), indent=1, default=float)
    open("objective-curves.md", "w").write("\n".join(md) + "\n")
    print("\n".join(md))


if __name__ == "__main__":
    main()
