"""§2.4/§4 evidence: core skew (TEL side vs eUSD side), anchor shape, split and the race response at the 30-day σ.

Outputs skew-and-levers.md / .json.  Uses the same evaluator as the controller (256 paths × 72 h).
"""
from __future__ import annotations

import json

import numpy as np

import telx_adaptive as T
import tel_objective as O


def main() -> None:
    """Run the lever sweeps."""
    h = T.build_history()
    spot = h.spot_end
    cur = h.competitor_map(h.t_end)
    comps = [T.Competitor(k[0], k[1], v, h.owners.get(k[2], "?"), k[2]) for k, v in cur.items()]
    inc7 = T.hourly_increments(h.tick_path, h.t_end - 7 * 86400, h.t_end)
    inc30 = T.hourly_increments(h.tick_path, h.tick_path[0][0], h.t_end)
    sig7, sig30 = float(inc7.std()), float(inc30.std())
    cfg = O.SolverCfg(paths=256, horizon_h=72)
    out: dict = {}
    md: list[str] = []
    a0, a1 = T.competitor_amounts_at(np.array([float(spot)]), comps)
    md.append(f"In-range competitor holdings today: eUSD ${a0[0] / 1e6 * T.EUSD_USD:,.0f}, TEL ${a1[0] / 1e18 * T.tel_usd(spot):,.0f} → TEL is the scarcer in-range token (25% axis pays {a0[0] / 1e6 * T.EUSD_USD / (a1[0] / 1e18 * T.tel_usd(spot)):.2f}× more per $ of TEL than of eUSD).")
    md.append("")
    for label, sig, inc in (("σ30d", sig30, inc30), ("σ7d", sig7, inc7)):
        m = O.Market(spot, comps, sig, inc)
        ev = O.Evaluator(m, cfg)
        md.append(f"### Core skew at total width 1200 t (= ±600 equivalent), 50/50, anchor ±2220 — {label} ({sig:.0f} t/√h)")
        md.append("| core TEL-side / eUSD-side (t) | price range vs spot | Merkl TEL/wk | TEL-axis share | eUSD-axis share | L-axis share | IL | HODL-mix (exposure) | ex-HODL | total | eUSD frac of book | re-centres/wk |")
        md.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
        rows = []
        for ts in (240, 360, 480, 600, 720, 840, 960):
            es = 1200 - ts
            lay = T.Layout(T.Bracket(ts, es, 0.5), T.Bracket(2220, 2220, 0.5))
            r = ev.evaluate(lay)
            # token-axis shares at spot (static)
            tl, tu = lay.core.bounds(spot)
            L = T.liquidity_for_w_tel(ev.capital_tel * 0.5, tl, tu, spot)
            u0, u1 = T.amounts(L, tl, tu, spot)
            atl, atu = lay.anchor.bounds(spot)
            La = T.liquidity_for_w_tel(ev.capital_tel * 0.5, atl, atu, spot)
            v0, v1 = T.amounts(La, atl, atu, spot)
            s0 = (u0 + v0) / (u0 + v0 + a0[0]); s1 = (u1 + v1) / (u1 + v1 + a1[0])
            Lo = float(T.liquidity_at(np.array([float(spot)]), comps)[0])
            ls = (L + La) / (L + La + Lo)
            r.update({"tel_side": ts, "eusd_side": es, "s0": s0, "s1": s1, "ls": ls})
            rows.append(r)
            md.append(f"| −{ts}/+{es} | TEL +{(1.0001 ** ts - 1) * 100:.1f}% … −{(1 - 1.0001 ** -es) * 100:.1f}% | {r['merkl_tel_wk']:,.0f} | {s1 * 100:.1f}% | {s0 * 100:.1f}% | {ls * 100:.1f}% | {r['il_tel_wk']:,.0f} | {r['hodl_mix_term_tel_wk']:,.0f} | **{r['total_ex_hodl_tel_wk']:,.0f}** | {r['total_tel_wk']:,.0f} | {r['eusd_fraction_tw'] * 100:.0f}% | {r['recentres_wk']:.1f} |")
        out[f"skew|{label}"] = rows
        md.append("")
        md.append(f"### Anchor shape and split, core ±600 — {label}")
        md.append("| anchor TEL-side / eUSD-side | split core/anchor | Merkl TEL/wk | IL | HODL-mix | ex-HODL | total | eUSD frac | anchor re-centres/wk (total) |")
        md.append("|---|---|---|---|---|---|---|---|---|")
        rows = []
        for (ats, aes) in ((2220, 2220), (3000, 1440), (3600, 840), (1440, 3000)):
            for wc in (0.15, 0.3, 0.5, 0.7):
                lay = T.Layout(T.Bracket(600, 600, wc), T.Bracket(ats, aes, 1 - wc))
                r = ev.evaluate(lay); r.update({"anchor": (ats, aes), "wc": wc}); rows.append(r)
                md.append(f"| −{ats}/+{aes} | {wc:.0%}/{1 - wc:.0%} | {r['merkl_tel_wk']:,.0f} | {r['il_tel_wk']:,.0f} | {r['hodl_mix_term_tel_wk']:,.0f} | **{r['total_ex_hodl_tel_wk']:,.0f}** | {r['total_tel_wk']:,.0f} | {r['eusd_fraction_tw'] * 100:.0f}% | {r['recentres_wk']:.1f} |")
        out[f"anchor|{label}"] = rows
        md.append("")
    # race response at σ30d
    def tight(usd: float, half: int) -> T.Competitor:
        c = T.snap_down(spot); tl, tu = c - half, c + 60 + half
        return T.Competitor(tl, tu, usd / T.usd(*T.amounts(1.0, tl, tu, spot), spot), "synthetic", -1)
    md.append(f"### Response to a tight entrant (±240 t tracking) — σ30d ({sig30:.0f} t/√h)")
    md.append("| entrant $ | L_o at spot | ex-HODL at ±600 50/50 | best sym width (50/50) → ex-HODL | match (±240, 50/50) → ex-HODL | full solve → layout | ex-HODL | Merkl TEL/wk |")
    md.append("|---|---|---|---|---|---|---|---|")
    race = []
    for usd in (0, 1000, 2500, 5000, 10000, 20000):
        cs = comps + ([tight(usd, 240)] if usd else [])
        m = O.Market(spot, cs, sig30, inc30)
        rows = O.width_curve(m, cfg)
        best = max(rows, key=lambda r: r["total_ex_hodl_tel_wk"])
        at600 = next(r for r in rows if r["half"] == 600); at240 = next(r for r in rows if r["half"] == 240)
        sol = O.solve(m, cfg, "total_ex_hodl_tel_wk")
        Lo = float(T.liquidity_at(np.array([float(spot)]), cs)[0])
        race.append({"usd": usd, "Lo": Lo, "best": best, "at600": at600, "at240": at240, "solve": sol.best.label(), "solve_eval": sol.best_eval})
        md.append(f"| {usd:,} | {Lo:.2e} | {at600['total_ex_hodl_tel_wk']:,.0f} | ±{best['half']} → {best['total_ex_hodl_tel_wk']:,.0f} | {at240['total_ex_hodl_tel_wk']:,.0f} | {sol.best.label()} | {sol.best_eval['total_ex_hodl_tel_wk']:,.0f} | {sol.best_eval['merkl_tel_wk']:,.0f} |")
    out["race30"] = race
    md.append("")
    # compounding marginal at σ30d
    md.append(f"### Marginal value of compounding ΔV into core vs anchor (today, σ30d, ±600/±2220 50/50)")
    md.append("| ΔV $ | ΔV TEL | Δ ex-HODL TEL/wk core | anchor | Δ Merkl TEL/wk core | anchor | weekly return on ΔV (core, ex-HODL) |")
    md.append("|---|---|---|---|---|---|---|")
    m = O.Market(spot, comps, sig30, inc30)
    base = O.Evaluator(m, cfg, 2000.0).evaluate(T.sym(600))
    comp = []
    for dv in (10, 25, 50, 100, 200):
        tot = 2000 + dv; wc = (1000 + dv) / tot
        rc = O.Evaluator(m, cfg, tot).evaluate(T.Layout(T.Bracket(600, 600, wc), T.Bracket(2220, 2220, 1 - wc)))
        ra = O.Evaluator(m, cfg, tot).evaluate(T.Layout(T.Bracket(600, 600, 1 - wc), T.Bracket(2220, 2220, wc)))
        dv_tel = dv / T.tel_usd(spot)
        comp.append({"dv": dv, "core": rc, "anchor": ra})
        md.append(f"| {dv} | {dv_tel:,.0f} | {rc['total_ex_hodl_tel_wk'] - base['total_ex_hodl_tel_wk']:,.0f} | {ra['total_ex_hodl_tel_wk'] - base['total_ex_hodl_tel_wk']:,.0f} | {rc['merkl_tel_wk'] - base['merkl_tel_wk']:,.0f} | {ra['merkl_tel_wk'] - base['merkl_tel_wk']:,.0f} | {(rc['total_ex_hodl_tel_wk'] - base['total_ex_hodl_tel_wk']) / dv_tel * 100:.1f}% |")
    out["compound30"] = comp
    json.dump(out, open("skew-and-levers.json", "w"), indent=1, default=float)
    open("skew-and-levers.md", "w").write("\n".join(md) + "\n")
    print("\n".join(md))


if __name__ == "__main__":
    main()
