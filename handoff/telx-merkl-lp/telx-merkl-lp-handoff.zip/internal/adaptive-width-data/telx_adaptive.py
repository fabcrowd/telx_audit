"""Shared library for the adaptive-width controller study (eUSD/TEL, Uniswap v4, Base).

Design research only: no keys, no transactions. Reuses ``internal/edge-data`` inputs
(``logs-30d.jsonl``, ``state.json``, ``block-timestamps.json``) and the owner map built in
``owner-map.json``.

Conventions (match measure-rebalance-mechanics.md D1): currency0 = eUSD (6 dec), currency1 = TEL
(18 dec); raw price 1.0001^tick = TEL_raw / eUSD_raw; tick UP = TEL CHEAPER.  Ticks *below* spot
are the TEL side of a range (the range holds TEL there and sells it as TEL rallies); ticks *above*
spot are the eUSD side (the range holds eUSD there and buys TEL as TEL falls).

Numeraire: ``W_TEL`` = TEL tokens + eUSD tokens valued in TEL at the current pool price.  The
benchmark is holding TEL (``W_TEL`` constant), so eUSD held is a short-TEL exposure: it gains TEL
when TEL falls and loses TEL when TEL rallies.
"""
from __future__ import annotations

import bisect
import json
import math
import os
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
EDGE = os.path.join(HERE, "..", "edge-data")

TICK_SPACING = 60
MIN_TICK, MAX_TICK = -887220, 887220
LN = math.log(1.0001)
WEEK_S = 7 * 86400
HOUR_S = 3600
WEEKLY_TEL = 500_000.0
EUSD_USD = 0.9935
GAS_USD_PER_BUNDLE = 0.03
SWAP_COST_FRAC = 0.006       # 0.3% fee + ~0.3% impact on an external venue (edge-strategy §3)
LP_FEE = 0.003
WHALE_KEY = (336060, 341640)  # 0xd0c5… $16.6k all-TEL wall (edge-strategy §2)


# ----------------------------------------------------------------------------- tick / amount math
def sqrt_at(tick: float) -> float:
    """sqrt(1.0001^tick)."""
    return 1.0001 ** (tick / 2)


def tel_per_eusd(tick: float) -> float:
    """Human TEL per eUSD at a tick (raw price × 1e6/1e18)."""
    return 1.0001 ** tick * 1e-12


def tel_usd(tick: float) -> float:
    """USD price of TEL implied by the pool tick (eUSD at EUSD_USD)."""
    return EUSD_USD / tel_per_eusd(tick)


def amounts(liq: float, tl: int, tu: int, tick: float) -> tuple[float, float]:
    """Raw (eUSD, TEL) amounts held by liquidity ``liq`` over [tl, tu) at ``tick``."""
    a, b = sqrt_at(tl), sqrt_at(tu)
    if tick < tl:
        return liq * (1 / a - 1 / b), 0.0
    if tick >= tu:
        return 0.0, liq * (b - a)
    p = sqrt_at(tick)
    return liq * (1 / p - 1 / b), liq * (p - a)


def amounts_vec(liq: float, tl: int, tu: int, ticks: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Vectorised :func:`amounts` over an array of ticks."""
    a, b = sqrt_at(tl), sqrt_at(tu)
    p = 1.0001 ** (ticks / 2)
    a0 = np.where(ticks < tl, liq * (1 / a - 1 / b), np.where(ticks >= tu, 0.0, liq * (1 / p - 1 / b)))
    a1 = np.where(ticks < tl, 0.0, np.where(ticks >= tu, liq * (b - a), liq * (p - a)))
    return a0, a1


def w_tel(a0: float, a1: float, tick: float) -> float:
    """TEL-equivalent wealth of raw amounts at ``tick`` (eUSD converted at the pool price)."""
    return a1 / 1e18 + a0 / 1e6 * tel_per_eusd(tick)


def usd(a0: float, a1: float, tick: float) -> float:
    """USD value of raw amounts at ``tick``."""
    return a0 / 1e6 * EUSD_USD + a1 / 1e18 * tel_usd(tick)


def snap_down(t: float, s: int = TICK_SPACING) -> int:
    """Snap down to tick spacing."""
    return int(math.floor(t / s) * s)


def liquidity_for_w_tel(target_w_tel: float, tl: int, tu: int, tick: float) -> float:
    """Liquidity such that the position's TEL-equivalent value at ``tick`` equals ``target_w_tel``."""
    a0, a1 = amounts(1.0, tl, tu, tick)
    v = w_tel(a0, a1, tick)
    return target_w_tel / v if v > 0 else 0.0


# ----------------------------------------------------------------------------- data loading
def load_logs() -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Load the 30-day Swap/ModifyLiquidity log (sorted)."""
    meta: dict[str, Any] = {}
    rows: list[dict[str, Any]] = []
    for line in open(os.path.join(EDGE, "logs-30d.jsonl")):
        r = json.loads(line)
        if r.get("kind") == "meta":
            meta = r
        else:
            rows.append(r)
    rows.sort(key=lambda r: (r["block"], r["logIndex"]))
    return meta, rows


def load_state() -> dict[str, Any]:
    """Load the on-chain state snapshot (block 54,912,240)."""
    return json.load(open(os.path.join(EDGE, "state.json")))


def load_owner_map() -> dict[int, str]:
    """tokenId → owner (lower-case) from leaderboards, state and RPC resolution."""
    m = json.load(open(os.path.join(HERE, "owner-map.json")))
    out = {int(k): v.lower() for k, v in m["leaderboard_or_state"].items()}
    for k, v in m["resolved"].items():
        if v.get("owner"):
            out[int(k)] = v["owner"].lower()
    return out


class BlockClock:
    """Block → timestamp interpolation over the 52 real anchors in block-timestamps.json."""

    def __init__(self) -> None:
        ts = {int(k): v for k, v in json.load(open(os.path.join(EDGE, "block-timestamps.json"))).items()}
        self.xs = sorted(ts)
        self.ys = [ts[x] for x in self.xs]

    def ts(self, block: int) -> float:
        """Interpolated unix timestamp of ``block``."""
        if block <= self.xs[0]:
            return self.ys[0]
        if block >= self.xs[-1]:
            return self.ys[-1] + (block - self.xs[-1]) * 0.2
        i = bisect.bisect_right(self.xs, block)
        b0, b1 = self.xs[i - 1], self.xs[i]
        return self.ys[i - 1] + (self.ys[i] - self.ys[i - 1]) * (block - b0) / (b1 - b0)


# ----------------------------------------------------------------------------- position history
@dataclass
class PosEvent:
    """One ModifyLiquidity event attributed to an owner."""
    ts: float
    block: int
    token_id: int
    tl: int
    tu: int
    delta: int
    owner: str


@dataclass
class History:
    """Reconstructed pool history: swap tick path and competitor liquidity over time."""
    tick_path: list[tuple[float, int, float]]            # (ts, tick, volume_usd)
    events: list[PosEvent]
    initial: dict[tuple[int, int, int], float]          # (tl, tu, tokenId) → L at window start
    owners: dict[int, str]
    t_end: float
    spot_end: int

    def competitor_map(self, ts: float) -> dict[tuple[int, int, int], float]:
        """Liquidity per position key at time ``ts`` (all positions; our bot is not in the data)."""
        pos = dict(self.initial)
        for e in self.events:
            if e.ts > ts:
                break
            k = (e.tl, e.tu, e.token_id)
            pos[k] = max(0.0, pos.get(k, 0.0) + e.delta)
        return {k: v for k, v in pos.items() if v > 0}


def build_history() -> History:
    """Reconstruct positions over the 30-day window from logs + current state (analyze.py method)."""
    meta, rows = load_logs()
    state = load_state()
    owners = load_owner_map()
    clock = BlockClock()
    net: dict[tuple[int, int, int], int] = {}
    events: list[PosEvent] = []
    path: list[tuple[float, int, float]] = []
    for r in rows:
        if r["kind"] == "modify":
            k = (r["tickLower"], r["tickUpper"], int(r["salt"], 16))
            net[k] = net.get(k, 0) + int(r["liquidityDelta"])
            events.append(PosEvent(clock.ts(r["block"]), r["block"], k[2], k[0], k[1], int(r["liquidityDelta"]),
                                   owners.get(k[2], "unknown")))
        else:
            path.append((clock.ts(r["block"]), int(r["tick"]), abs(int(r["amount0"])) / 1e6 * EUSD_USD))
    cur: dict[tuple[int, int, int], int] = {}
    for p in state["subscribedPositions"]:
        cur[(p["tickLower"], p["tickUpper"], p["tokenId"])] = int(p["liquidity"])
    initial: dict[tuple[int, int, int], float] = {}
    for k in set(net) | set(cur):
        if k in cur:
            init = cur[k] - net.get(k, 0)
        else:
            init = max(0, -net.get(k, 0))
        if init > 0:
            initial[k] = float(init)
    first_ts = clock.ts(meta["start"])
    path = [(first_ts, path[0][1], 0.0)] + path
    return History(path, events, initial, owners, float(state["timestamp"]), int(state["tick"]))


# ----------------------------------------------------------------------------- competitor model
@dataclass
class Competitor:
    """A competitor position as seen by the controller."""
    tl: int
    tu: int
    liq: float
    owner: str = "?"
    token_id: int = 0


def liquidity_at(ticks: np.ndarray, comps: Iterable[Competitor]) -> np.ndarray:
    """L_others(tick): competitor liquidity active at each tick (vectorised)."""
    out = np.zeros_like(ticks, dtype=float)
    for c in comps:
        out += np.where((ticks >= c.tl) & (ticks < c.tu), c.liq, 0.0)
    return out


def competitor_amounts_at(ticks: np.ndarray, comps: Iterable[Competitor]) -> tuple[np.ndarray, np.ndarray]:
    """In-range competitor (eUSD_raw, TEL_raw) totals at each tick — the 25/25 denominators."""
    a0 = np.zeros_like(ticks, dtype=float)
    a1 = np.zeros_like(ticks, dtype=float)
    for c in comps:
        inr = (ticks >= c.tl) & (ticks < c.tu)
        x0, x1 = amounts_vec(c.liq, c.tl, c.tu, ticks)
        a0 += np.where(inr, x0, 0.0)
        a1 += np.where(inr, x1, 0.0)
    return a0, a1


def classify(c: Competitor, spot: int, usd_value: float) -> str:
    """Width/value classification used by the competitor model (§1 of the design doc)."""
    width = c.tu - c.tl
    in_range = c.tl <= spot < c.tu
    if width >= 400_000:
        return "full-range passive"
    if usd_value < 5 and width <= 300:
        return "dust ladder slot"
    if usd_value >= 10_000 and not in_range:
        return "whale out of range"
    if usd_value >= 10_000:
        return "whale in range"
    if width >= 3000:
        return "wide static"
    if width >= 1000:
        return "mid-width bot"
    return "tight bot"


def concentration(comps: list[Competitor], spot: int, ks: tuple[int, ...] = (60, 180, 300, 600, 1200, 2220)) -> dict[str, float]:
    """Competitor liquidity around spot: min/mean L within ±k ticks, relative to L at spot."""
    at_spot = float(liquidity_at(np.array([spot]), comps)[0])
    out = {"L_at_spot": at_spot}
    for k in ks:
        grid = np.arange(spot - k, spot + k + 1, TICK_SPACING)
        L = liquidity_at(grid, comps)
        out[f"min_within_{k}"] = float(L.min())
        out[f"mean_within_{k}"] = float(L.mean())
        out[f"max_within_{k}"] = float(L.max())
    return out


# ----------------------------------------------------------------------------- volatility
def hourly_increments(path: list[tuple[float, int, float]], t_from: float, t_to: float) -> np.ndarray:
    """Hourly tick changes on a last-value-resampled path between two timestamps."""
    ts = np.array([p[0] for p in path])
    tk = np.array([p[1] for p in path], dtype=float)
    hours = np.arange(t_from, t_to, HOUR_S)
    idx = np.searchsorted(ts, hours, side="right") - 1
    idx = np.clip(idx, 0, len(tk) - 1)
    series = tk[idx]
    return np.diff(series)


def sigma_h(path: list[tuple[float, int, float]], t_now: float, window_s: float = 7 * 86400,
            floor: float = 60.0, cap: float = 600.0) -> float:
    """Realised 1-h tick σ over the trailing window (mechanics §3.2: floor 60 t, cap 600 t)."""
    inc = hourly_increments(path, max(path[0][0], t_now - window_s), t_now)
    if len(inc) < 12:
        return 156.0
    return float(min(cap, max(floor, inc.std())))


# ----------------------------------------------------------------------------- layouts
@dataclass(frozen=True)
class Bracket:
    """Range relative to centre c = snapDown(spot): [c - tel_side, c + 60 + eusd_side); share of capital."""
    tel_side: int      # ticks below spot (holds TEL; sells TEL on rallies)
    eusd_side: int     # ticks above spot (holds eUSD; buys TEL on dips)
    weight: float

    def bounds(self, spot: int) -> tuple[int, int]:
        """Absolute [tl, tu) for a given spot."""
        c = snap_down(spot)
        return c - self.tel_side, c + TICK_SPACING + self.eusd_side


@dataclass(frozen=True)
class Layout:
    """Core + anchor layout (anchor may be None for single-bracket layouts)."""
    core: Bracket
    anchor: Bracket | None = None

    def label(self) -> str:
        """Human label."""
        a = f" + anchor -{self.anchor.tel_side}/+{self.anchor.eusd_side} ({self.anchor.weight:.0%})" if self.anchor else ""
        return f"core -{self.core.tel_side}/+{self.core.eusd_side} ({self.core.weight:.0%}){a}"


def sym(half: int, w_core: float = 0.5, anchor_half: int | None = 2220) -> Layout:
    """Symmetric core ±half (+ symmetric anchor)."""
    core = Bracket(half, half, w_core)
    anc = Bracket(anchor_half, anchor_half, 1 - w_core) if anchor_half else None
    return Layout(core, anc)


FIXED_LAYOUT = sym(600)                                    # edge-strategy §5 / mechanics D11
