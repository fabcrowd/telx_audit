"""30-day event-level replay: fixed layout vs straddle vs adaptive controller, TEL-denominated (design doc §5).

Competitors are the *reconstructed history* (every ModifyLiquidity in the window), not a static
snapshot, plus optional synthetic overlays (a $5k tight bot entering mid-month; the $16.6k whale
re-entering range mid-month).  Merkl TEL accrues continuously at 500k/week × share; fees accrue in
TEL; inventory is tracked in raw token amounts and valued in TEL (W_TEL) and USD at the end.

Usage: python3 backtest.py [scenario ...]   (default: all)  → backtest-results.json, backtest-output.txt
"""
from __future__ import annotations

import json
import math
import sys
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np

import telx_adaptive as T
import tel_objective as O

CAMPAIGN_START = 1793491200.0
ROOT_PERIOD_S = 8 * 3600          # Merkl reward updates ≈ every 8 h (docs: 4–12 h)
ROOT_LAG_S = 3 * 3600             # computation (~2 h) + dispute window (1–2 h) before a root is claimable
CLAIM_GAS_USD = 0.003             # Distributor.claim ≈ 120k gas @ 0.006 gwei
INCREASE_GAS_USD = 0.01           # INCREASE_LIQUIDITY (+ CLOSE×2) ≈ 400k gas
MID_MONTH = 1795478400.0 - 15 * 86400  # placeholder, replaced in main() by window start + 15 d


# ----------------------------------------------------------------------------- competitor overlays
class Overlay:
    """Synthetic competitor added to the historical set from ``t_start``."""

    def __init__(self, kind: str, t_start: float) -> None:
        self.kind, self.t_start = kind, t_start
        self.pos: T.Competitor | None = None

    def positions(self, t: float, tick: int) -> list[T.Competitor]:
        """Overlay positions at (t, tick); tight bot re-centres when spot leaves its band."""
        if t < self.t_start:
            return []
        if self.kind == "tight5k":
            if self.pos is None or not (self.pos.tl <= tick < self.pos.tu):
                c = T.snap_down(tick)
                tl, tu = c - 240, c + 60 + 240
                L = 5000 / T.usd(*T.amounts(1.0, tl, tu, tick), tick)
                self.pos = T.Competitor(tl, tu, L, "synthetic-tight-5k", -1)
            return [self.pos]
        if self.kind == "whale":
            if self.pos is None:
                c = T.snap_down(tick)
                self.pos = T.Competitor(c - 2790, c + 60 + 2790, 1.853e18, "synthetic-whale-in-range", -2)
            return [self.pos]
        return []


# ----------------------------------------------------------------------------- our book
@dataclass
class Slot:
    """One of our brackets."""
    role: str
    tl: int
    tu: int
    liq: float

    def in_range(self, tick: int) -> bool:
        """Spot inside [tl, tu)."""
        return self.tl <= tick < self.tu


@dataclass
class Book:
    """Our positions + wallet leftovers + accounting."""
    slots: list[Slot]
    wallet0: float = 0.0
    wallet1: float = 0.0
    merkl_tel: float = 0.0
    fees_tel: float = 0.0
    costs_tel: float = 0.0
    claimable_tel: float = 0.0        # posted by a Merkl root, not yet claimed
    unposted_tel: float = 0.0         # accrued since the last root cutoff
    compounded_tel: float = 0.0
    recentres: list[float] = field(default_factory=list)
    width_changes: int = 0
    forced_width_changes: int = 0
    compounds: int = 0

    def amounts(self, tick: int) -> tuple[float, float]:
        """Raw totals incl. wallet."""
        a0 = self.wallet0; a1 = self.wallet1
        for s in self.slots:
            x0, x1 = T.amounts(s.liq, s.tl, s.tu, tick)
            a0 += x0; a1 += x1
        return a0, a1


def rebuild_slot(book: Book, slot: Slot, b: T.Bracket, tick: int, extra_tel_raw: float = 0.0) -> float:
    """Re-centre ``slot`` to bracket ``b`` at ``tick`` using its own inventory (+ wallet + extra TEL); swap to the shape's mix.

    Returns the cost in TEL (swap 0.6% of the swapped notional + gas); updates the slot and book in place."""
    a0, a1 = T.amounts(slot.liq, slot.tl, slot.tu, tick)
    a0 += book.wallet0; a1 += book.wallet1 + extra_tel_raw
    book.wallet0 = book.wallet1 = 0.0
    q = T.tel_per_eusd(tick)
    v_tel = a1 / 1e18 + a0 / 1e6 * q
    tl, tu = b.bounds(tick)
    u0, u1 = T.amounts(1.0, tl, tu, tick)
    unit_v = u1 / 1e18 + u0 / 1e6 * q
    L_pre = v_tel / unit_v
    swapped_tel = abs(L_pre * u0 - a0) / 1e6 * q
    cost = swapped_tel * T.SWAP_COST_FRAC + T.GAS_USD_PER_BUNDLE / T.tel_usd(tick)
    slot.tl, slot.tu, slot.liq = tl, tu, max(0.0, v_tel - cost) / unit_v
    book.costs_tel += cost
    return cost


def build_book(lay: T.Layout, tick: int, capital_usd: float, roles: tuple[str, ...] = ("core", "anchor")) -> Book:
    """Fresh book for a layout at ``tick``."""
    cap_tel = capital_usd / T.tel_usd(tick)
    slots = []
    brs = [lay.core] + ([lay.anchor] if lay.anchor else [])
    for role, b in zip(roles, brs):
        tl, tu = b.bounds(tick)
        slots.append(Slot(role, tl, tu, T.liquidity_for_w_tel(cap_tel * b.weight, tl, tu, tick)))
    return Book(slots)


# ----------------------------------------------------------------------------- strategies
class Strategy:
    """Base: fixed core/anchor with the mechanics-doc triggers (60-min dwell core, 300-t anchor margin)."""
    name = "fixed"

    def __init__(self, lay: T.Layout, compound: bool = False) -> None:
        self.lay = lay
        self.compound = compound
        self.oor_since: float | None = None
        self.last_compound_ts = -1e18
        self._sigma: tuple[float, np.ndarray] | None = None
        self._compound_target: Slot | None = None
        self.compound_log: list[dict[str, Any]] = []

    def init(self, tick: int, t: float, capital_usd: float) -> Book:
        """Create the book."""
        self.book = build_book(self.lay, tick, capital_usd)
        return self.book

    def core_shape(self) -> T.Bracket:
        """Bracket the core is rebuilt to at the next re-centre."""
        return self.lay.core

    def on_tick(self, t: float, tick: int, comps: list[T.Competitor]) -> None:
        """Trigger evaluation after a tick update (dwell handled by caller via pending())."""
        core, anchor = self.book.slots[0], self.book.slots[1]
        if core.in_range(tick):
            self.oor_since = None
        elif self.oor_since is None:
            self.oor_since = t
        if (tick - anchor.tl) < 300 or (anchor.tu - 1 - tick) < 300:
            rebuild_slot(self.book, anchor, self.lay.anchor, tick)
            self.book.recentres.append(t)

    def pending_fire(self) -> float | None:
        """Timestamp at which the pending core trigger matures (None if no pending)."""
        return None if self.oor_since is None else self.oor_since + 3600

    def fire(self, t: float, tick: int, comps: list[T.Competitor]) -> None:
        """Core re-centre."""
        core = self.book.slots[0]
        extra = self._compound_now(t, tick, comps, piggyback=True)
        if extra > 0 and self._compound_target is not core:
            self._increase(self._compound_target, tick, extra)
            extra = 0.0
        rebuild_slot(self.book, core, self.core_shape(), tick, extra)
        self.book.recentres.append(t)
        self.oor_since = None

    def on_clock(self, t: float, tick: int, comps: list[T.Competitor], sigma_fn: Callable[[], tuple[float, np.ndarray]]) -> None:
        """12-min clock: compounding check (controller adds re-solve)."""
        self._sigma = sigma_fn()
        extra = self._compound_now(t, tick, comps, piggyback=False)
        if extra > 0:
            # INCREASE_LIQUIDITY on the chosen existing slot: keep its range, add the claimed TEL (swap the eUSD leg)
            self._increase(self._compound_target, tick, extra)

    def _increase(self, slot: Slot, tick: int, extra_tel_raw: float) -> None:
        q = T.tel_per_eusd(tick)
        u0, u1 = T.amounts(1.0, slot.tl, slot.tu, tick)
        unit_v = u1 / 1e18 + u0 / 1e6 * q
        v = extra_tel_raw / 1e18
        swapped_tel = (u0 / 1e6 * q) / unit_v * v          # eUSD leg bought with claimed TEL
        cost = swapped_tel * T.SWAP_COST_FRAC + (CLAIM_GAS_USD + INCREASE_GAS_USD) / T.tel_usd(tick)
        slot.liq += max(0.0, v - cost) / unit_v
        self.book.costs_tel += cost
        self.book.compounds += 1

    def _compound_now(self, t: float, tick: int, comps: list[T.Competitor], piggyback: bool) -> float:
        """Claim-and-compound rule → raw TEL to add to the chosen bracket (0 = hold the claimed TEL as TEL).

        Marginal test: evaluate the current layout at capital V and at V+ΔV with ΔV added to the core or the
        anchor (same bootstrapped paths); compound into the better bracket iff its gain over the remaining
        horizon ≥ evMultiple × (claim gas + INCREASE gas + swap of the eUSD leg).  Otherwise claimed TEL is
        simply held (it is already TEL — the objective's unit)."""
        if not self.compound or self.book.claimable_tel <= 0 or getattr(self, "_sigma", None) is None:
            return 0.0
        claim = self.book.claimable_tel
        if claim < 5_000:                                   # dust floor ≈ $7
            return 0.0
        if not piggyback and (t - self.last_compound_ts < 24 * 3600 or t - getattr(self, "_last_compound_check", -1e18) < 3600):
            return 0.0
        self._last_compound_check = t
        core, anchor = self.book.slots[0], self.book.slots[1]
        cap_usd = T.usd(*self.book.amounts(tick), tick)
        dv_usd = claim * T.tel_usd(tick)
        s_h, inc = self._sigma
        m = O.Market(tick, comps, s_h, inc)
        cfg = O.SolverCfg(paths=96, horizon_h=48, seed=11)
        lay = self.lay
        base = O.Evaluator(m, cfg, cap_usd).evaluate(lay)
        wc = lay.core.weight
        tot = cap_usd + dv_usd
        gains = {}
        for target, wcore in (("core", (cap_usd * wc + dv_usd) / tot), ("anchor", cap_usd * wc / tot)):
            lay2 = T.Layout(T.Bracket(lay.core.tel_side, lay.core.eusd_side, wcore), T.Bracket(lay.anchor.tel_side, lay.anchor.eusd_side, 1 - wcore))
            r = O.Evaluator(m, cfg, tot).evaluate(lay2)
            gains[target] = r["total_ex_hodl_tel_wk"] - base["total_ex_hodl_tel_wk"]
        h_rem = min(168.0, max(0.0, (CAMPAIGN_START + 30 * 86400 - t) / 3600))
        best = max(gains, key=gains.get)
        gain = gains[best] / 168 * h_rem
        slot = core if best == "core" else anchor
        u0, u1 = T.amounts(1.0, slot.tl, slot.tu, tick)
        q = T.tel_per_eusd(tick)
        eusd_leg_frac = (u0 / 1e6 * q) / (u1 / 1e18 + u0 / 1e6 * q)
        cost = (CLAIM_GAS_USD + (0 if piggyback else INCREASE_GAS_USD)) / T.tel_usd(tick) + claim * eusd_leg_frac * T.SWAP_COST_FRAC
        self.compound_log.append({"ts": t, "claim_tel": claim, "gain_core_wk": gains["core"], "gain_anchor_wk": gains["anchor"], "cost_tel": cost, "h_rem": h_rem})
        if gain < 3 * cost:
            return 0.0                                       # hold: claimed TEL stays TEL
        self.book.claimable_tel = 0.0
        self.book.compounded_tel += claim
        self.last_compound_ts = t
        self._compound_target = slot
        return claim * 1e18                                 # raw TEL to add


class Straddle(Strategy):
    """Build-plan A/B/C with mechanics-doc triggers: envelope breach 6 min, 6 h cooldown, 5/week cap."""
    name = "straddle"

    def __init__(self, compound: bool = False) -> None:
        super().__init__(T.Layout(T.Bracket(180, 180, 0.5)), compound)
        self.brs = [T.Bracket(180, 180, 0.5), T.Bracket(180, 420, 0.25), T.Bracket(420, 180, 0.25)]  # A, B(−4%..+1.5% price), C

    def init(self, tick: int, t: float, capital_usd: float) -> Book:
        cap_tel = capital_usd / T.tel_usd(tick)
        self.book = Book([Slot(r, *b.bounds(tick), T.liquidity_for_w_tel(cap_tel * b.weight, *b.bounds(tick), tick)) for r, b in zip(("A", "B", "C"), self.brs)])
        return self.book

    def on_tick(self, t: float, tick: int, comps: list[T.Competitor]) -> None:
        lo, hi = min(s.tl for s in self.book.slots), max(s.tu for s in self.book.slots)
        if lo <= tick < hi:
            self.oor_since = None
        elif self.oor_since is None:
            self.oor_since = t

    def pending_fire(self) -> float | None:
        return None if self.oor_since is None else self.oor_since + 360

    def fire(self, t: float, tick: int, comps: list[T.Competitor]) -> None:
        recent = [x for x in self.book.recentres if x > t - T.WEEK_S]
        if len(recent) >= 5 or (self.book.recentres and t - self.book.recentres[-1] < 6 * 3600):
            self.oor_since = None   # capped: stay put until the next breach observation
            return
        a0, a1 = self.book.amounts(tick)
        self.book.wallet0 = self.book.wallet1 = 0.0
        q = T.tel_per_eusd(tick)
        v = a1 / 1e18 + a0 / 1e6 * q
        need0 = 0.0
        new = []
        for r, b in zip(("A", "B", "C"), self.brs):
            tl, tu = b.bounds(tick)
            L = T.liquidity_for_w_tel(v * b.weight, tl, tu, tick)
            need0 += T.amounts(L, tl, tu, tick)[0]
            new.append(Slot(r, tl, tu, L))
        cost = abs(need0 - a0) / 1e6 * q * T.SWAP_COST_FRAC + T.GAS_USD_PER_BUNDLE / T.tel_usd(tick)
        scale = max(0.0, v - cost) / v
        for s in new:
            s.liq *= scale
        self.book.slots = new
        self.book.costs_tel += cost
        self.book.recentres.append(t)
        self.oor_since = None

    def on_clock(self, t: float, tick: int, comps: list[T.Competitor], sigma_fn: Callable[[], tuple[float, np.ndarray]]) -> None:
        return None


class Controller(Strategy):
    """Adaptive width/shape/split controller with hysteresis, rate limits and race guard."""
    name = "controller"

    def __init__(self, compound: bool = False, objective: str = "total_ex_hodl_tel_wk", persist_n: int = 3,
                 ev_multiple: float = 3.0, force_multiple: float = 10.0, resolve_every_s: float = 1800.0,
                 deadband_frac: float = 0.10, deadband_min_tel_wk: float = 3000.0) -> None:
        super().__init__(T.sym(600), compound)
        self.objective = objective
        self.persist_n, self.ev_multiple, self.force_multiple = persist_n, ev_multiple, force_multiple
        self.resolve_every_s = resolve_every_s
        self.deadband_frac, self.deadband_min = deadband_frac, deadband_min_tel_wk
        self.cfg = O.SolverCfg(paths=160, horizon_h=48)
        self.last_solve_ts = -1e18
        self.last_map_sig: Any = None
        self.rec: T.Layout | None = None
        self.rec_count = 0
        self.pending: T.Layout | None = None
        self.pending_gain_h = 0.0
        self.log: list[dict[str, Any]] = []
        self.forced_ts: list[float] = []
        self.n_solves = 0

    def core_shape(self) -> T.Bracket:
        return self.lay.core

    def _switch_cost_tel(self, new: T.Layout, tick: int) -> float:
        """TEL cost of reshaping now: swap of the mix difference (0.6%) + gas."""
        a0, a1 = self.book.amounts(tick)
        q = T.tel_per_eusd(tick)
        v = a1 / 1e18 + a0 / 1e6 * q
        need0 = 0.0
        for b in (new.core, new.anchor):
            tl, tu = b.bounds(tick)
            need0 += T.amounts(T.liquidity_for_w_tel(v * b.weight, tl, tu, tick), tl, tu, tick)[0]
        return abs(need0 - a0) / 1e6 * q * T.SWAP_COST_FRAC + 2 * T.GAS_USD_PER_BUNDLE / T.tel_usd(tick)

    def _same(self, a: T.Layout, b: T.Layout) -> bool:
        """Within one grid step on every lever."""
        return (abs((a.core.tel_side + a.core.eusd_side) - (b.core.tel_side + b.core.eusd_side)) <= 120
                and abs(a.core.tel_side - b.core.tel_side) <= 180 and abs(a.core.weight - b.core.weight) < 0.11
                and a.anchor.tel_side == b.anchor.tel_side)

    def on_clock(self, t: float, tick: int, comps: list[T.Competitor], sigma_fn: Callable[[], tuple[float, np.ndarray]]) -> None:
        sig = (round(sum(c.liq for c in comps if c.tl <= tick < c.tu) / 1e16), len(comps))
        self._sigma = sigma_fn()
        if t - self.last_solve_ts >= self.resolve_every_s or sig != self.last_map_sig:
            s_h, inc = self._sigma
            cap_usd = T.usd(*self.book.amounts(tick), tick)
            m = O.Market(tick, comps, s_h, inc)
            ev = O.Evaluator(m, self.cfg, capital_usd=cap_usd)
            cur_eval = ev.evaluate(self.lay)
            sol = O.solve(m, self.cfg, self.objective, start=self.lay)
            self.n_solves += 1
            self.last_solve_ts, self.last_map_sig = t, sig
            best = sol.best
            if self.rec is not None and self._same(best, self.rec):
                self.rec_count += 1
            else:
                self.rec, self.rec_count = best, 1
            gain_wk = sol.best_eval[self.objective] - cur_eval[self.objective]
            h_eff = min(72.0, 168.0 / max(0.5, cur_eval["recentres_wk"]))
            gain_h = gain_wk / 168 * h_eff
            sw = self._switch_cost_tel(best, tick)
            self.log.append({"ts": t, "tick": tick, "sigma_h": s_h, "L_others_spot": sum(c.liq for c in comps if c.tl <= tick < c.tu),
                             "current": self.lay.label(), "best": best.label(), "gain_tel_h_eff": gain_h, "switch_cost_tel": sw,
                             "cur_obj_wk": cur_eval[self.objective], "best_obj_wk": sol.best_eval[self.objective], "rec_count": self.rec_count})
            deadband_ok = gain_wk >= max(self.deadband_frac * abs(cur_eval[self.objective]), self.deadband_min)
            if not self._same(best, self.lay) and self.rec_count >= self.persist_n and gain_h >= self.ev_multiple * sw and deadband_ok:
                self.pending, self.pending_gain_h = best, gain_h
                # force only if the gain is large and the rate limits allow
                recent_day = [x for x in self.book.recentres if x > t - 86400]
                recent_wk = [x for x in self.book.recentres if x > t - T.WEEK_S]
                cooldown_ok = not self.book.recentres or t - self.book.recentres[-1] >= 7200
                forced_day = [x for x in self.forced_ts if x > t - 86400]
                if gain_h >= self.force_multiple * sw and len(recent_day) < 3 and len(recent_wk) < 12 and cooldown_ok and not forced_day:
                    self.forced_ts.append(t)
                    self._apply(t, tick, comps, forced=True)
            elif self._same(best, self.lay):
                self.pending = None
        super().on_clock(t, tick, comps, sigma_fn)

    def _apply(self, t: float, tick: int, comps: list[T.Competitor], forced: bool) -> None:
        new = self.pending
        assert new is not None
        a0, a1 = self.book.amounts(tick)
        self.book.wallet0 = self.book.wallet1 = 0.0
        q = T.tel_per_eusd(tick)
        extra = self._compound_now(t, tick, comps, piggyback=True)   # whole book is rebuilt: any target is fine
        v = a1 / 1e18 + a0 / 1e6 * q + extra / 1e18
        need0 = 0.0
        slots = []
        for role, b in (("core", new.core), ("anchor", new.anchor)):
            tl, tu = b.bounds(tick)
            L = T.liquidity_for_w_tel(v * b.weight, tl, tu, tick)
            need0 += T.amounts(L, tl, tu, tick)[0]
            slots.append(Slot(role, tl, tu, L))
        cost = abs(need0 - a0) / 1e6 * q * T.SWAP_COST_FRAC + 2 * T.GAS_USD_PER_BUNDLE / T.tel_usd(tick)
        scale = max(0.0, v - cost) / v
        for s in slots:
            s.liq *= scale
        self.book.slots = slots
        self.book.costs_tel += cost
        self.book.recentres.append(t)
        self.book.width_changes += 1
        self.book.forced_width_changes += int(forced)
        self.lay, self.pending = new, None
        self.oor_since = None

    def fire(self, t: float, tick: int, comps: list[T.Competitor]) -> None:
        if self.pending is not None:
            self._apply(t, tick, comps, forced=False)        # width change rides the natural re-centre
        else:
            super().fire(t, tick, comps)


# ----------------------------------------------------------------------------- replay
def replay(strat: Strategy, h: T.History, overlays: list[Overlay], t_start: float, t_end: float, capital_usd: float = 2000.0,
           clock_s: float = 720.0, record_widths: bool = False) -> dict[str, Any]:
    """Event-level replay between t_start and t_end."""
    path = [p for p in h.tick_path if t_start <= p[0] <= t_end]
    before = [p for p in h.tick_path if p[0] < t_start]
    tick = before[-1][1] if before else path[0][1]
    events = [(p[0], "swap", p) for p in path if p[0] > t_start]
    events += [(e.ts, "modify", e) for e in h.events if t_start < e.ts <= t_end]
    clocks = np.arange(t_start + clock_s, t_end, clock_s)
    events += [(float(c), "clock", None) for c in clocks]
    roots = np.arange(CAMPAIGN_START, t_end + ROOT_PERIOD_S, ROOT_PERIOD_S)
    events += [(float(r), "root", None) for r in roots if t_start < r <= t_end]
    events.sort(key=lambda e: (e[0], {"swap": 0, "modify": 1, "root": 2, "clock": 3}[e[1]]))
    events.append((t_end, "end", None))

    comp_map = h.competitor_map(t_start)
    comps = [T.Competitor(k[0], k[1], v, h.owners.get(k[2], "?"), k[2]) for k, v in comp_map.items()]
    def all_comps(t: float, tk: int) -> list[T.Competitor]:
        return comps + [p for o in overlays for p in o.positions(t, tk)]

    book = strat.init(tick, t_start, capital_usd)
    hodl0, hodl1 = book.amounts(tick)
    start_tel = T.w_tel(hodl0, hodl1, tick)
    start_count = hodl1 / 1e18
    acc = {"T": 0.0, "share": 0.0, "l": 0.0, "up": 0.0, "core_up": 0.0, "eusd_frac": 0.0}
    merkl_unposted_cut = CAMPAIGN_START
    widths: list[tuple[float, int, int, float, float]] = []   # (ts, core total width, tel_side, core weight, sigma)

    def sigma_fn() -> tuple[float, np.ndarray]:
        inc = T.hourly_increments(h.tick_path, max(h.tick_path[0][0], t_now - 7 * 86400), t_now)
        return T.sigma_h(h.tick_path, t_now), inc

    def accumulate(dt: float, tk: int, t_at: float) -> None:
        if dt <= 0:
            return
        cs = all_comps(t_at, tk)
        Lo = o0 = o1 = 0.0
        for c in cs:
            if c.tl <= tk < c.tu:
                x0, x1 = T.amounts(c.liq, c.tl, c.tu, tk)
                Lo += c.liq; o0 += x0; o1 += x1
        Lus = u0 = u1 = 0.0
        core_in = False
        for s in book.slots:
            if s.in_range(tk):
                x0, x1 = T.amounts(s.liq, s.tl, s.tu, tk)
                Lus += s.liq; u0 += x0; u1 += x1
                core_in = core_in or s.role in ("core", "A")
        ls = Lus / (Lus + Lo) if Lus + Lo > 0 else 0.0
        s0 = u0 / (u0 + o0) if u0 + o0 > 0 else 0.0
        s1 = u1 / (u1 + o1) if u1 + o1 > 0 else 0.0
        share = 0.5 * ls + 0.25 * s0 + 0.25 * s1
        if t_at + dt > CAMPAIGN_START or True:   # campaign-equivalent budget assumed throughout the 30 d (500k/wk)
            tel = share * T.WEEKLY_TEL / T.WEEK_S * dt
            book.merkl_tel += tel
            book.unposted_tel += tel
        acc["T"] += dt; acc["share"] += dt * share; acc["l"] += dt * ls
        acc["up"] += dt * (Lus > 0); acc["core_up"] += dt * core_in
        a0, a1 = book.amounts(tk)
        tot = T.w_tel(a0, a1, tk)
        acc["eusd_frac"] += dt * (a0 / 1e6 * T.tel_per_eusd(tk) / tot if tot > 0 else 0)
        acc["_ls"] = ls

    t_prev = t_start
    t_now = t_start
    for t_now, kind, payload in events:
        # pending core trigger maturing inside the interval
        pf = strat.pending_fire()
        if pf is not None and t_prev <= pf < t_now:
            accumulate(pf - t_prev, tick, t_prev)
            strat.fire(pf, tick, all_comps(pf, tick))
            t_prev = pf
        accumulate(t_now - t_prev, tick, t_prev)
        t_prev = t_now
        if kind == "swap":
            _, new_tick, vol = payload
            book.fees_tel += T.LP_FEE * vol * acc.get("_ls", 0.0) / T.tel_usd(tick)
            tick = new_tick
            strat.on_tick(t_now, tick, all_comps(t_now, tick))
        elif kind == "modify":
            e = payload
            k = (e.tl, e.tu, e.token_id)
            comp_map[k] = max(0.0, comp_map.get(k, 0.0) + e.delta)
            comps = [T.Competitor(kk[0], kk[1], v, h.owners.get(kk[2], "?"), kk[2]) for kk, v in comp_map.items() if v > 0]
        elif kind == "root":
            # rewards accrued up to (root − lag) become claimable
            book.claimable_tel += book.unposted_tel
            book.unposted_tel = 0.0
        elif kind == "clock":
            strat.on_clock(t_now, tick, all_comps(t_now, tick), sigma_fn)
            if record_widths:
                c = strat.book.slots[0]
                widths.append((t_now, c.tu - c.tl, tick - c.tl, strat.lay.core.weight if hasattr(strat, "lay") and strat.lay.anchor else 1.0, 0.0))
    a0, a1 = book.amounts(tick)
    q = T.tel_per_eusd(tick)
    weeks = acc["T"] / T.WEEK_S
    w_end = T.w_tel(a0, a1, tick)
    w_hodl_mix = T.w_tel(hodl0, hodl1, tick)
    usd_end = T.usd(a0, a1, tick); usd_hodl = T.usd(hodl0, hodl1, tick); usd_start = T.usd(hodl0, hodl1, path[0][1] if not before else before[-1][1])
    merkl_claimed_or_claimable = book.merkl_tel  # all accrued (claimable at campaign end)
    out = {
        "strategy": strat.name, "weeks": weeks,
        "merkl_tel_wk": book.merkl_tel / weeks, "fees_tel_wk": book.fees_tel / weeks,
        "hodl_mix_term_tel_wk": (w_hodl_mix - start_tel) / weeks,
        "il_tel_wk": (w_end - w_hodl_mix + book.costs_tel - book.compounded_tel) / weeks,
        "costs_tel_wk": book.costs_tel / weeks,
        "delta_w_tel_wk": (w_end - start_tel) / weeks,
        "tel_count_delta_wk": (a1 / 1e18 - start_count) / weeks,
        "compounded_tel": book.compounded_tel, "compounds": book.compounds,
        "share_tw": acc["share"] / acc["T"], "l_share_tw": acc["l"] / acc["T"], "uptime": acc["up"] / acc["T"], "core_uptime": acc["core_up"] / acc["T"],
        "eusd_fraction_tw": acc["eusd_frac"] / acc["T"],
        "recentres_wk": len(book.recentres) / weeks, "width_changes": book.width_changes, "forced_width_changes": book.forced_width_changes,
        "usd_end": usd_end, "usd_start": usd_start, "usd_net_wk_vs_hodl": (usd_end - usd_hodl + (book.merkl_tel - book.compounded_tel + book.fees_tel) * T.tel_usd(tick)) / weeks,
        "usd_rewards_wk": book.merkl_tel * T.tel_usd(tick) / weeks,
        "end_tel_usd": T.tel_usd(tick),
    }
    # compounded TEL is already inside w_end (as liquidity); do not double count it in the total
    out["total_tel_wk"] = out["merkl_tel_wk"] - book.compounded_tel / weeks + out["fees_tel_wk"] + out["delta_w_tel_wk"]
    out["total_ex_hodl_tel_wk"] = out["total_tel_wk"] - out["hodl_mix_term_tel_wk"]
    out["compound_log"] = strat.compound_log
    if isinstance(strat, Controller):
        out["n_solves"] = strat.n_solves
        out["controller_log"] = strat.log
    if record_widths:
        out["widths"] = widths
    return out


def expost_optimum(h: T.History, overlays_factory: Callable[[], list[Overlay]], t_start: float, t_end: float,
                   halfs: tuple[int, ...]) -> list[dict[str, Any]]:
    """Per UTC day: best fixed symmetric core half-width by total TEL ex-HODL-mix (fresh book each day)."""
    out = []
    day = math.floor(t_start / 86400) * 86400 + 86400
    while day + 86400 <= t_end:
        best = None
        for hf in halfs:
            r = replay(Strategy(T.sym(hf)), h, overlays_factory(), day, day + 86400, clock_s=3600)
            if best is None or r["total_ex_hodl_tel_wk"] > best[1]:
                best = (hf, r["total_ex_hodl_tel_wk"])
        out.append({"day": day, "best_half": best[0], "best_obj_wk": best[1]})
        day += 86400
    return out


SCENARIOS = {
    "actual": lambda mid: [],
    "tight5k_midmonth": lambda mid: [Overlay("tight5k", mid)],
    "whale_midmonth": lambda mid: [Overlay("whale", mid)],
}


def run_one(args: tuple[str, str, bool]) -> tuple[str, dict[str, Any]]:
    """Worker: one (scenario, strategy, compound) replay."""
    scen, sname, compound = args
    h = T.build_history()
    t_start, t_end = h.tick_path[0][0], h.t_end
    mid = t_start + 15 * 86400
    ov = SCENARIOS[scen](mid)
    if sname == "fixed":
        strat: Strategy = Strategy(T.sym(600), compound)
    elif sname == "straddle":
        strat = Straddle(compound)
    else:
        strat = Controller(compound)
    r = replay(strat, h, ov, t_start, t_end, record_widths=True)
    return f"{scen}|{sname}|{'compound' if compound else 'plain'}", r


def main() -> None:
    """Run the matrix in parallel; write results and a text table."""
    scens = sys.argv[1:] or list(SCENARIOS)
    jobs = [(s, st, c) for s in scens for st in ("fixed", "straddle", "controller") for c in (False, True) if not (st == "straddle" and c)]
    results: dict[str, Any] = {}
    with ProcessPoolExecutor(max_workers=4) as ex:
        for key, r in ex.map(run_one, jobs):
            results[key] = r
            print("done", key, f"total {r['total_tel_wk']:.0f} TEL/wk", flush=True)
    h = T.build_history()
    t_start, t_end = h.tick_path[0][0], h.t_end
    mid = t_start + 15 * 86400
    halfs = (180, 240, 300, 360, 420, 480, 600, 720, 840, 960, 1200, 1500)
    for scen in scens:
        results[f"{scen}|expost"] = expost_optimum(h, lambda: SCENARIOS[scen](mid), t_start, t_end, halfs)
        # fraction of time the controller's core width is within one grid step of the day's optimum
        for key in (f"{scen}|controller|plain", f"{scen}|controller|compound", f"{scen}|fixed|plain"):
            if key not in results:
                continue
            days = {d["day"]: d["best_half"] for d in results[f"{scen}|expost"]}
            hit = tot = 0
            for ts, width, _, _, _ in results[key]["widths"]:
                d = math.floor(ts / 86400) * 86400
                if d in days:
                    bh = days[d]; i = halfs.index(bh)
                    lo = halfs[max(0, i - 1)] * 2; hi = halfs[min(len(halfs) - 1, i + 1)] * 2
                    hit += lo <= width <= hi; tot += 1
            results[key]["frac_within_one_step_of_expost"] = hit / tot if tot else None
    json.dump(results, open("backtest-results.json", "w"), indent=1, default=float)
    lines = [f"{'scenario|strategy|mode':40} {'Merkl TEL/wk':>12} {'fees':>7} {'IL':>8} {'costs':>7} {'HODLmix':>8} {'TOTAL TEL/wk':>12} {'exHODL':>8} {'TELcount Δ/wk':>13} {'USD net/wk':>10} {'eUSD%':>6} {'reb/wk':>6} {'wchg':>5} {'cmp':>4} {'expost':>6}"]
    for k, r in results.items():
        if k.endswith("expost"):
            continue
        f = r.get("frac_within_one_step_of_expost")
        lines.append(f"{k:40} {r['merkl_tel_wk']:12.0f} {r['fees_tel_wk']:7.0f} {r['il_tel_wk']:8.0f} {r['costs_tel_wk']:7.0f} {r['hodl_mix_term_tel_wk']:8.0f} {r['total_tel_wk']:12.0f} {r['total_ex_hodl_tel_wk']:8.0f} {r['tel_count_delta_wk']:13.0f} {r['usd_net_wk_vs_hodl']:10.1f} {r['eusd_fraction_tw']*100:6.1f} {r['recentres_wk']:6.1f} {r['width_changes']:5d} {r['compounds']:4d} {('%.2f' % f) if f is not None else '—':>6}")
    open("backtest-output.txt", "w").write("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
