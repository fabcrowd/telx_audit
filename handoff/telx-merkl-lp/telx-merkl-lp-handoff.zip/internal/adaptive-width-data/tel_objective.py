"""TEL-denominated objective and width solver (design doc §2).

For a candidate layout the expected TEL accumulated per week is estimated by a small common-random-
numbers Monte Carlo over hourly tick paths (bootstrapped from realised hourly tick changes, so fat
tails are kept) against the *current* competitor map L_others(tick):

    E[TEL/wk] = Merkl TEL + fees (in TEL) + E[ΔW_TEL] − re-centre costs (swap + gas, in TEL)

where W_TEL = TEL + eUSD·(TEL per eUSD).  E[ΔW_TEL] is further split into a HODL-mix term (what the
start inventory would be worth in TEL at the end — the price exposure of holding eUSD) and the
concavity loss of the LP position versus that HODL mix (IL in TEL numeraire).

The same engine is used by the controller in the backtest; it is cheap enough (≈ 30 layouts ×
256 paths × 72 h ≈ 50–100 ms in numpy) to run on every competitor-map refresh.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np

import telx_adaptive as T


@dataclass
class Market:
    """Inputs the controller reads from the measurement layer."""
    spot: int
    comps: list[T.Competitor]
    sigma_h: float                    # ticks per √hour
    increments: np.ndarray            # realised hourly tick changes (trailing window) for bootstrap
    budget_tel_per_h: float = T.WEEKLY_TEL / 168
    volume_usd_per_h: float = 43_000 / 168
    drift_ticks_per_h: float = 0.0    # + = TEL weakening; default 0 (zero log-drift)
    gas_usd: float = T.GAS_USD_PER_BUNDLE
    swap_cost_frac: float = T.SWAP_COST_FRAC


@dataclass
class SolverCfg:
    """Solver knobs (mirrors ``AdaptiveWidthConfig.solver`` in the design doc)."""
    paths: int = 256
    horizon_h: int = 72
    seed: int = 7
    core_halfs: tuple[int, ...] = (180, 240, 300, 360, 420, 480, 600, 720, 840, 960, 1200, 1500)
    asym_fracs: tuple[float, ...] = (0.4167, 0.5, 0.5833)   # TEL-side share of the core width (±1 step around symmetric; wider skews only via the token-tilt rule)
    anchor_shapes: tuple[tuple[int, int], ...] = ((2220, 2220), (3000, 1440))   # symmetric vs TEL-heavy anchor
    splits: tuple[float, ...] = (0.15, 0.3, 0.4, 0.5, 0.6, 0.7)
    core_dwell_steps: int = 2          # hourly steps out of range before re-centre (one full hour out ≈ 60-min dwell)
    anchor_margin: int = 300
    grid_halfspan: int = 6000


class Evaluator:
    """Evaluates layouts on a common set of bootstrapped tick paths against a fixed competitor map."""

    def __init__(self, m: Market, cfg: SolverCfg, capital_usd: float = 2000.0) -> None:
        self.m, self.cfg = m, cfg
        rng = np.random.default_rng(cfg.seed)
        inc = m.increments - m.increments.mean() if len(m.increments) >= 24 else rng.normal(0, m.sigma_h, 2000)
        # rescale bootstrap increments to the current σ estimate (window may differ from the σ window)
        if inc.std() > 0:
            inc = inc * (m.sigma_h / inc.std())
        draws = rng.choice(inc, size=(cfg.paths, cfg.horizon_h), replace=True) + m.drift_ticks_per_h
        self.ticks = m.spot + np.cumsum(draws, axis=1)                       # tick after each hourly step
        self.ticks = np.concatenate([np.full((cfg.paths, 1), float(m.spot)), self.ticks], axis=1)
        # competitor grid lookups
        self.grid = np.arange(m.spot - cfg.grid_halfspan, m.spot + cfg.grid_halfspan + 1, T.TICK_SPACING, dtype=float)
        self.L_grid = T.liquidity_at(self.grid, m.comps)
        self.c0_grid, self.c1_grid = T.competitor_amounts_at(self.grid, m.comps)
        self.capital_tel = capital_usd / T.tel_usd(m.spot)                    # TEL-equivalent budget at spot
        self.tel_per_eusd_path = 1.0001 ** self.ticks * 1e-12

    def _lookup(self, arr: np.ndarray, ticks: np.ndarray) -> np.ndarray:
        idx = np.clip(np.round((ticks - self.grid[0]) / T.TICK_SPACING).astype(int), 0, len(self.grid) - 1)
        return arr[idx]

    def evaluate(self, lay: T.Layout) -> dict[str, float]:
        """Expected weekly TEL decomposition for ``lay`` (mean over paths)."""
        P, H = self.cfg.paths, self.cfg.horizon_h
        ticks = self.ticks
        spot0 = np.full(P, float(self.m.spot))
        # build positions at t=0 sized in TEL-equivalent
        def build(b: T.Bracket, centre: np.ndarray, budget_tel: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
            c = np.floor(centre / T.TICK_SPACING) * T.TICK_SPACING
            tl, tu = c - b.tel_side, c + T.TICK_SPACING + b.eusd_side
            a0, a1 = self._amounts(np.ones(P), tl, tu, centre)
            v = a1 / 1e18 + a0 / 1e6 * (1.0001 ** centre * 1e-12)
            return tl, tu, np.where(v > 0, budget_tel / np.maximum(v, 1e-300), 0.0)

        core_budget = self.capital_tel * lay.core.weight
        ctl, ctu, cL = build(lay.core, spot0, np.full(P, core_budget))
        has_anchor = lay.anchor is not None
        if has_anchor:
            atl, atu, aL = build(lay.anchor, spot0, np.full(P, self.capital_tel * lay.anchor.weight))
        else:
            atl = atu = aL = np.zeros(P)
        wallet0 = np.zeros(P)   # eUSD raw leftover
        wallet1 = np.zeros(P)   # TEL raw leftover
        hodl0 = self._amounts(cL, ctl, ctu, spot0)[0] + (self._amounts(aL, atl, atu, spot0)[0] if has_anchor else 0)
        hodl1 = self._amounts(cL, ctl, ctu, spot0)[1] + (self._amounts(aL, atl, atu, spot0)[1] if has_anchor else 0)
        merkl = np.zeros(P); fees = np.zeros(P); costs = np.zeros(P); oor_steps = np.zeros(P, dtype=int)
        core_in_steps = np.zeros(P); recentres = np.zeros(P); width_tel_exposure = np.zeros(P)
        lshare_acc = np.zeros(P)
        for h in range(1, H + 1):
            tk = ticks[:, h - 1]               # tick in force during hour h
            core_in = (tk >= ctl) & (tk < ctu)
            anc_in = (tk >= atl) & (tk < atu) if has_anchor else np.zeros(P, dtype=bool)
            Lus = np.where(core_in, cL, 0.0) + np.where(anc_in, aL, 0.0)
            c0u, c1u = self._amounts(cL, ctl, ctu, tk)
            a0u, a1u = self._amounts(aL, atl, atu, tk) if has_anchor else (np.zeros(P), np.zeros(P))
            us0 = np.where(core_in, c0u, 0.0) + np.where(anc_in, a0u, 0.0)
            us1 = np.where(core_in, c1u, 0.0) + np.where(anc_in, a1u, 0.0)
            Lo = self._lookup(self.L_grid, tk); o0 = self._lookup(self.c0_grid, tk); o1 = self._lookup(self.c1_grid, tk)
            ls = np.where(Lus > 0, Lus / (Lus + Lo), 0.0)
            s0 = np.where(us0 > 0, us0 / (us0 + o0), 0.0)
            s1 = np.where(us1 > 0, us1 / (us1 + o1), 0.0)
            share = 0.5 * ls + 0.25 * s0 + 0.25 * s1
            merkl += share * self.m.budget_tel_per_h
            lshare_acc += ls
            fees += self.m.volume_usd_per_h * T.LP_FEE * ls / (T.EUSD_USD / (1.0001 ** tk * 1e-12))
            core_in_steps += core_in
            tot0 = c0u + a0u + wallet0
            width_tel_exposure += (tot0 / 1e6 * (1.0001 ** tk * 1e-12)) / np.maximum(1e-9, tot0 / 1e6 * (1.0001 ** tk * 1e-12) + (c1u + a1u + wallet1) / 1e18)
            # end-of-hour tick → triggers
            tk2 = ticks[:, h]
            core_out = (tk2 < ctl) | (tk2 >= ctu)
            oor_steps = np.where(core_out, oor_steps + 1, 0)
            fire = core_out & (oor_steps >= max(1, self.cfg.core_dwell_steps))
            if fire.any():
                self._recentre(fire, lay.core, tk2, ctl, ctu, cL, wallet0, wallet1, costs)
                recentres += fire
                oor_steps = np.where(fire, 0, oor_steps)
            if has_anchor:
                near = ((tk2 - atl) < self.cfg.anchor_margin) | ((atu - 1 - tk2) < self.cfg.anchor_margin)
                if near.any():
                    self._recentre(near, lay.anchor, tk2, atl, atu, aL, wallet0, wallet1, costs)
                    recentres += near
        tk_end = ticks[:, H]
        e0 = self._amounts(cL, ctl, ctu, tk_end)[0] + (self._amounts(aL, atl, atu, tk_end)[0] if has_anchor else 0) + wallet0
        e1 = self._amounts(cL, ctl, ctu, tk_end)[1] + (self._amounts(aL, atl, atu, tk_end)[1] if has_anchor else 0) + wallet1
        q_end = 1.0001 ** tk_end * 1e-12
        w_end = e1 / 1e18 + e0 / 1e6 * q_end
        w_hodl_mix = hodl1 / 1e18 + hodl0 / 1e6 * q_end
        w_start = self.capital_tel
        weeks = H / 168
        out = {
            "merkl_tel_wk": merkl.mean() / weeks,
            "fees_tel_wk": fees.mean() / weeks,
            "hodl_mix_term_tel_wk": (w_hodl_mix - w_start).mean() / weeks,      # eUSD exposure: + when TEL fell
            "il_tel_wk": (w_end - w_hodl_mix).mean() / weeks,                    # concavity loss vs HODL mix (≤ 0), costs already deducted below
            "costs_tel_wk": costs.mean() / weeks,
            "core_uptime": core_in_steps.mean() / H,
            "recentres_wk": recentres.mean() / weeks,
            "l_share_tw": lshare_acc.mean() / H,
            "eusd_fraction_tw": width_tel_exposure.mean() / H,
        }
        out["il_tel_wk"] += out["costs_tel_wk"]  # costs were taken out of w_end inside _recentre; report IL ex-costs
        out["delta_w_tel_wk"] = (w_end - w_start).mean() / weeks
        out["total_tel_wk"] = out["merkl_tel_wk"] + out["fees_tel_wk"] + out["delta_w_tel_wk"]
        out["total_ex_hodl_tel_wk"] = out["total_tel_wk"] - out["hodl_mix_term_tel_wk"]   # drift-neutral objective
        out["p5_total_tel_wk"] = float(np.percentile((merkl + fees + (w_end - w_start)) / weeks, 5))
        out["usd_net_wk_vs_hodl_usd"] = float((((e0 / 1e6 * T.EUSD_USD + e1 / 1e18 * T.EUSD_USD / q_end) - (hodl0 / 1e6 * T.EUSD_USD + hodl1 / 1e18 * T.EUSD_USD / q_end)) + (merkl + fees) * T.EUSD_USD / q_end).mean() / weeks)
        return out

    def _amounts(self, L: np.ndarray, tl: np.ndarray, tu: np.ndarray, tick: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        a, b = 1.0001 ** (tl / 2), 1.0001 ** (tu / 2)
        p = 1.0001 ** (tick / 2)
        below, above = tick < tl, tick >= tu
        a0 = np.where(below, L * (1 / a - 1 / b), np.where(above, 0.0, L * (1 / p - 1 / b)))
        a1 = np.where(below, 0.0, np.where(above, L * (b - a), L * (p - a)))
        return a0, a1

    def _recentre(self, mask: np.ndarray, b: T.Bracket, tk: np.ndarray, tl: np.ndarray, tu: np.ndarray, L: np.ndarray,
                  w0: np.ndarray, w1: np.ndarray, costs: np.ndarray) -> None:
        """Rebuild bracket ``b`` around ``tk`` for paths in ``mask``: swap to the shape's mix, pay costs (in place)."""
        a0, a1 = self._amounts(L, tl, tu, tk)
        a0 = a0 + w0; a1 = a1 + w1
        q = 1.0001 ** tk * 1e-12
        v_tel = a1 / 1e18 + a0 / 1e6 * q
        c = np.floor(tk / T.TICK_SPACING) * T.TICK_SPACING
        ntl, ntu = c - b.tel_side, c + T.TICK_SPACING + b.eusd_side
        u0, u1 = self._amounts(np.ones_like(L), ntl, ntu, tk)
        unit_v = u1 / 1e18 + u0 / 1e6 * q
        # swapped notional (TEL terms) = |target eUSD − held eUSD| in TEL
        gas_tel = self.m.gas_usd / (T.EUSD_USD / q)
        nL_pre = v_tel / np.maximum(unit_v, 1e-300)
        swapped_tel = np.abs(nL_pre * u0 - a0) / 1e6 * q
        cost = swapped_tel * self.m.swap_cost_frac + gas_tel
        nL = np.maximum(v_tel - cost, 0) / np.maximum(unit_v, 1e-300)
        tl[mask] = ntl[mask]; tu[mask] = ntu[mask]; L[mask] = nL[mask]
        w0[mask] = 0.0; w1[mask] = 0.0
        costs[mask] += cost[mask]


@dataclass
class Solution:
    """Solver output."""
    best: T.Layout
    best_eval: dict[str, float]
    curve: list[dict[str, Any]] = field(default_factory=list)


def solve(m: Market, cfg: SolverCfg, objective: str = "total_tel_wk", start: T.Layout | None = None,
          stages: tuple[str, ...] = ("core", "asym", "anchor", "split")) -> Solution:
    """Coordinate-descent over tickSpacing-aligned widths, TEL-side skew, anchor shape and split."""
    ev = Evaluator(m, cfg)
    cur = start or T.sym(600)
    curve: list[dict[str, Any]] = []

    def score(lay: T.Layout) -> tuple[float, dict[str, float]]:
        r = ev.evaluate(lay)
        curve.append({"layout": lay.label(), **r})
        return r[objective], r

    best_s, best_r = score(cur)
    for _ in range(2):
        for stage in stages:
            cands: list[T.Layout] = []
            W = cur.core.tel_side + cur.core.eusd_side
            if stage == "core":
                for hf in cfg.core_halfs:
                    f = cur.core.tel_side / max(1, W)
                    ts = int(round(2 * hf * f / 60)) * 60
                    cands.append(T.Layout(T.Bracket(ts, 2 * hf - ts, cur.core.weight), cur.anchor))
            elif stage == "asym":
                for f in cfg.asym_fracs:
                    ts = int(round(W * f / 60)) * 60
                    cands.append(T.Layout(T.Bracket(ts, W - ts, cur.core.weight), cur.anchor))
            elif stage == "anchor" and cur.anchor is not None:
                for (a, b) in cfg.anchor_shapes:
                    cands.append(T.Layout(cur.core, T.Bracket(a, b, cur.anchor.weight)))
            elif stage == "split" and cur.anchor is not None:
                for s in cfg.splits:
                    cands.append(T.Layout(T.Bracket(cur.core.tel_side, cur.core.eusd_side, s), T.Bracket(cur.anchor.tel_side, cur.anchor.eusd_side, 1 - s)))
            for lay in cands:
                if lay.core.tel_side < 60 or lay.core.eusd_side < 60:
                    continue
                if lay == cur:
                    continue
                s, r = score(lay)
                if s > best_s + 1e-9:
                    best_s, best_r, cur = s, r, lay
    return Solution(cur, best_r, curve)


def width_curve(m: Market, cfg: SolverCfg, halfs: tuple[int, ...] | None = None, w_core: float = 0.5,
                anchor_half: int | None = 2220) -> list[dict[str, Any]]:
    """Symmetric-width sweep (the §2 saturation/IL curve)."""
    ev = Evaluator(m, cfg)
    rows = []
    for hf in halfs or cfg.core_halfs:
        lay = T.sym(hf, w_core, anchor_half)
        r = ev.evaluate(lay)
        # static L share at spot for the core alone
        L_core = ev.capital_tel * w_core / (lambda a0, a1: a1 / 1e18 + a0 / 1e6 * T.tel_per_eusd(m.spot))(*T.amounts(1.0, *lay.core.bounds(m.spot), m.spot))
        Lo = float(T.liquidity_at(np.array([float(m.spot)]), m.comps)[0])
        rows.append({"half": hf, "pct": (1.0001 ** hf - 1) * 100, "L_core": L_core, "static_core_share": L_core / (L_core + Lo), **r})
    return rows
