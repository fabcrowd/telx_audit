---
cursor:
  subagentId: "bc-1b8fce17-3e2d-57d5-8bb0-4fb17fc24a4b"
---

# TELx / Telcoin accessible-repo inventory

**Access date:** 2026-11-08 (America/New_York)  
**Re-check:** same day ~15:53 ET after user reported GitHub “should be connected.”  
**Identity used:** Cursor GitHub App integration (`gh auth` user `cursor`), **not** personal `fabcrowd`. Unchanged after reconnect.  
**`gh api user` / `user/orgs` / `user/repos`:** HTTP 403 `Resource not accessible by integration`.  
**Installation repos API:** **1** repo — `fabcrowd/telx_audit` (public only).  
**Private repos visible:** **0**. No `GITHUB_TOKEN` / `GH_TOKEN` secret injected (`CLOUD_AGENT_ALL_SECRET_NAMES` = target_username/target_password only).  
**User action requested:** expand Cursor GitHub App to All repositories / TELx privates, **or** add `GITHUB_TOKEN` PAT secret (preferred for this already-running VM), then reply.

This inventory therefore covers **everything the current token can list/clone**. Cursor SCM “pushable only” caveat noted: this scan still found no private-readable TELx repos. Re-run after PAT or App grant.

---

## Auth / method

| Check | Result |
|-------|--------|
| `gh auth status` | Logged in as `cursor` (integration token) |
| Expected identity | `fabcrowd` / fabcrowd@gmail.com — **not active** |
| `gh repo list fabcrowd --limit 200` | 22 repos, **all public** |
| `gh api user/orgs` | 403 |
| `gh api users/fabcrowd/orgs` | `[]` |
| Orgs listed by public API | `Telcoin-Association`, `Telx-lab`, `telcoin`, `Telx` (unrelated 2016 Cucumber) |

---

## Triage legend

| Tag | Meaning for Merkl LP bot on Base |
|-----|----------------------------------|
| **HIGH** | Subscribe / PositionRegistry / pool keys / reward math / Merkl / rebalance encoding |
| **MED** | Adjacent (legacy calculators, subgraphs, Snapshot scoring, ops) |
| **LOW** | Marketing, TN protocol, forks, empty, unrelated |

---

## A. fabcrowd (22 public, 0 private)

| Repo | Updated | Relevance | Notes |
|------|---------|-----------|-------|
| [fabcrowd/telx_audit](https://github.com/fabcrowd/telx_audit) | 2026-03-30 | **HIGH** | Fork of TA issuance; has `TELxRewardsCalculator`, checkpoints; **no** `backend/merkl/` (upstream TA does). Audit/working copy of native-reward era. |
| [fabcrowd/telcoin-application-network-issuance](https://github.com/fabcrowd/telcoin-application-network-issuance) | 2026-03-30 | **HIGH** | Older fork (tracks `leopashov/…` upstream remote); missing Merkl reporter vs TA canonical. Prefer TA original. |
| [fabcrowd/lpsubgraph](https://github.com/fabcrowd/lpsubgraph) | 2025-12-09 | **HIGH** | Base v4 LP subgraph + ABIs; still pins **legacy** registry `0x3994…` / hook `0x23aB…` / pool `0x727b…` and Passive/Active/JIT. |
| [fabcrowd/subgraph](https://github.com/fabcrowd/subgraph) | 2025-12-15 | **MED** | Graph-node stack + `docs/rewards_rules.md` (Essential Guide Passive/JIT copy). |
| [fabcrowd/subgraph2](https://github.com/fabcrowd/subgraph2) | 2025-12-16 | **LOW** | **Empty** repo. |
| [fabcrowd/wallet_tracker](https://github.com/fabcrowd/wallet_tracker) | 2026-01-14 | **LOW** | Multi-chain TEL wallet HTML tracker. |
| [fabcrowd/telcoin-network](https://github.com/fabcrowd/telcoin-network) | 2026-04-08 | **LOW** | TN protocol fork. |
| [fabcrowd/telcoinwiki](https://github.com/fabcrowd/telcoinwiki) | 2026-08-20 | **LOW** | Wiki hub. |
| [fabcrowd/Telcoin-Association-Agency](https://github.com/fabcrowd/Telcoin-Association-Agency) | 2026-08-11 | **LOW** | Marketing. |
| [fabcrowd/Telcoin-Association-Stream](https://github.com/fabcrowd/Telcoin-Association-Stream) | 2025-09-04 | **LOW** | Stream. |
| [fabcrowd/Marketing_Agent](https://github.com/fabcrowd/Marketing_Agent) | 2026-03-10 | **LOW** | TA marketing agent. |
| [fabcrowd/tradingbot](https://github.com/fabcrowd/tradingbot) | 2026-09-19 | **LOW** | Unrelated tradingbot. |
| holderdistribution, card-scanner-data, BEATBOTS, pokemon-auto-lister, fantasy-football-draft-roomv2, logocreator, Singulr, pokescan, skills, rust-libp2p | various | **LOW** | Non-TELx / personal. |

---

## B. Telcoin-Association (28 public, 0 private listed)

| Repo | Updated | Relevance | Notes |
|------|---------|-----------|-------|
| [telcoin-laboratories-contracts](https://github.com/Telcoin-Association/telcoin-laboratories-contracts) | 2026-10-01 | **HIGH** | **Canonical** thin `PositionRegistry` + `TELxSubscriber` source, CREATE3 predicted addresses, BaseAddresses, TELxPools catalog (hooks=`address(0)`), deploy/seed/verify runbooks. Hook removed 2026-05. |
| [telx-frontend](https://github.com/Telcoin-Association/telx-frontend) | 2026-10-13 | **HIGH** | Live Merkl registry/subscriber/pool IDs in `src/lib/contracts.ts`; mint+subscribe multicall in `src/lib/v4/positionManager.ts`; `src/data/pool.json` PoolKeys; Essential Guide still legacy. |
| [telcoin-application-network-issuance](https://github.com/Telcoin-Association/telcoin-application-network-issuance) | 2026-09-23 | **HIGH** | `TELxRewardsCalculator.ts` (legacy Passive/JIT weights vs `0x3994…`); `backend/merkl/merklCampaignReport.ts`; Base ETH/TEL poolId `0x727b…` checkpoints. |
| [score-api](https://github.com/Telcoin-Association/score-api) | 2025-10-31 | **MED** | Snapshot strategy `uni-v4-telx-lp` → `getSubscriptions` / `getAmountsForLiquidity`. |
| [telx-community](https://github.com/Telcoin-Association/telx-community) | 2025-02-25 | **MED** | Community LP docs UI (older). |
| [tel-v3](https://github.com/Telcoin-Association/tel-v3) | 2026-10-03 | **MED** | TEL v3 / bridge / CREATE3 token addresses (needed for Merkl-era pools). |
| [forge-deploy-utils](https://github.com/Telcoin-Association/forge-deploy-utils) / [safe-utils](https://github.com/Telcoin-Association/safe-utils) | 2026 | **LOW–MED** | Deploy tooling only. |
| tn-*, telcoin-network, chains, explorer*, sourcify*, TNIPs, assets, recoverable-wrapper, rust-libp2p, viem, .github | various | **LOW** | TN / infra / mirrors. |

---

## C. Telx-lab (9 public, 0 private)

| Repo | Relevance | Notes |
|------|-----------|-------|
| telx-viem | **LOW** | Plain viem mirror; eth_subscribe noise only. |
| telx-community | **MED** | Mirror of TA community app. |
| telx-chain, telx-network, telx-TNIs, tel-contract, telx-GemPAD-v1, tnip-actions, .github | **LOW** | Emptyish / early lab scaffolding. |

---

## D. telcoin org (23 public)

Mostly Rust infra, token lists, historical airdrops. Closest adjacent: `generalized-incentives`, `balancer-airdrops` — **LOW** for v4 Merkl bot.

---

## E. Probe 404s (do not invent access)

Tried and got **404** (absent or private-without-access):

`Telcoin-Association/{telx-contracts,telx,TELxIncentiveHook,PositionRegistry,telx-incentives,uniswap-v4-hooks,telx-hooks,merkl}`, `Telx-lab/{telx-contracts,PositionRegistry}`, `fabcrowd/{telx_private,telx-contracts}`.

---

## F. Deep-read HIGH file index (clone roots under `/tmp/telx-repos/`)

### `Telcoin-Association/telcoin-laboratories-contracts`

| Path | Why |
|------|-----|
| `contracts/telx/core/PositionRegistry.sol` | Thin Merkl-era index; caps; eligibility |
| `contracts/telx/core/TELxSubscriber.sol` | `notifySubscribe` / no-op modify / wrapped burn |
| `contracts/telx/interfaces/IPositionRegistry.sol` | Full external ABI surface |
| `contracts/telx/core/README.md` | Security spec + address tables |
| `contracts/telx/core/spec.md` | Merkl out-of-scope note |
| `script/telx/README.md` | Deploy/seed/subscribe runbook |
| `script/shared/TELxPools.sol` | 7-pool catalog; hooks always 0 |
| `script/shared/BaseAddresses.sol` | Base periphery + TEL_V2/V3 + safes |
| `script/shared/CrossChainAddresses.sol` | TEL_V3, eUSD, CREATEX, gov Safe |
| `script/shared/Salts.sol` | `TELX_POSITION_REGISTRY_V3` / `TELX_SUBSCRIBER_V3` |
| `INVARIANTS.md` | Hook removal changelog; Merkl owns rewards |
| `deployments/base.json` | `{}` — predicted CREATE3 batch **not recorded as executed** |

### `Telcoin-Association/telx-frontend`

| Path | Why |
|------|-----|
| `src/lib/contracts.ts` | **Live** Merkl registry/subscriber/poolIds + legacy |
| `src/merkl/merklConstants.ts` | Distributor, TEL_V3 reward token |
| `src/data/pool.json` | Active Base Merkl PoolKeys (hooks 0, TEL_V3) |
| `src/lib/v4/positionManager.ts` | `encodeMintAndSubscribe` / PosM `subscribe` |
| `src/lib/v4/range.ts` | In-range required for subscribe |
| `src/hooks/usePositionActions.ts` | Subscribe/unsubscribe UX + OutOfRange handling |
| `content/about/TELx-liquidity-mining-essential-guide-for-lps.md` | **Stale** Passive/JIT guide → legacy `0x3994…` |

### `Telcoin-Association/telcoin-application-network-issuance`

| Path | Why |
|------|-----|
| `backend/calculators/TELxRewardsCalculator.ts` | Legacy fee-share + Passive weights vs Base `0x3994…` |
| `backend/merkl/merklCampaignReport.ts` | Merkl API → xlsx (no API key for `/v4/rewards`) |
| `backend/checkpoints/base-ETH-TEL-*.json` | Historical native-era accruals |

### `fabcrowd/lpsubgraph` / `fabcrowd/subgraph`

| Path | Why |
|------|-----|
| `config/telxBasePool.ts`, `README.md` | Legacy Base addresses |
| `abis/PositionRegistry.json`, `Subscriber.json` | Legacy ABIs |
| `docs/rewards_rules.md` | Essential Guide dump |

### `Telcoin-Association/score-api`

| Path | Why |
|------|-----|
| `src/strategies/strategies/uni-v4-telx-lp/` | Snapshot reads registry views |

---

## G. Address / pool fact sheet (from deep-read)

### Registries / subscribers (Base)

| Role | Address | Source |
|------|---------|--------|
| Legacy PositionRegistry (Passive/JIT) | `0x3994e3ae3Cf62bD2a3a83dcE73636E954852BB04` | labs README, frontend, calculator, lpsubgraph |
| Legacy TELxSubscriber | `0x735ee950D979C70C14FAa739f80fC96d9893f7ED` | same |
| Legacy TELxIncentiveHook (ETH/TEL v2) | `0x23aB2e6D4Ab0c5f872567098671F1ffb46Fd2500` | labs README, frontend |
| **Live Merkl PositionRegistry** | `0xcebC0b00473Ca00e429eF431826d0A32cdc945E1` | **frontend** `MERKL_POSITION_REGISTRY` (same on ETH/Poly/Base) |
| **Live Merkl TELxSubscriber** | `0x19EDFa380ead0Bb26010Ca3d1C7AbC7213938c86` | **frontend** `MERKL_TELX_SUBSCRIBER` |
| Predicted CREATE3 thin registry (TEL v3 catalog) | `0x00637FBbae593E920B1d08300EC1f05d6D61Aa61` | labs scripts; **not** in `deployments/base.json`; **≠** Merkl live |
| Predicted CREATE3 TELxSubscriber | `0xD9e2c4A560ba8FD0f28A5Bf25B3940576cc53fEC` | labs scripts |
| Merkl Distributor | `0x3Ef3D8bA38EBe18DB133cEc108f4D14CE00Dd9Ae` | frontend merklConstants |
| Governance Safe (CREATE3 deployer) | `0x6012dBcb4350Ab297FeB7f96D4d86258062aeB03` | CrossChainAddresses |
| Support Safe (Base) | `0xE3a465e1460E9987c772c36b91020946BC60Af52` | BaseAddresses |

### Tokens (Base)

| Token | Address | Decimals |
|-------|---------|----------|
| TEL v2 (legacy pool) | `0x09bE1692ca16e06f536F0038fF11D1dA8524aDB1` | 2 |
| TEL v3 (Merkl pools / rewards) | `0x7E13B43065380aCdeC1c2d138c579cbBbafA0731` | 18 |
| eUSD | `0x14913815bCFDE78BAeAd2111F463D038Ac9C2949` | 6 |
| WETH | `0x4200000000000000000000000000000000000006` | 18 |
| Native ETH in PoolKey | `address(0)` | 18 |

### Uniswap v4 Base periphery (matches blueprint)

`PoolManager 0x4985…2b2b`, `PositionManager 0x7C5f…9bDc`, `StateView 0xA3c0…7A71`, `Permit2 0x0000…BA3`, `UniversalRouter 0x6fF5…9b43`.

### Pool IDs

| Pool | PoolId | Key summary | Active Merkl? |
|------|--------|-------------|---------------|
| Legacy Base ETH/TEL v2 | `0x727b2741…8829b` | ETH + TEL_V2, fee 3000, spacing 60, **hook 0x23aB…** | No (archived in pool.json) |
| **Merkl Base ETH/TEL** | `0x272e0968…214a6` | ETH + TEL_V3, fee 3000, spacing 60, **hooks 0** | Yes (`createdBlock` 51706252) |
| **Merkl Base eUSD/TEL** | `0x1266df87…b36982` | eUSD + TEL_V3, fee 3000, spacing 60, **hooks 0** | Yes (`createdBlock` 51706241) |

Note: Merkl ETH/TEL and eUSD/TEL poolIds are **shared across chains** that use identical CREATE3 token addresses + hooks=0 (frontend lists same ids on Ethereum / Base / Polygon as applicable).

### Subscribe flow (bot-critical)

1. Mint PosM NFT (optionally atomic with subscribe).  
2. Call `PositionManager.subscribe(tokenId, MERKL_TELX_SUBSCRIBER, 0x)`.  
3. Subscriber `notifySubscribe` → `PositionRegistry.handleSubscribe` (SUBSCRIBER_ROLE only; PoolManager must be locked).  
4. Eligibility: allowlisted pool, `liquidity >= minLiquidity`, and `inRangeRequired` (default true).  
5. `notifyModifyLiquidity` is **no-op** — modify does **not** auto-unsubscribe (unlike Essential Guide’s “drop below 1bp → unsubscribe” story).  
6. Transfer/burn → unsubscribe; refill after prune → permissionless `resubscribe(tokenId)`.  
7. Frontend encoding: `src/lib/v4/positionManager.ts` → `encodeMintAndSubscribe` / `mintAndSubscribeCalls`.

### Caps / floors (thin registry source)

- `MAX_SUBSCRIBED = 50_000` owners global  
- `MAX_SUBSCRIPTIONS = 1_000` per owner  
- Absolute per-pool `minLiquidity` (not 1 bp of pool TVL)  
- Suggested `minPositionValue1` ≈ 200 TEL for 1-spacing band (~$1)  

### Legacy native reward math (still in calculator; **not** Merkl)

- Period reward Base ETH/TEL: `64_814_814` TEL/week (2-decimal TEL units in script constants)  
- Passive / Active / JIT via `MIN_PASSIVE_LIFETIME`, weights on legacy registry  

---

## H. Gaps until fabcrowd private access

- Any private forks of labs contracts / Merkl campaign configs / operator scripts  
- Whether `0xcebC…` / `0x19ED…` source lives only in an unpublished branch or a private deploy repo (frontend constants exist; labs README still says predicted `0x00637…` “not yet deployed”)  
- Private Merkl campaign param dumps beyond public Merkl API  

Re-inventory after PAT / GitHub reconnect.
