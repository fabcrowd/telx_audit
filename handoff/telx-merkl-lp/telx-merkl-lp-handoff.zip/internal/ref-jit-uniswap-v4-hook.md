---
cursor:
  subagentId: "bc-2b328a44-5f24-5337-af44-2b746091ad58"
---

# Design reference: LamsyA/JIT-UNISWAP-V4-HOOK

**Scope:** Design research only. Anti-pattern / defensive lessons for a **Passive Merkl–compliant** TELx Uniswap v4 LP bot on Base.  
**Not in scope:** Implementing our bot; JIT profit runbooks; MEV attack playbooks.

**Repo:** https://github.com/LamsyA/JIT-UNISWAP-V4-HOOK  
**Analyzed tip:** `6de79c5` (2024-09-16) on default branch `dev`  
**Related project docs:** `/cursor/stores/self/docs/bot-blueprint.md`, `/cursor/stores/self/docs/project-context.md`

---

## 1. Purpose, maturity, license, activity

| Field | Finding |
|-------|---------|
| **Purpose** | Educational / hackathon-style **Just-In-Time (JIT) liquidity hook** for Uniswap v4: add concentrated liquidity in `beforeSwap` for “large” swaps, remove it in `afterSwap`, recycle inventory through a share-token vault (`JITRebalancer`). |
| **Stack** | Foundry (Solidity 0.8.26, Cancun), `BaseHook` + `IPoolManager`, Chainlink AggregatorV3, OZ ERC20/ReentrancyGuard/Ownable. |
| **License** | README claims **MIT**; SPDX headers on sources are MIT. GitHub API `license` field is `null` (no `LICENSE` file committed). Treat as MIT-intended but incomplete packaging. |
| **Maturity** | **Prototype / demo.** ~41 commits over ~12 days (2024-09-04 → 2024-09-16), then silence. No releases, no topics, 8★ / 3 forks. CI is `workflow_dispatch` only (manual). Submodules present but shallow clone leaves them empty without `--recursive`. Tests cover vault deposits and swap-path smoke cases; production hardening is thin (shared hook state, USD threshold quirks, console logs in prod paths). |
| **Activity** | Last push 2024-09-16; GitHub `updated_at` later is metadata-only. **Dormant.** |
| **Contributors** | Small set (Lamsy / Adetula Olamide, the-first-elder, Paul Elisha). |

**Verdict for TELx work:** Useful as a **negative design reference** (what Merkl Passive explicitly zeros) plus a few generic v4 PoolManager / tick / settle patterns. Do **not** copy the product behavior into a Merkl-rewarded strategy.

---

## 2. How the JIT hook works (architecture, high level)

### Components

```text
LP depositors
    │  depositLiquidity / withdrawLiquidity (share ERC20)
    ▼
JITRebalancer (per pair vault + Chainlink _getPrice)
    │  approved to RouterHook
    ▼
RouterHook (BaseHook: beforeSwap + afterSwap)
    │  poolManager.modifyLiquidity ± settle/take
    ▼
Uniswap v4 PoolManager (singleton pool state)
```

- **`RouterHook`** (`src/RouterHook.sol`): pool hook. Owns `rebalancerFactory`, maps `(token0,token1) → JITRebalancer`, implements JIT around swaps.
- **`JITRebalancer`** (`src/JITRebalancer.sol`): inventory vault; depositors mint shares; tokens are pulled into the hook during JIT add and returned via `take` after remove.
- **No PositionManager / NFT positions.** Liquidity is added as **hook-owned PoolManager positions** keyed by `(tickLower, tickUpper, salt: 0)` — not TELx-subscribable PosM NFTs.

### Swap lifecycle (conceptual)

1. **Swap starts** → PoolManager calls hook `beforeSwap`.
2. Hook reads Chainlink price, approximates `tokenInUsd` from `amountSpecified * price`.
3. If above `LARGE_SWAP_THRESHOLD` (`1e7` in code units):
   - Estimates post-swap tick via `SwapMath.computeSwapStep` + `TickMath`.
   - Builds a **narrow tick band** around that tick (`getLowerUsableTick` / mirrored lower bound — heuristic, not production-grade ranging).
   - `poolManager.modifyLiquidity(... liquidityDelta > 0 ...)` **adds** liquidity.
   - Settles negative deltas by `transferFrom` vault → hook → `Currency.settle` into PoolManager.
4. **Swap executes** against the augmented liquidity (fees accrue to the JIT position).
5. Hook `afterSwap`:
   - Same ticks / `liquidityDelta` with **negative** delta → **remove** liquidity.
   - Positive deltas `Currency.take` back to the vault.

**Canonical Merkl-hostile pattern:** **same-transaction / same-block add then remove** of liquidity around a swap. That is exactly the documented TELx/Merkl **JIT → 0% weight** behavior class.

### Permissions / integration notes

- Hook permissions: **only** `beforeSwap` + `afterSwap` (no liquidity-add/remove hooks).
- Uses v4 flash accounting helpers (`CurrencySettler` settle/take) inside the unlock context.
- Factory is `onlyOwner`; pair uniqueness enforced both orientations.
- Transient state (`tickLower`, `tickUpper`, `liquidityDelta`, `price`) lives in **contract storage** across before→after — fine for single-threaded swap unlock, fragile if concurrent logic or reentrancy assumptions change.

---

## 3. Contrast with our TELx Merkl Passive strategy

| Dimension | This repo (JIT hook) | Our bot (blueprint) |
|-----------|----------------------|---------------------|
| **Objective** | Capture swap fees / reduce swapper slippage on large trades | Maximize **Merkl Passive reward share** (~425k TEL/week/pool) |
| **Liquidity lifetime** | Seconds: add before swap, remove after | Days: staggered brackets, ≤1 modify / ~24h (Base **43_200 blocks**) |
| **Position shape** | Ephemeral PM position, `salt: 0`, hook-owned | PosM **NFTs** → must `TELxIncentiveController.subscribe` |
| **Trigger** | Large swap USD notional inside hook | Outer-buffer breach + cooldown OK; optional volume spark |
| **Merkl class** | **JIT** (add+remove same block) → **0%** | Target **Passive**; avoid **Active** (re-modify inside window) |
| **Capital path** | Shared vault recycled every large swap | Dedicated LP capital; custody stable (NFT transfer unsubscribes) |

### Defensive lessons (Passive Merkl compliance)

Emphasize **detection and avoidance**, not replication.

#### A. Detection signals (what Merkl / auditors / our own guards should flag)

1. **Same-block liquidity add + remove** on the same position identity (or wallet/tokenId set) with a swap interleaved or adjacent.
2. **Same-tx `modifyLiquidity(+)` then `modifyLiquidity(-)`** (this hook’s exact shape).
3. **Liquidity that exists only for the duration of one swap unlock** (present in `beforeSwap`, gone in `afterSwap`).
4. **Very short hold windows** even across blocks (docs: “very short window” besides same-block) — treat sub-cooldown churn as high risk.
5. **Hook-owned ephemeral PM positions** that never appear as subscribed PosM NFTs — irrelevant for earning TELx, but a red flag if any future campaign indexes raw PM liquidity.

#### B. Same-block add/remove patterns our bot must avoid

| Pattern | Why it is toxic for Merkl | Bot rule |
|---------|---------------------------|----------|
| Hook-style beforeSwap add / afterSwap remove | Textbook JIT | Never implement; never “help” swaps with ephemeral LP |
| Atomic burn+mint of ranges in one tx (blueprint §B risk) | Matches documented JIT / may zero period weight | Prefer staged modes; default `burn_then_mint_next_window` until TELx clarifies semantics |
| Mint new tokenId + burn old in same block “for capital efficiency” | Same-block add/remove class | Split across ≥ one Passive window **or** accept known 0% period |
| Multiple `modifyLiquidities` on same NFT inside 43_200 blocks | **Active** → 0% for remainder of reward period | Hard cooldown clock per position; outer-buffer-only triggers |
| “Rebalance every swap” / react to every tick | Active thrash | Breach margin + `maxRebalancesPerWeek` |

#### C. Timing windows (defensive)

| Window | Guidance |
|--------|----------|
| **Same block / same tx** | Hard forbid for add↔remove pairs that look like JIT. |
| **≪ 43_200 Base blocks** | Treat as Active risk; bot must refuse second modify. |
| **≥ 43_200 blocks** | Minimum Passive rebalance spacing (verify live campaign params). |
| **Fee claims** | Blueprint notes claims may not count as liquidity mods — keep claim path separate; still do not couple claims with range flips in one “optimization” bundle without confirmation. |
| **Subscribe** | Mint→subscribe same operational window is required for rewards; that is **not** the same as JIT add/remove. Prefer subscribe without an immediate opposing remove. |

#### D. Product-strategy inversion

This repo optimizes **fee capture on toxic/large flow**. Our bot optimizes **Time-In-Range + Passive classification** on low-volume TELx pools. Chasing this repo’s triggers (large swaps, tight ephemeral bands) would **destroy** Merkl weight even if fees look good on a scanner.

---

## 4. PositionManager / PoolManager patterns still useful for honest LP automation

**PositionManager:** essentially **absent**. Do not look here for PosM action encoding, `modifyLiquidities` unlock payloads, Permit2, or NFT subscribe flows. Prefer Uniswap v4 SDK / periphery docs and our blueprint §5–6.

**Still useful (generic v4 / test harness patterns):**

1. **`IPoolManager` + `StateLibrary` reads** — `getSlot0`, `getLiquidity` before planning (mirrors our monitor’s StateView usage).
2. **`ModifyLiquidityParams` shape** — `tickLower`, `tickUpper`, `liquidityDelta`, `salt`; honest bots still think in these terms even when PosM wraps them.
3. **Tick spacing helpers** — `getLowerUsableTick` / upper align pattern (implement carefully; this repo’s range construction is heuristic and buggy-looking for production).
4. **`TickMath` + `LiquidityAmounts` + `SwapMath`** — sizing liquidity for a target amount and estimating price impact (offline planner / simulate path).
5. **Settle / take flash accounting** — mental model for how unlock callbacks balance currencies (PosM hides this; useful when debugging failed unlocks).
6. **Foundry `Deployers` + `modifyLiquidityRouter` test setup** (`test/RouterHook.t.sol`) — good template for **local pool fixtures** with staggered ranges (−60/60, −120/120, full range) without needing mainnet forks initially.
7. **Hook permission bit addressing** — `deployCodeTo` with `BEFORE_SWAP_FLAG | AFTER_SWAP_FLAG` shows how v4 hook addresses encode permissions (relevant only if we ever read TELx pool hook flags — not for implementing JIT).
8. **Allowance hygiene sketch** — factory approves then `revokeUnUsedAllowances` (intent good; our bot should use explicit Permit2 / PosM allowances with least privilege instead).

**Explicitly not useful / avoid copying:**

- Shared mutable JIT tick/liquidity storage on a singleton hook.
- USD gate via `amountSpecified * chainlink / 1e18` (unit-fragile).
- Vault share math that tracks deposits separately from actual token balances after JIT PnL.
- Returning synthetic `BeforeSwapDelta` that can desync from real pool execution (design smell for any production hook).

---

## 5. Borrow-vs-avoid checklist & key files

### Borrow (adapt carefully)

- [ ] PoolManager slot0 / liquidity read pattern for monitors.
- [ ] Tick-spacing snap helpers (rewrite with tests; don’t paste blindly).
- [ ] LiquidityAmounts-based sizing for planned brackets.
- [ ] Foundry Deployers-style fixture for unit tests of planners (if we add a Solidity/math test package) — or mirror the fixture ideas in TS forks.
- [ ] Conceptual settle/take understanding for unlock debugging.
- [ ] Multi-range liquidity seeding idea in tests (core + buffers + wide) — aligns with our staggered A/B/C brackets **as durable positions**, not ephemeral JIT.

### Avoid (Merkl / product)

- [ ] Any beforeSwap-add / afterSwap-remove liquidity machine.
- [ ] Same-block or same-tx add↔remove for fee sniping.
- [ ] Hook-owned ephemeral positions as a substitute for PosM + TELx subscribe.
- [ ] Rebalancing on large-swap detection (invert: large toxic flow is a reason to **not** thrash ranges).
- [ ] Treating atomic burn+mint as “always OK” because capital is efficient — Merkl may zero the period.
- [ ] Copying Chainlink-in-hook pricing as a rebalance oracle (our triggers are slot0/tick breach + cooldown).
- [ ] Assuming this repo’s MIT README without a committed LICENSE file for compliance packaging (add our own license hygiene).

### Avoid (engineering quality)

- [ ] Production `console2.log`.
- [ ] Unverified USD threshold constants.
- [ ] Bidirectional factory map edge cases / owner-centric ops without ops runbooks.
- [ ] Relying on dormant 2024 prototype deps without pinning current v4-periphery for Base mainnet.

### Key files

| Path | Role |
|------|------|
| `README.md` | Stated JIT flow (beforeSwap add → swap → afterSwap remove). |
| `src/RouterHook.sol` | Hook architecture; JIT modifyLiquidity ±; factory; permissions. |
| `src/JITRebalancer.sol` | Vault, shares, Chainlink `_getPrice`. |
| `src/lib/Utils.sol` | Share mint math. |
| `test/RouterHook.t.sol` | v4 Deployers fixture; swap tests exercising hook path. |
| `test/JITRebalancer.t.sol` | Vault deposit/withdraw unit tests. |
| `script/HelperConfig.sol` | Chainlink mock / Sepolia feed addresses. |
| `foundry.toml` | Cancun / via-ir / optimizer profile. |
| `.github/workflows/test.yml` | Manual Foundry CI. |

---

## Bottom line for future developers

Use this repository as a **catalog of Merkl JIT anti-patterns** and a light **PoolManager literacy** aid. Our TELx bot must keep liquidity **passive, subscribed, PosM-NFT-based, and cooldown-gated**. If a design idea looks like `RouterHook.beforeSwap` / `afterSwap` liquidity bracketing, it is almost certainly **incompatible** with Passive reward eligibility.
