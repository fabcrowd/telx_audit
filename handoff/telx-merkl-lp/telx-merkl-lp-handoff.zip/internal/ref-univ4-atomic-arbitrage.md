---
cursor:
  subagentId: "bc-cb0d6519-f627-530a-bfd3-352aba4db4cd"
---

# Design reference: pixelis0x/UniV4-AtomicArbitrage

**Scope:** architecture research for a TELx Merkl Uniswap v4 LP bot on Base.  
**Not in scope:** arb/MEV implementation, attack procedures, bot code.  
**Source:** https://github.com/pixelis0x/UniV4-AtomicArbitrage (cloned for read-only review).  
**Related project docs:** `/cursor/stores/self/docs/project-context.md`, `/cursor/stores/self/docs/bot-blueprint.md`.

---

## 1. Purpose, maturity, license, activity

### Purpose

Public Foundry prototype branded **TheEqualizer**: an **atomic cross-pool swap router + discounted-fee hook** for Uniswap v4. Idea: many v4 pools share the same token pair but different hooks, so prices can diverge; flash accounting in the singleton `PoolManager` makes multi-pool ops cheap. The router swaps pool A → pool B in one `unlock` callback, keeps a small initiator bounty (~10%), and returns most profit to LPs via `donate()`. A companion hook can apply a lower dynamic LP fee when the caller is the arb router.

This is **not** an LP rebalancer, PositionManager integration, or Merkl/TELx subscriber.

### Maturity

| Signal | Observation |
|--------|-------------|
| Stage | Early research / demo (pre–v4-mainnet era) |
| Created | 2024-05-31 |
| Last push | 2024-06-11 (HEAD commit content dated 2024-06-07) |
| Stars / forks | ~11 / 1 (as of review) |
| Issues / releases | None meaningful; no tags |
| CI | `.github/workflows/test.yml` — Foundry build+test, **manual `workflow_dispatch` only** |
| Production readiness | **Low.** Router extends `PoolTestBase` (v4-core **test** helper), not official periphery. Scripts hardcode **Goerli** addresses. Submodule pins are mid-2024 `v4-core` / `v4-periphery` (APIs have drifted since). |
| Scaffolding | Root `LICENSE` copyright `saucepoint` (2023); leftover Counter / Goerli scripts — clearly started from Uniswap/saucepoint v4-template |

Treat as a **teaching sample for `unlock` + flash accounting + multi-op atomicity**, not a dependency to fork into production.

### License

- Repo SPDX / GitHub: **MIT** (`LICENSE`, copyright saucepoint).
- `src/AtomicArbHook.sol`: `MIT`.
- `src/AtomicArbRouter.sol`: header says **`UNLICENSED`** — inconsistent with root LICENSE. Resolve before any copy-paste reuse.

### Activity

Short burst (~10 author commits early June 2024), then idle. No ongoing maintenance relative to Base mainnet PoolManager / PositionManager.

**Dependency pins (gitlinks):**

- `lib/v4-core` → `3351c80e58e6300cb263d33a4efe75b88ad7b9b2`
- `lib/v4-periphery` → `ad7976af2181a80af0d381f4a8e9e234b880cc8f`
- Foundry: `solc 0.8.24`, `evm_version = cancun` (needed for transient storage / flash accounting)

---

## 2. Architecture: PoolManager / unlock / flash accounting / multicall

### High-level shape

```text
EOA / test caller
    │ arbSwap(key0, key1, direction, amount, hookData…)
    ▼
AtomicArbRouter  ──manager.unlock(abi.encode(CallbackData))──►  PoolManager
    ▲                                                              │
    │                    unlockCallback(rawData)                   │
    └──────────────────── (msg.sender must be manager) ◄───────────┘
                              │
                              ├─ manager.swap(key0, …)   // deltas accrue in transient storage
                              ├─ manager.swap(key1, …)   // uses prior swap output as input
                              ├─ manager.donate(key1, …) // optional profit routing
                              └─ currency.take(…)        // settle credit to initiator
```

There is **no separate off-chain multicall** and **no `PositionManager` / `Actions` codec**. Atomicity is entirely “multiple `PoolManager` calls inside one `unlock` session.”

### Unlock + callback (core pattern)

1. External entry `arbSwap` encodes a `CallbackData` struct (sender, pool keys, direction, amount, hook data, settle/take flags).
2. Calls `IPoolManager.unlock(bytes)` — PoolManager re-enters `IUnlockCallback.unlockCallback` on the **caller contract**.
3. Callback asserts `msg.sender == address(manager)`.
4. All pool ops happen while unlocked; currency **deltas** are tracked per locker (EIP-1153 transient storage in Cancun-era v4).
5. Before unlock ends, deltas must net to zero (or be explicitly `settle`/`take`’d). The sample uses `_fetchBalances` from `PoolTestBase` to read `manager.currencyDelta(deltaHolder, currency)` and require a clean intermediate asset (profit in one currency only).

### Flash accounting (what the sample demonstrates)

- Intermediate swap output never leaves the PoolManager as an ERC-20 transfer between the two swaps.
- Second swap size is derived from the first `BalanceDelta` (`amountUnspecified = -delta0.amount1()` or `amount0`).
- Initiator only `take`s the residual profit currency after donation — “capital efficiency of one lock.”
- Comments/tests explicitly note the sending token need not move when flash accounting closes the loop.

**LP-bot translation:** burn (negative liquidity delta → tokens owed **to** the locker) and mint (positive liquidity → tokens owed **from** the locker) in the **same unlock** can net inventory so you avoid an intermediate wallet hop — same accounting idea, different opcodes (`modifyLiquidity` vs `swap`).

### Settle / take

Uses `CurrencySettleTake` from v4-core:

- `settle` — pay PoolManager (ERC-20 transfer + `settle`, native value, or ERC-6909 burn).
- `take` — receive from PoolManager (ERC-20 or ERC-6909 claims mint).

The arb path only `take`s profit; swap legs are expected to net via flash accounting. An LP router would typically `settle` net deficits after mint and `take` net surpluses after burn (or let PosM do this).

### Hooks interaction (arb-adjacent — high level only)

`AtomicArbHook` registers `afterInitialize` + `beforeSwap`. On init it stores `(atomicArbRouterAddress, defaultFee, arbFee)`. On `beforeSwap`, if `caller == atomicArbRouterAddress`, it returns a dynamic fee override (`arbFee | OVERRIDE_FEE_FLAG`); else `defaultFee`. Pattern: **privileged caller gets cheaper pool fee**. Irrelevant to TELx Merkl LP unless a pool’s hook exposes similar caller-based behavior (do not assume TELx pools do).

### Multicall

**Absent.** No `multicall`, no Multicall3, no PosM `Action` batching. “Atomic bundle” here means **one unlock callback**, not a wallet-level multicall across unrelated contracts (e.g. PosM + TELx IncentiveController).

For TELx LP, subscribe lives **outside** PoolManager — unlock alone cannot register Merkl. You need a higher-level bundle: custom router that finishes unlock then calls `subscribe`, or an outer multicall / batched user ops wrapping PosM + TELx.

---

## 3. Atomic tx bundling patterns relevant to burn + mint (+ subscribe)

| Pattern in this repo | Relevance to burn→mint→subscribe |
|----------------------|----------------------------------|
| Single `unlock` → N `PoolManager` ops | **Directly relevant** for netting burn proceeds into new mints without leaving idle ERC-20 gaps mid-tx. |
| Encode all intent in `CallbackData` | Useful shape for a custom rebalance router (`burns[]`, `mints[]`, payer, deadline). |
| Require post-op delta invariants | Borrow the idea: assert no unexpected leftover currency / liquidity before unlock returns. |
| Profit `donate` / fee override hook | **Not relevant** to Merkl LP rebalance. |
| Cross-pool `swap` chaining | Only loosely related to optional “volume spark” self-swap; do not copy arb sizing/profit logic. |

### Practical LP mapping (conceptual)

```text
Option A — Custom unlock router (closest to this repo)
  rebalance() → PoolManager.unlock →
      modifyLiquidity (burn old ranges)
      modifyLiquidity (mint new brackets)
      settle/take nets
  then → TELxIncentiveController.subscribe(newTokenIds)   // same tx, after unlock

Option B — Official PositionManager (preferred for NFT positions)
  PosM.modifyLiquidities / multicall Actions: BURNs + MINTs (+ SETTLE/TAKE/SWEEP)
  + same-tx or follow-up TELx.subscribe(tokenIds)
  (this repo does not show PosM Actions encoding)

Option C — Outer Multicall3 / smart-wallet batch
  [PosM call, TELx.subscribe] as sibling calls if both are plain externals
```

### Merkl / TELx caution (from project blueprint — not from this repo)

Same-block burn+mint can look like **JIT** to Merkl and may zero reward weight for a period. Treat atomicity as **capital / inventory safety**, not automatically reward-optimal. Decide policy separately (atomic rebalance vs staggered across passive cooldown).

---

## 4. Contract vs off-chain bot split

| Layer | What this repo has | What a TELx Merkl LP bot needs |
|-------|--------------------|--------------------------------|
| On-chain | `AtomicArbRouter`, `AtomicArbHook`, Foundry scripts/tests | Prefer **PositionManager** (+ optional thin helper for subscribe atomicity). Custom PoolManager unlock router only if PosM cannot express the flow. **Avoid** deploying arb hooks. |
| Off-chain | **None** (opportunity detection not implemented) | Monitor slot0 / tick, bracket breach, Merkl eligibility clocks, encode calldata, simulate, submit, verify receipts, track tokenIds. |
| Initiation | External `arbSwap(...)` with fully specified args | Bot computes burns/mints/subscribe list; chain only executes. |
| Quoting | Test uses periphery `Quoter` ad hoc | Bot should simulate via `eth_call` / viem `simulateContract` against live Base PosM + TELx ABIs. |

**Split recommendation for TELx:** keep strategy, breach detection, Merkl rules, and gas policy **off-chain**; keep settlement atomicity **on-chain** via PosM (or a small unlock router) + TELx subscribe in one user transaction when policy allows.

---

## 5. Borrow vs avoid (we are not building arb)

### Borrow (patterns / mental models)

1. **`unlock` → callback → multiple PM ops → settle/take** as the atomicity primitive inside PoolManager.
2. **Flash-accounting netting** so burn credits fund mint debits in one lock.
3. **Explicit delta invariants** before completing the callback.
4. **`CurrencySettleTake` semantics** (pay/receive vs ERC-6909 claims) when touching PoolManager directly.
5. **Foundry + Cancun** test posture; HookMiner only if you ever deploy a hook (unlikely for consuming existing TELx pools).
6. **PoolKey** construction discipline (currency order, fee, tickSpacing, hooks address).

### Avoid / do not carry over

1. Cross-pool arbitrage, initiator bounty, `donate` profit sharing, LVR-capture framing.
2. Dynamic fee overrides / privileged-router hooks.
3. Subclassing **`PoolTestBase`** for anything production — use audited periphery (PosM, StateView).
4. Goerli scripts, template Counter, stale submodule pins — retarget Base mainnet addresses from Uniswap + TELx docs.
5. Treating this repo as a Merkl/subscribe reference — it has **zero** incentive-registry integration.
6. Assuming “one unlock” alone equals “burn+mint+subscribe” — subscribe is a **different contract**.
7. Copying MEV/frontrun narrative into the LP bot threat model as a feature; keep rebalance private-mempool / gas policy boring and defensive.
8. Blind same-block rebalance without checking TELx **passive / JIT** rules.

### Neutral / re-evaluate

- Tiny self-swap “volume spark”: this repo’s swap chaining shows flash-accounting swaps, but spark should be a separate, capped PosM/UniversalRouter path — not arb sizing.
- Custom router vs PosM-only: choose based on whether NFT position + TELx subscribe can be atomically composed without a bespoke contract.

---

## 6. Checklist + key file pointers

### Developer checklist (when implementing the LP bot later)

- [ ] Re-read live Base `PoolManager` / `PositionManager` / `StateView` addresses (blueprint placeholders).
- [ ] Confirm TELx IncentiveController ABI: `subscribe(tokenIds)` (or current equivalent) and whether it is multicall-friendly.
- [ ] Prefer PosM `Actions` batch for burn/mint; only design a custom `unlock` router if PosM+TELx composition fails.
- [ ] Encode settle/take so wallet inventory nets correctly after staggered-bracket remint.
- [ ] Simulate full tx (liquidity + subscribe) before broadcast; assert new tokenIds subscribed in receipt.
- [ ] Gate rebalance on Merkl passive cooldown / anti-JIT policy (product rule, not this repo).
- [ ] Do not vendor this repo’s arb hook or donate path.
- [ ] If copying any file, fix `UNLICENSED` vs MIT inconsistency and drop `PoolTestBase` inheritance.
- [ ] Pin current Uniswap v4 periphery compatible with Base mainnet — not 2024-06 gitlinks.
- [ ] Keep opportunity/breach detection off-chain; on-chain path should be “execute planned bundle.”

### Key file pointers

| Path | Why it matters |
|------|----------------|
| `README.md` | Product thesis (TheEqualizer); flash-accounting motivation |
| `src/AtomicArbRouter.sol` | **`unlock` / `unlockCallback` / multi-`swap` / `donate` / `take`** — primary architecture sample |
| `src/AtomicArbHook.sol` | Dynamic fee override by caller — pattern only; skip for LP bot |
| `test/AtomicArb.t.sol` | Deployers setup, HookMiner, liquidity seeding via `modifyLiquidityRouter`, quoter usage, flash-accounting assertions |
| `test/utils/HookMiner.sol` | CREATE2 flag mining for hooks (rarely needed for TELx consumer bot) |
| `foundry.toml` | `cancun` + `0.8.24` |
| `.gitmodules` / `remappings.txt` | How v4-core & v4-periphery are wired |
| `script/02_AddLiquidity.s.sol` | Template `PoolModifyLiquidityTest.modifyLiquidity` usage (Goerli — outdated addrs) |
| `script/03_Swap.s.sol` | Template swap + `TestSettings{takeClaims, settleUsingBurn}` |
| `.github/workflows/test.yml` | Minimal Foundry CI shape |

### Upstream APIs the sample relies on (for study)

- `IPoolManager.unlock` / `modifyLiquidity` / `swap` / `donate` / `settle` / `take`
- `IUnlockCallback.unlockCallback`
- `CurrencySettleTake.settle` / `.take`
- `PoolTestBase._fetchBalances` → `currencyDelta` (test-only helper)

### One-line verdict

**Useful as a compact illustration of Uniswap v4 unlock + flash-accounting atomic multi-ops; not a blueprint to fork for TELx Merkl LP — compose PositionManager burns/mints with TELx `subscribe`, and keep arb/hook/donate machinery out.**
