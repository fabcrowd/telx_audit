---
cursor:
  subagentId: "bc-f2940dd1-ff64-5579-8b41-d6c92a2a4e4b"
---

# pool-selection-data

Raw data and scripts behind `docs/pool-selection.md` (TELx pool comparison, accessed 2026-11-08 21:40–22:05 UTC). Generalised from `internal/edge-data/` (read_state.py, scan_logs.py, analyze.py, simulate.py, tick_stats.py).

Pipeline (run from this directory, Python 3.12 + web3 8):

1. `verify_chains.py` → `verify-chains.json`, `verify.log` — RPC reachability, v4 periphery / registry addresses per chain, poolKey → poolId recomputation, slot0, `minLiquidity`, `poolAllowed`.
2. `merkl_fetch.py` → `merkl/opportunity-<slug>.json`, `merkl/leaderboard-<slug>.json`, `merkl/summary.json` (input list: `merkl-campaigns-tel.json`).
3. `collect.py <slug> 30` → `<slug>/state.json` (slot0, active L, all initialised ticks, subscribed positions in pool), `<slug>/logs-30d.jsonl` (Swap + ModifyLiquidity), `<slug>/block-timestamps.json`. Logs: `<slug>.collect.log`. `base-eusd-tel/` is copied from `../edge-data/` (see `base-eusd-tel/SOURCE.txt`).
4. `analyze_pool.py <slug>` → `<slug>/analysis.json` (tick path, current eligible positions, leaderboard validation, vol/drift/breach stats, concentration, depth, price impact), `<slug>/analysis.log`.
5. `simulate_pool.py <slug> [budget]` → `<slug>/sim-results.json` ($2k), `<slug>/sim-results-1000.json` ($1k), `<slug>/sim-output.txt`.
6. `summarize.py` → `summary-tables.md`, `summary-table.json`.

Slugs: `base-eusd-tel`, `base-eth-tel`, `poly-eusd-tel`, `poly-weth-tel`, `poly-eusd-emxn`, `eth-eusd-tel`, `eth-eth-tel` (constants in `chains.py`).

RPCs that worked for 30-day `eth_getLogs`: Base `base-rpc.publicnode.com` (50k blocks), Polygon `polygon-bor-rpc.publicnode.com` (10k), Ethereum `mainnet.gateway.tenderly.co` (10k). `rpc.flashbots.net` returned silently empty ranges and must not be used for history; `ethereum-rpc.publicnode.com` 403s `eth_getLogs`.
