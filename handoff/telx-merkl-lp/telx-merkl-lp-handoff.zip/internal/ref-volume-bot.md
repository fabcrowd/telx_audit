---
cursor:
  subagentId: "bc-8ba52358-6f5a-526e-a1e3-c0ba67789b36"
---

# Design reference: joymadhu49/volume-bot

**Repo:** https://github.com/joymadhu49/volume-bot  
**Analyzed (shallow + full clone):** tip `976f2c1` (2026-03-31)  
**Purpose of this note:** extract transferable Uniswap v4 / Base patterns for the TELx Merkl LP bot (staggered brackets, atomic rebalance, Merkl subscribe, volume-spark keep-alive). **Design research only** — not an implementation guide for wash trading, MEV, or attack runbooks.

Related project docs: [`docs/project-context.md`](../docs/project-context.md), [`docs/bot-blueprint.md`](../docs/bot-blueprint.md).

---

## 1. Purpose, maturity, license, last activity

| Field | Finding |
|-------|---------|
| **Stated purpose** | “Auto volume bot” for tokens on Uniswap v4 (Base): continuous randomized buy/sell loop to create on-chain swap volume. Dual UI: blessed terminal dashboard (`cli.js`) or Telegram (`index.js`). |
| **npm name** | `chainsoul-volume-bot` (README brands “Volume Bot” / Telegram copy says “ChainSoul Volume Bot”). |
| **Maturity** | Early personal prototype. **14 commits**, ~1 month of active development (2026-03-05 → 2026-03-31), then quiet. **0 stars / 0 forks**, no issues/PRs, no releases/tags, no tests, no CI, no TypeScript, no SDK packages beyond `ethers`. Several commits list Claude as co-author. |
| **Last activity** | 2026-03-31 — “fix: use verified Clanker hook addresses from Blockscout”. As of analysis date (2026-11-08): **~7 months idle**. |
| **License** | **None declared.** GitHub `license` API → 404; no `LICENSE` file; `package.json` has no `license` field. Treat as **all-rights-reserved / unclear reuse**. Do not copy substantial code verbatim into our repo without explicit permission or a clean-room rewrite of ideas only. |
| **Scope vs ours** | Swap-only volume generator for WETH/token pools (esp. Clanker meme hooks). **No LP**, **no PositionManager**, **no Merkl/TELx subscribe**, **no bracket math**, **no rebalance planner**. |

**Verdict:** useful as a small, readable Base + Uniswap v4 Universal Router / pool-key discovery specimen — **not** as a Merkl LP architecture to fork.

---

## 2. Architecture / module map

Flat Node.js app (~2.1k LOC JS). No `src/` tree, no tests, no config schema.

```text
volume-bot/
├── package.json      # ethers@6, blessed, telegraf, dotenv, chalk, inquirer
├── .env.example      # RPC_URL, BOT_TOKEN, PRIVATE_KEY
├── trader.js         # Chain I/O: pool discovery, V4 swap encode, buy/sell, balances
├── cli.js            # Blessed TUI + auto trade loop (primary UX per README)
├── index.js          # Telegraf Telegram bot + same trade loop
├── db.js             # users.json key-value “DB” (per-user settings + trade history)
└── utils.js          # AES encrypt/decrypt for keys, CoinGecko ETH price, randomBetween
```

### Responsibility split

| Module | Role |
|--------|------|
| **`trader.js`** | Sole on-chain surface: addresses, ABIs, nonce queue, pool discovery, Universal Router `execute`, Permit2 approvals, DexScreener/CoinGecko pricing helpers. |
| **`cli.js` / `index.js`** | UX + orchestration: start/stop loop, amount/interval randomization, PnL/history display, settings wizards. Both call into `trader`. |
| **`db.js`** | Persist wallet ciphertext, token, pool key fields (`fee_tier`, `tick_spacing`, `hook_address`), min/max USD & interval, trade_count / trade_history. |
| **`utils.js`** | Local crypto for private keys; price + RNG helpers. |

### Runtime model

- Single process; HTTP JSON-RPC via `ethers.JsonRpcProvider(RPC_URL || https://mainnet.base.org)`.
- **No WebSocket**, no event subscription for swaps (except one-shot `Initialize` log scan during discovery).
- Trade loop = `setTimeout` recursion with randomized delay; CLI also shows a countdown bar.
- Per-address **promise-chain nonce queue** in `trader.sendTx` so concurrent UI actions do not collide.

### Hardcoded Base addresses (as in repo)

| Contract | Address |
|----------|---------|
| Universal Router V4 | `0x6ff5693b99212da76ad316178a184ab56d299b43` |
| PoolManager | `0x498581ff718922c3f8e6a244956af099b2652b2b` |
| Permit2 | `0x000000000022D473030F116dDEE9F6B43aC78BA3` |
| WETH | `0x4200000000000000000000000000000000000006` |

**Not present (and needed for our LP bot):** PositionManager, StateView, TELx IncentiveController, Permit2 signature flow for PosM, Multicall3 beyond UR commands.

---

## 3. How it generates / simulates volume (high level)

**Mechanism:** wash-style two-sided swaps against a configured Uniswap v4 pool using the operator’s own wallet(s).

1. User configures token + (auto or manual) `PoolKey` `{currency0, currency1, fee, tickSpacing, hooks}` for **token ↔ WETH**.
2. Loop picks a random USD notional in `[min_amount_usd, max_amount_usd]`, converts to ETH via CoinGecko (fallback hardcodes ~$2000–$3000).
3. With ~**70% probability: BUY** (ETH → WRAP_ETH → `V4_SWAP` exact-in).
4. With ~**30% probability: SELL** (5–15% of token balance via Permit2 → `V4_SWAP` → `UNWRAP_WETH`).
5. Sleep random `[min_interval_sec, max_interval_sec]` (defaults 20–60s; README examples 10–30s), repeat until STOP.
6. Manual buy/sell menus exist for one-shots; Telegram path historically supported multi-wallet rotation (CLI later simplified away multi-wallet UX; `index.js` still has multi-wallet sell/import paths).

**Encoding sketch (conceptual):** Universal Router command bytes (`WRAP_ETH` + `V4_SWAP` for buys; `PERMIT2_TRANSFER_FROM` + `V4_SWAP` + `UNWRAP_WETH` for sells). Inside V4 swap input: action bytes `SWAP_EXACT_IN_SINGLE` → `SETTLE` → `TAKE_ALL` / `TAKE_PORTION`, with `amountOutMinimum = 0`.

**What it is not:** LP fee farming, oracle manipulation tooling, sandwich construction, or Merkl-aware utilization scoring. It simply submits frequent small swaps so explorers/DexScreener show “volume.”

**Relevance to our “volume-spark keep-alive”:** same *physical* primitive (tiny self-swap through active ticks) but opposite *policy* — continuous high-frequency wash vs rare keep-alive when `no_volume_duration > 3h`. Do not import their loop cadence or 70/30 buy/sell schedule into Merkl ops.

---

## 4. Chain / RPC patterns, config, safety switches

### Config

| Source | Contents |
|--------|----------|
| `.env` | `RPC_URL`, `BOT_TOKEN` (Telegram), `PRIVATE_KEY` (auto-import into encrypted local store) |
| `users.json` (gitignored) | Per-user settings + encrypted key + trade history |
| Optional `wallets.txt` | Plain private keys auto-imported by `index.js` on startup (**dangerous pattern**) |
| In-app settings | Token address, min/max USD, min/max interval, manual pool key `fee tickSpacing [hooks]` |

No TOML/YAML, no zod schema, no per-pool allowlist, no environment staging (testnet/mainnet flag).

### RPC / discovery patterns worth noting

1. **Fast path — combinatorial `PoolKey` probe:** for each of ~6 known hooks (zero + 5 Clanker) × ~9 fee/tickSpacing presets, compute `poolId = keccak256(abi.encode(c0,c1,fee,tickSpacing,hooks))` and call `getSlot0(poolId)`. First hit with `sqrtPriceX96 > 0` wins.
2. **Slow path — `Initialize` log scan:** filter PoolManager logs by currency topics; chunked `getLogs` (50k blocks, up to 15M blocks back) with short retries.
3. **Manual override** when discovery fails (important for non-WETH or exotic TELx pools).
4. **Currency ordering:** `token < WETH` lexicographic compare to set `currency0`/`currency1`.
5. **Fixed gas limits** on sends (e.g. 700k swap, 100k approve) — no fee oracle / EIP-1559 strategy object.
6. **Deadline:** `now + 300s` on UR `execute`.

**Caveat / speculation:** Official Uniswap v4 integrations typically read slot0 via **StateView** (`0xa3c0c9b65bad0b08107aa264b0f3db444b867a71` on Base per our blueprint), not a public `PoolManager.getSlot0`. This repo calls `getSlot0` on PoolManager and on failure of the call **aborts the entire probe grid** (`return null` inside the catch). **Speculation:** fast path often no-ops on current Base PoolManager, forcing the expensive event scan. Our bot should prefer StateView (or confirmed extsload helpers) and treat this probe as a cautionary tale.

README vs code inconsistency: README claims ~115 days of history; code comments claim ~350 days / 15M blocks @ 2s.

### Safety switches (thin)

| Control | Present? | Notes |
|---------|----------|-------|
| Start / Stop loop | Yes | Soft pause only; no durable kill-switch file/env |
| Dry-run / simulate | **No** | Every path sends real txs |
| Slippage / `amountOutMinimum` | **No** (`0n`) | Sandwich-exposed exact-in |
| Max daily notional / trade count | **No** | |
| Passive / Merkl cooldown awareness | **No** | N/A to their product |
| Gas price cap | **No** | Hard gasLimit only |
| Insufficient funds stop | Partial | Telegram loop stops on “insufficient funds”; CLI logs and keeps looping if `running` |
| Key custody | Weak | AES-256-CBC with default passphrase `'chainsoul-default-key'` if `ENCRYPTION_KEY` unset; plaintext `.env` / `wallets.txt` import paths |
| Auth on Telegram | **None visible** | Anyone who can talk to the bot token appears able to create a user and drive flows (multi-tenant JSON file) — **high risk if BOT_TOKEN leaks** |

---

## 5. What transfers cleanly vs what does not

### Transfers cleanly (ideas / patterns — clean-room)

| Pattern | Why useful for TELx Merkl LP bot |
|---------|----------------------------------|
| Explicit **PoolKey** persistence (`fee`, `tickSpacing`, `hooks`, ordered currencies) | TELx pools may use non-default hooks/fees; never hardcode only “3000/60/zero”. |
| Manual pool-key override when discovery fails | Same failure mode for TEL/eUSD (non-WETH pair) — this repo is WETH-centric; we must generalize. |
| Combinatorial probe of known fee/spacing (+ known hooks) before log scan | Cheap first pass; adapt to **StateView** + our known TELx hook set. |
| Chunked `getLogs` + retry for historical discovery | Ops/tooling for “find the pool once,” not hot path. |
| Universal Router command composition for **volume-spark** swaps | Spark module can reuse UR wrap/swap/unwrap ideas; prefer viem + typed codecs over hand-rolled hex. |
| Permit2 allowance check before approve | Avoid redundant approve txs on spark sells / token legs. |
| Per-wallet **serialized nonce queue** | Essential once monitor + spark + rebalance can race. |
| Start/stop + structured trade/event log with Basescan links | Ops UX for spark/rebalance audit trail. |
| Separate “chain adapter” module from UI/orchestrator | Their `trader.js` vs `cli.js` split maps to our `chain/` + `orchestrator/` + `spark/`. |
| Fixed Base periphery address table in one place | Match blueprint; add PosM / StateView / TELx. |

### Does **not** transfer (especially vs Merkl Passive / JIT)

| Anti-fit | Why |
|----------|-----|
| Continuous 10–60s wash loop | Burns gas, looks like wash trading, **not** Merkl keep-alive; our spark is rare and threshold-gated. |
| 70/30 buy/sell inventory churn | Moves inventory and price; LP bot wants **stable brackets** and minimal inventory shock. |
| `amountOutMinimum = 0` | Unacceptable for production capital; sparks still need slippage bounds. |
| No simulate-before-send | Our blueprint requires `simulateContract` + guards. |
| Swap-only Universal Router focus | Rebalance needs **PositionManager** `modifyLiquidities` + TELx `subscribe`, not UR volume commands. |
| Same-block / high-frequency liquidity or swap games | TELx **JIT → 0%**; **Active** (>1 liquidity modify / ~43_200 Base blocks) → 0% for period. Their product never touches liquidity mods — but copying “always on” aggression into rebalances would zero rewards. |
| Atomic burn+mint as volume tactic | N/A here; for us atomicity is **capital safety**, and may still collide with JIT rules — see blueprint §2/§7. |
| WETH-only pair assumption | TEL/eUSD needs arbitrary `currency0/currency1`, possibly no native wrap path. |
| Telegram multi-user + local JSON key store | Wrong custody model for a single-ops LP vault. |
| Clanker hook catalog as primary discovery | Useful for memes; TELx hooks/pool keys should come from TELx docs / Basescan, not Clanker lists. |
| PnL-as-buy-vs-sell-USD accounting | Irrelevant to Merkl share maximization. |
| Hand-rolled action bytes without SDK tests | Fragile; prefer `@uniswap/v4-sdk` / periphery encoders + golden vectors. |

### Merkl Passive/JIT checklist interaction (ours — not theirs)

This repo never calls `modifyLiquidity`. Borrowing only the **swap spark** idea:

- Sparks are **swaps**, not liquidity modifications → should **not** trip Passive “1 modify / 24h” by themselves (**verify** against live TELx rules).
- Sparks must route through the bot’s **in-range core** ticks so Merkl volume attribution hits our position.
- Never couple spark and rebalance into one aggressive same-block add/remove pattern that looks like JIT.
- Rebalance planner remains gated by `lastLiquidityModifyBlock + 43_200` (Base) per blueprint.

---

## 6. Concrete “steal these ideas” checklist

For future developers (implement in **our** stack: TypeScript + viem + v4-sdk — not by forking this repo):

1. **[ ]** Single module owns Base addresses + ABIs; config validates pool keys with a schema.
2. **[ ]** Store full `PoolKey` (including hooks) next to each monitored pool; support manual override.
3. **[ ]** Discovery tool (offline/script): StateView slot0 probe grid → optional `Initialize` log scan → write `pools.base.yaml`.
4. **[ ]** Volume-spark: tiny exact-in swap via Universal Router (or SwapRouter) with **non-zero minOut**, gas cap, and idle-threshold gate (`> 3h` no `Swap` events).
5. **[ ]** Serialize all wallet sends through a nonce/mutex queue shared by spark + rebalance.
6. **[ ]** Preflight: `simulateContract` / eth_call; abort on revert; log Basescan hash on success.
7. **[ ]** Soft kill switch (env/file) checked every loop — stronger than their start/stop flag.
8. **[ ]** Permit2: check allowance then approve max-uint160 with finite expiry; never approve wrong contract (their history shows an approve-target bug that was fixed — learn from the commit, don’t repeat).
9. **[ ]** Progress callbacks / structured logs during long RPC scans (their `onProgress` notify pattern).
10. **[ ]** Separate CLI/ops dashboard later if needed — do **not** block core bot on blessed/Telegram.
11. **[ ]** Never default encryption passphrase; never commit keys; prefer OS keychain / KMS / locked signer — treat their `ENCRYPTION_KEY` default and `wallets.txt` as **anti-patterns**.
12. **[ ]** Document license posture of any copied snippet; prefer clean-room reimplementation.

**Do not steal:** randomized continuous wash loop, zero slippage, Telegram open control plane, Clanker-first product assumptions, private-key-in-JSON custody.

---

## 7. Key file links (with why)

Paths below are GitHub blob URLs at analyzed tip `976f2c1` on `main`.

| File | Link | Why it matters |
|------|------|----------------|
| README | https://github.com/joymadhu49/volume-bot/blob/main/README.md | Product intent, setup, address table, pool discovery UX summary. |
| `package.json` | https://github.com/joymadhu49/volume-bot/blob/main/package.json | Stack pins (`ethers` 6, blessed, telegraf); shows no v4-sdk / viem. |
| `trader.js` | https://github.com/joymadhu49/volume-bot/blob/main/trader.js | **Core reference:** nonce queue, Clanker hook list, probe + Initialize scan, UR buy/sell encoding, Permit2, balances. |
| `cli.js` | https://github.com/joymadhu49/volume-bot/blob/main/cli.js | Auto loop (70/30 buy/sell), settings wizard, start/stop, PnL/history — orchestration patterns only. |
| `index.js` | https://github.com/joymadhu49/volume-bot/blob/main/index.js | Telegram twin of the loop; multi-wallet + `wallets.txt` import (**custody anti-pattern**). |
| `db.js` | https://github.com/joymadhu49/volume-bot/blob/main/db.js | Minimal durable settings shape (pool fields + intervals) — inspiration for our state store fields, not the JSON file approach. |
| `utils.js` | https://github.com/joymadhu49/volume-bot/blob/main/utils.js | Illustrates weak local key encryption defaults — **what not to do**. |
| `.env.example` | https://github.com/joymadhu49/volume-bot/blob/main/.env.example | Minimal env surface (`RPC_URL`, `BOT_TOKEN`, `PRIVATE_KEY`). |
| Tip commit | https://github.com/joymadhu49/volume-bot/commit/976f2c18e28fd0ec17c880bec7810b20387b22f2 | Documents verifying hook addresses on Blockscout before hardcoding — good ops habit. |

---

## 8. License / risk notes

1. **No SPDX / LICENSE** → legal reuse of source text is unclear; **reimplement ideas**, do not vendor files.
2. **Security posture is hobby-grade:** default AES key material, optional plaintext key file import, Telegram bot without apparent allowlist, slippage disabled.
3. **Regulatory / platform risk:** purpose is artificial volume. Even as a design reference, our spark feature must stay **utilization keep-alive for Merkl scoring**, sized negligible, rate-limited, and documented — not a volume-bot clone.
4. **Technical risk if copied naively:** PoolManager `getSlot0` probe, WETH-only pairs, zero `amountOutMinimum`, and no simulation would all be production defects in our LP bot.
5. **Supply-chain:** small unknown publisher; pin and audit anything you copy; prefer Uniswap official examples / sdk for encodings.

---

## 9. Speculation log (explicit)

| Claim | Status |
|-------|--------|
| Fast-path `PoolManager.getSlot0` often fails on current Base deployment, forcing log scan | **Speculation** based on Uniswap v4 StateView norms + this repo’s own catch → `return null` behavior; not re-probed live in this research pass. |
| Telegram bot is effectively open to any chat user with access to the token | **Inferred** from `createUser(ctx.from.id)` with no allowlist in source; not dynamically tested. |
| Multi-wallet path in `index.js` is partially vestigial after CLI overhaul | **Inferred** from commit message “remove multi-wallet” vs remaining `index.js` wallet arrays. |
| Author intent is Clanker/meme volume, not LP incentives | **High confidence** from README + hook lists + absence of PosM/Merkl — still product-intent inference. |

---

## 10. Bottom line for TELx Merkl LP bot

Use this repo as a **compact Base v4 swap + pool-key discovery field guide**. Lift the *ideas* of PoolKey persistence, discovery fallbacks, UR spark swaps, and send serialization. **Reject** its product loop, custody model, and safety omissions. Merkl Passive/JIT constraints, staggered brackets, PositionManager multicalls, and TELx `subscribe` remain entirely on us (see blueprint) — this reference does not implement or even sketch them.
