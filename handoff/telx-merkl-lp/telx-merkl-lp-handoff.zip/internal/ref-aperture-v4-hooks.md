---
cursor:
  subagentId: "bc-c99b76c0-dc86-58b1-a602-33e141eec25b"
---

# Design reference: Aperture-Finance Uniswap v4 hooks

**Scope:** design research only for the TELx Merkl Uniswap v4 LP bot on Base. No exploit PoCs; no production bot code.  
**Primary URL used:** https://github.com/Aperture-Finance/uniswap-v4-hooks (resolves; **not** a 404).  
**Cloned:** `/tmp/aperture-research/uniswap-v4-hooks` (shallow).  
**Related Aperture repos surveyed for patterns:** `uniswap-v3-automan`, `Aperture-Lens`, `UniV4Backtester_ETHSF2024`.  
**Project context:** staggered-bracket LP + TELx subscribe on Base v4 (`docs/bot-blueprint.md`, `docs/project-context.md`).

---

## 1. Repo purpose, maturity, license, activity

| Field | Finding |
|-------|---------|
| Purpose (stated) | Design notes for three Uniswap v4 hook ideas: JIT fee equity, in-hook LP automation, institutional permissions |
| Purpose (actual) | **README-only manifesto** from Uniswap v4 early hook brainstorming (ETH-SF era). Commit message says “Initial hook PoC”; diff is README prose only — **no Solidity, Foundry, tests, or deployments** |
| Created / last push | 2023-09-01 → 2023-09-01 (3 commits by `while1`) |
| Stars / forks / issues | 0 stars, 2 inert forks (README copies), 0 issues |
| Size / language | 6 KB; GitHub `language: null` |
| License | **None** declared (no LICENSE file; API `license: null`) |
| Archived | No, but effectively abandoned |
| Base / production | **No Base deployment, no PoolManager integration, no hook address mining** |

**Verdict on maturity:** conceptual sketch, not a reusable hooks codebase. Treat as historical product thinking from Aperture, not as an implementation reference for Base v4 TELx pools.

**Where Aperture’s real LP automation lives (for pattern transfer):**

| Repo | Role | Maturity signal |
|------|------|-----------------|
| [uniswap-v3-automan](https://github.com/Aperture-Finance/uniswap-v3-automan) | Production **periphery** automation (close / rebalance / reinvest) for UniV3, Pancake V3, Aerodrome SlipStream; includes **Base** deploy params | BUSL-1.1 → GPL-2.0 after change date; audits under `audits/`; CI; active through 2025 |
| [Aperture-Lens](https://github.com/Aperture-Finance/Aperture-Lens) | Ephemeral lens contracts + viem clients; **includes V4** position/tick helpers | Apache-2.0; npm `aperture-lens` |
| [UniV4Backtester_ETHSF2024](https://github.com/Aperture-Finance/UniV4Backtester_ETHSF2024) | Hackathon v4 backtester; `AutoCompound.sol` largely **commented out**; `NoopHook` stub | No license; 2024 hackathon |

---

## 2. Hook catalog / architecture (what “hooks” exist)

The target repo defines **three design proposals**, not deployed contracts. Hook names below are conceptual; APIs cited match **early v4 draft** (`beforeModifyPosition` / `afterModifyPosition`) — production Uniswap v4 uses `before/afterAddLiquidity` and `before/afterRemoveLiquidity` (plus swap/donate permissions). Do not copy the old names into Base code.

### 2.1 JIT fee equity hook

**User goal:** redistribute fees so passive LPs are not drained by same-block JIT LPs, while still allowing JIT that reduces trader impact.

**Approach A — Adaptive block-distance fee redistribution**

- Use `before/afterModifyPosition` to mark add→remove sequences and attribute captured fees.
- Custom knobs redistribute JIT-captured fees to other in-range LPs.

**Approach B — Fees as MasterChef-style rewards**

- Intercept trading fees into the hook; emit fee tokens by emission rate + allocation points (passive vs JIT weights).
- Governance tunes allocation.

**v4 assumptions:** pool-attached hook can observe every liquidity modify and (in B) divert fee accounting. **No Base-specific assumptions.** Conflicts with TELx Merkl: TELx already zero-weights JIT/Active behavior off-chain — a fee-redistribution hook is a different incentive layer and is not TELx’s mechanism.

### 2.2 Hook-based LP automation

**User goal:** rebalance / compound / limit-order **natively in Uniswap**, without off-chain infra.

**Proposed flow:**

1. External registration: position id + desired future range stored in hook.
2. `afterSwap`: scan tracked positions; rebalance when owner conditions met.
3. Compensate traders for extra gas by skimming a portion of the rebalanced position.

**Architecture implication:** automation cost is socialized onto **every swapper** of that pool. Gas and MEV surface grow with tracked position count. This is the opposite of Aperture’s shipped Automan model (off-chain controller → on-chain periphery).

### 2.3 Institutional permission / hook-owned liquidity

**User goal:** finer than UniV3 NPM’s “approve one NFT **or** operator for all.”

**Ideas:**

- Hook owns pool liquidity (hook-owned liquidity / HOL).
- Track same-tx A→B rebalance and **inherit permissions** from parent position.
- Bake automation conditions (e.g. price bounds) into gasless permit payloads.

**Relevance note:** TELx unsubscribes on NFT transfer; custody and permission inheritance across mint/burn must stay compatible with IncentiveController rules — a HOL design would need TELx-aware ownership, which this README never mentions.

### 2.4 What is *not* in the repo

- No `getHookPermissions` bitmap, CREATE2 vanity mining, or Base PoolKey wiring.
- No staggered multi-position strategy, Merkl, or subscribe flow.
- No tests proving reentrancy / unlock callback safety under production v4.

Sibling **UniV4Backtester** adds only:

- `NoopHook` — all permissions false (or commented vanity-address variants).
- `AutoCompound` — third-party-inspired afterSwap compound; **source mostly commented**; share accounting sketch, not production.

---

## 3. Patterns for liquidity modification, rebalancing, position management, automation

### 3.1 From the v4-hooks README (conceptual)

| Pattern | Mechanism | TELx caution |
|---------|-----------|--------------|
| Detect JIT | Correlate add+remove via modify hooks / block distance | TELx already penalizes JIT off-chain — do not reimplement as bot “feature” |
| In-hook rebalance | `afterSwap` scans + `modifyLiquidity` | Extra swaps = Active/JIT risk; tax traders; cannot call TELx subscribe cleanly |
| Permission inheritance | Same-tx parent→child tracking | Useful *idea* for bot state (`oldTokenId → newTokenIds`), not as a pool hook |
| Trader gas rebate from LP skim | Deduct from rebalanced position | Misaligned with Merkl max-share objective |

### 3.2 From Automan (actual Aperture automation — primary pattern transfer)

**Architecture:** off-chain automation service + on-chain `UniV3Automan` / `SlipStreamAutoman` periphery. Controllers are allowlisted; users permit Automan on NFT(s).

**Supported actions:** close, **rebalance** (new tick range → **new NFT**), **reinvest** (collect fees → optimal swap → increase same NFT).

**Canonical rebalance sequence** (`_rebalance` in `src/base/Automan.sol`):

1. Optional fee collect + zap-out to owner.
2. Remove liquidity + collect + deduct protocol fee.
3. Set `recipient` = current NFT owner (preserve custody).
4. `_optimalSwap` inventory into target range ratio (`OptimalSwap` closed-form + optional external `swapData`).
5. `_mint` new position NFT → emit `Rebalance(newTokenId)`.

**Auth pattern:** `checkAuthorizedForToken` + optional EIP-2612-style NFT `Permit` / operator approval — gasless scheduling for institutions without transferring ownership.

**Base footprint:** deploy scripts + `script/UniV3Automan_input/8453/automan_params.json` (NPM, controller, fee collector, OKX router). Proves Aperture treated Base as a first-class automation venue — still **v3/SlipStream**, not v4 PosM.

**Not in Automan:** multi-bracket staggered layouts; Merkl/TELx subscribe; cooldown-aware passive windows; volume-spark swaps as a product feature.

### 3.3 From Aperture-Lens (read-path patterns)

Useful **off-chain inventory** primitives for a v4 bot (ephemeral / eth_call style):

- `PositionLensV4`, `EphemeralGetPosition(s)V4`, `EphemeralGetPopulatedTicksInRangeV4`, `PoolUtilsV4` / `PositionUtilsV4`, `IStateView`.
- Pattern: batch position fee + amount reads without deploying lenses permanently.

### 3.4 Layering model for TELx (synthesis)

```text
┌─────────────────────────────────────────────────────────┐
│ Off-chain bot (recommended for TELx)                    │
│  slot0 watch · breach · cooldown · plan · simulate      │
│  PosM modifyLiquidities · TELx.subscribe · verify       │
└──────────────────────────▲──────────────────────────────┘
                           │ txs
┌──────────────────────────┴──────────────────────────────┐
│ Periphery (Uniswap PositionManager + optional executor) │
│  Actions: BURN/DECREASE · MINT/INCREASE · SETTLE/TAKE   │
└──────────────────────────▲──────────────────────────────┘
                           │ unlock
┌──────────────────────────┴──────────────────────────────┐
│ PoolManager + TELx pool hook (already on official pools)│
│  Do NOT replace with Aperture automation hook ideas     │
└─────────────────────────────────────────────────────────┘
```

---

## 4. Relevance to staggered-bracket LP + TELx subscribe

| Concern | Hooks (Aperture README) | Periphery (Automan-like) | Off-chain bot (blueprint) |
|---------|-------------------------|--------------------------|---------------------------|
| Staggered 3 brackets | Not addressed | Single-position rebalance only; extend planner off-chain | **Fit:** planner owns A/B/C roles |
| Rebalance trigger | `afterSwap` (every trade) | Controller calls when conditions met | **Fit:** breach + 43_200-block passive cooldown |
| Atomic burn→mint | Possible in unlock, but JIT-shaped | Automan: remove then mint **same tx** → new tokenId | Blueprint flag: `atomic_jit` vs staged; TELx may zero-weight same-tx |
| TELx `subscribe(newIds)` | Hook would need IncentiveController auth + NFT ownership model — **not designed** | Could wrap PosM+subscribe in custom executor **if** TELx accepts caller | **Fit:** bot multicall / same-block follow-up |
| NFT transfer / unsub | HOL changes ownership semantics | Automan keeps owner; Automan is operator | **Must keep owner stable**; avoid transfers |
| Volume spark | Not in README | Not a product action | **Bot-only** tiny swap path |
| Fee compound | Approach B / AutoCompound sketches | `reinvest` on same NFT | TELx: claims ≠ liquidity modify (verify); prefer claim path separate from rebalance |
| Who pays gas | Swappers (afterSwap) | Controllers / users | Bot wallet — correct for private strategy |

**Bottom line:** Aperture’s **shipped** answer to “automate LP” was **off-chain + periphery**, not in-pool hooks. Their v4-hooks README speculated about moving automation *into* hooks; that speculation is a poor fit for TELx Merkl (passive cooldown, mandatory subscribe, official pool hooks already set). For this bot, treat Automan’s **control plane** as the reference and the v4-hooks README as a **negative** example for on-swap automation.

---

## 5. Reuse conceptually vs ignore

### Reuse (concepts / adjacent code)

1. **Off-chain condition engine + allowlisted executor** — Automan’s split of “decide off-chain / act on-chain.”
2. **Rebalance = remove → ratio swap → mint new NFT, preserve owner** — map to v4 PosM actions + TELx subscribe on **new** tokenIds.
3. **Optimal inventory swap into target tick range** — `OptimalSwap` math / idea for capital reuse when reminting core/buffers (reimplement against v4 StateView; do not copy BUSL source into a GPL/MIT bot without license review).
4. **Permit / operator auth without transferring NFT** — custody model compatible with “transfer unsubscribes.”
5. **Aperture-Lens V4 ephemeral reads** — inventory reconciliation, fees, tick bitmap (Apache-2.0 friendlier).
6. **Position lineage in bot state** — README’s “inherit permissions A→B” → persist `oldTokenId → newTokenIds[]` + Merkl cooldown clocks.
7. **CREATE2 vanity / hook address mining awareness** — only if ever deploying a *custom* hook; TELx official pools already fix hook in PoolKey — bot should **consume** that address, not invent one.

### Ignore / actively avoid

1. **Implementing anything from `uniswap-v4-hooks` as Solidity** — there is no code; API names are pre-production.
2. **`afterSwap` rebalance / limit-order hooks** — taxes traders; fights TELx Passive; couples strategy to pool singleton behavior.
3. **JIT fee redistribution hooks** — orthogonal (and adverse) to Merkl TIR/passive rules.
4. **Hook-owned liquidity for this bot** — custody/subscribe complexity; not needed at ~$2k single-operator scale.
5. **UniV4Backtester `AutoCompound` as a template** — commented hackathon fork of external work; not audited Aperture product.
6. **Automan fee skim / OKX router coupling** — product economics, not Merkl share maximization.
7. **Assuming Aperture has a Base v4 Automan** — they do not in these public repos; v4 path is PosM + your bot (or a thin custom executor you design later).

---

## 6. Key file map + checklist

### 6.1 File map

**https://github.com/Aperture-Finance/uniswap-v4-hooks**

| Path | Notes |
|------|-------|
| `README.md` | Sole artifact: three hook design proposals |

**https://github.com/Aperture-Finance/uniswap-v3-automan** (pattern donor)

| Path | Notes |
|------|-------|
| `README.md` | Product model: off-chain service + on-chain Automan |
| `LICENSE` | BUSL-1.1 (change date 2026-07-01 → GPL-2.0+) |
| `src/interfaces/IAutoman.sol` | mint / increase / decrease / reinvest / rebalance API |
| `src/base/Automan.sol` | `_rebalance`, `_optimalSwap`, permits, fee config |
| `src/libraries/OptimalSwap.sol` | Closed-form double-sided deposit swap |
| `src/UniV3Automan.sol`, `SlipStreamAutoman.sol` | Chain/DEX variants |
| `script/UniV3Automan_input/8453/automan_params.json` | Base params example |
| `audits/*.pdf` | Narya May/July 2023 |

**https://github.com/Aperture-Finance/Aperture-Lens**

| Path | Notes |
|------|-------|
| `contracts/PositionLensV4.sol` | Fees + total amounts for v4 positions |
| `contracts/EphemeralGetPositionsV4.sol` | Batch position reads |
| `contracts/interfaces/v4/IStateView.sol` | StateView-shaped interface |
| `src/viem/` | TS clients |

**https://github.com/Aperture-Finance/UniV4Backtester_ETHSF2024**

| Path | Notes |
|------|-------|
| `src/hooks/NoopHook.sol` | Empty permissions BaseHook |
| `src/hooks/AutoCompound.sol` | Commented afterSwap compound sketch |
| `src/SUniV4Backtester.sol` / `UniV4Backtester.s.sol` | Backtest harness |

### 6.2 Developer checklist (TELx Merkl bot)

- [ ] Treat `Aperture-Finance/uniswap-v4-hooks` as **design history**, not a dependency.
- [ ] Prefer **Automan control-plane** (off-chain decide → PosM act → TELx subscribe) over in-hook automation.
- [ ] Map Automan `_rebalance` steps onto v4 `PositionManager.modifyLiquidities` action packs; account for **new tokenIds** + subscribe.
- [ ] Do **not** deploy a custom rebalance hook onto TELx pools; use official PoolKey.hook.
- [ ] Encode TELx passive cooldown (Base ~43_200 blocks) and JIT/Active zero-weight before choosing atomic vs staged rebalance.
- [ ] Keep NFT owner stable; use approvals/permits, not transfers.
- [ ] Consider `aperture-lens` / ephemeral V4 readers for inventory; verify license fit.
- [ ] If borrowing OptimalSwap ideas, run **license review** (BUSL) before copying Solidity.
- [ ] Ignore trader-gas-rebate / afterSwap skim economics.
- [ ] Reconfirm Base PosM / PoolManager / StateView / TELx IncentiveController addresses at implementation time (blueprint placeholders).

---

## Appendix — quick verdict

**Aperture’s public `uniswap-v4-hooks` repo is a 2023 README brainstorm (JIT fee equity, afterSwap automation, institutional HOL permissions) with zero executable hooks.** For the TELx Merkl staggered-bracket bot on Base, the useful Aperture lineage is **`uniswap-v3-automan` + `Aperture-Lens`**, not that hooks repo: automate off-chain, execute via periphery (v4 PosM), and keep TELx subscribe in the bot’s transaction path—not inside a pool hook.
